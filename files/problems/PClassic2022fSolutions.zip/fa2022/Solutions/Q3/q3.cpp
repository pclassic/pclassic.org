#include <string>
#include <iostream>
#include <vector>
using namespace std;

int getNth(int c1, int c2, int c3, int n) {
    int a = c1;
    int b = c2;
    int c = c3;
    int i = 4;
    int first = a;
    int second = b;
    int third = c;
    if (n == 1)
        return a;
    if (n == 2)
        return b;
    if (n == 3)
        return c;
    int next;
    while (i <= n) {
        next = (first + second + third + 100000007) % 100000007;
        first = second;
        second = third;
        third = next;
        i++;
    }
    return next;
}

int main() {
    int t;
    cin >> t;
    while (t-- > 0) {
        int c1, c2, c3;
        cin >> c1 >> c2 >> c3;
        int n;
        cin >> n;

        std::cout << getNth(c1, c2, c3, n) << std::endl;

    }
}