#include <string>
#include <iostream>
#include <vector>
using namespace std;

string rotateString(string s, int n) {
    int len = s.length();
    string leftString = "";
    string rightString = "";
    if (n == 0) {
        leftString = "";
    } else if (n == 1) {
        leftString = s.substr(0, 1);
    } else {
        leftString = s.substr(0, n);
        leftString = leftString.substr(1) + leftString.substr(0, 1);
    }
    if (n == len - 1) {
        rightString = "";
    } else if (n == len - 1) {
        rightString = s.substr(len - 1);
    } else {
        rightString = s.substr(n+1);
        rightString = rightString.substr(rightString.length() - 1) + rightString.substr(0, rightString.length() - 1);
    }
    return leftString + s.substr(n, 1) + rightString;
}

int main() {
    int t;
    cin >> t;
    while (t-- > 0) {
        string input;
        cin >> input;
        int n;
        cin >> n;
        std::cout << rotateString(input, n) << std::endl;

    }
}