#include <bits/stdc++.h>
using namespace std;
 
 
typedef pair<int,int> point;
#define Rd(r) freopen(r, "r", stdin);
#define Wt(w) freopen(w, "w", stdout);
#define x first
#define y second
#define INF 1<<30
#define MAXI 20
vector<int> MASK[MAXI];
int dp[1 << MAXI], rem[1 << MAXI], mark[1 << MAXI], y;
bool flag = false;
 
bool ZiwenZapper(int n, int m, int arr1[], int arr2[]) {
  y = 0;
	mark[0] = 1;
	for(int mask = 0; mask < (1 << n); mask++){
		for(int	i = 0; i < n; i++){
			if(mark[mask ^ (1 << i)] and (mask & (1 << i))){
				int last = dp[mask ^ (1 << i)];
				int curr = rem[mask ^ (1 << i)] + arr1[i];
				if(curr > arr2[last]) continue;
				dp[mask] = last + (curr == arr2[last] ? 1 : 0);
				rem[mask] = (curr == arr2[last] ? 0 : curr);
				mark[mask] = 1;
			}
		}
		if(dp[mask] == m) y = 1;
	}
	return y;
 
}
 
int main()
{
    //Rd("ziwenzapper.in");
    int n, m, t;
    int arr1[MAXI], arr2[MAXI];
	cin >> t;
	for(int j = 0; j < t; j++) {
    	cin >> n;
    	for (int i = 0; i < n; i++) cin >> arr1[i];
		cin >> m;
    	for (int j = 0; j < m; j++) cin >> arr2[j];
    	bool val = ZiwenZapper(n, m, arr1, arr2);
   		cout << val << endl;
	}
    return 0;
 
}