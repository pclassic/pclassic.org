#include <string>
#include <iostream>
#include <vector>
using namespace std;

int findOdd(vector<int> arr) {
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i] % 2 == 1) {
            return arr[i];
        }
    }
    return 0;
}

int main() {
    int t;
    cin >> t;
    while (t-- > 0) {
        int length;
        cin >> length;
        string line;
        vector<int> arr;
        arr.resize(length);
        for (int i = 0; i < length; i++) {
            std::cin >> arr[i];
        }
        std::cout << findOdd(arr) << std::endl;

    }
}