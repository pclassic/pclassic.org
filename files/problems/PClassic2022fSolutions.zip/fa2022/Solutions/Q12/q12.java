import java.util.HashMap;
import java.util.Queue;
import java.util.LinkedList;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {
    public static class Graph{
        HashMap<Integer, Integer>[] graph;
        int row;
        public Graph(HashMap<Integer,Integer>[] graphArg){
            graph = graphArg;
            row = graph.length;
        }
        
        public HashMap<Integer, Integer>[] getGraph(){
            return graph;
        }
        
        public void adjust_capacity(int firstShelter, int shelters, int maxShelters, int minShelters){
            for (int i = 0; i < shelters; i++){
                graph[firstShelter + i].put(row-1, graph[firstShelter + i].get(row-1) + maxShelters - minShelters);
            }
        }
        
        public boolean BFS(int s, int t, int[] parent){
            boolean[] visited = new boolean[row];
            Queue<Integer> q = new LinkedList<>();
            q.add(s);
            visited[s] = true;
            while (!q.isEmpty()){
                int u = q.poll();
                for (HashMap.Entry<Integer, Integer> entry: graph[u].entrySet()){
                    if (visited[entry.getKey()] == false && entry.getValue() > 0){
                        q.add(entry.getKey());
                        visited[entry.getKey()] = true;
                        parent[entry.getKey()] = u;
                        if (entry.getKey() == t){
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        
        public int ford_fulkerson(int source, int sink){
            int[] parent = new int[row];
            int max_flow = 0;
            while (BFS(source, sink, parent)) {
                int path_flow = Integer.MAX_VALUE;
                int s = sink;
                while(s != source){
                    path_flow = Math.min(path_flow, graph[parent[s]].get(s));
                    s = parent[s];
                }
                max_flow += path_flow;
                int v = sink;
                while (v != source){
                    int u = parent[v];
                    if (graph[u].keySet().contains(v)){
                        graph[u].put(v, graph[u].get(v) - path_flow);
                    } else{
                        graph[u].put(v, -path_flow);
                    }
                    if (graph[v].keySet().contains(u)){
                        graph[v].put(u, graph[v].get(u) + path_flow);
                    } else{
                        graph[v].put(u, path_flow);
                    }
                    v = parent[v];
                }
            }
            return max_flow;
        }
    }
    
    public static double dist(int[] loc1, int[] loc2){
        return Math.pow(Math.pow((loc1[0] - loc2[0]),2) + Math.pow((loc1[1] - loc2[1]),2),(0.5));
    }
    
    public static int findMaxPairing(int powerplants, int shelters, int[][] powerplantLocations, int[][] shelterLocations, int maxPowerPlants, int minShelters, int maxShelters){
        int graphlen = shelters + powerplants + 2;
        HashMap<Integer, Integer>[] graph = new HashMap[graphlen];
        for (int i = 0; i < graph.length; i++){
            graph[i] = new HashMap<Integer, Integer>();
        }
        ArrayList<Integer[]> pairs = new ArrayList<>(); 
        for (int i = 0; i < powerplants; i++){
            for(int j = 0; j< shelters; j++){
                if (dist(powerplantLocations[i], shelterLocations[j]) <= 10){
                    pairs.add(new Integer[]{i,j});
                }
            }
        }
        for (int i = 0; i < powerplants; i++){
            graph[0].put(i+1, maxPowerPlants);
        }
        int firstShelter = 1 + powerplants;
        for (int i = 0; i < shelters; i++){
            graph[firstShelter+i].put(graphlen - 1, minShelters);
        }
        for (int i = 0; i < pairs.size(); i++){
            graph[pairs.get(i)[0]+1].put(firstShelter + pairs.get(i)[1], 1);
        }

        Graph g = new Graph(graph);
        int firstRun = g.ford_fulkerson(0, graph.length-1);
        if (firstRun != minShelters * shelters)
            return 0;
        g.adjust_capacity(firstShelter, shelters, maxShelters, minShelters);
        int additionalPairs = g.ford_fulkerson(0, graph.length-1);
        return firstRun + additionalPairs;
    }
    
    public static void main(String args[]) throws Exception{
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.valueOf(reader.readLine());
        for (int i = 0; i < t; i++) {
            int numPowerPlants = Integer.valueOf(reader.readLine());
            int numShelters = Integer.valueOf(reader.readLine());
            int[][] powerPlantLocations = new int[numPowerPlants][2];
            for (int j = 0; j < powerPlantLocations.length; j++){
                String[] line = reader.readLine().split(" ");
                powerPlantLocations[j][0] = Integer.valueOf(line[0]);
                powerPlantLocations[j][1] = Integer.valueOf(line[1]);
            }
            int[][] shelterLocations = new int[numShelters][2];
            for (int j = 0; j < shelterLocations.length; j++){
                String[] line = reader.readLine().split(" ");
                shelterLocations[j][0] = Integer.valueOf(line[0]);
                shelterLocations[j][1] = Integer.valueOf(line[1]);
            }
            int maxPowerPlants = Integer.valueOf(reader.readLine());
            int minShelters = Integer.valueOf(reader.readLine());
            int maxShelters = Integer.valueOf(reader.readLine());
            System.out.println(findMaxPairing(numPowerPlants, numShelters, powerPlantLocations, shelterLocations, maxPowerPlants, minShelters, maxShelters));
        }
    }
}