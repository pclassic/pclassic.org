class Graph:
 
    def __init__(self, graph):
        self.graph = graph  # residual graph
        self.ROW = len(graph)

    def adjust_capacity(self, firstshelter, shelters, maxshelters, minshelters):
        for i in range(shelters):
            self.graph[firstshelter + i][self.ROW-1] += maxshelters - minshelters

    '''Returns true if there is a path from source 's' to sink 't' in
    residual graph. Also fills parent[] to store the path '''

    def get_graph(self):
        return self.graph

    def BFS(self, s, t, parent):
 
        # Mark all the vertices as not visited
        visited = [False for _ in range(self.ROW)]
 
        # Create a queue for BFS
        queue = []
 
        # Mark the source node as visited and enqueue it
        queue.append(s)
        visited[s] = True
 
         # Standard BFS Loop
        while queue:
 
            # Dequeue a vertex from queue and print it
            u = queue.pop(0)
 
            # Get all adjacent vertices of the dequeued vertex u
            # If a adjacent has not been visited, then mark it
            # visited and enqueue it
            for ind, val in self.graph[u].items():
                if visited[ind] == False and val > 0:
                    # If we find a connection to the sink node,
                    # then there is no point in BFS anymore
                    # We just have to set its parent and can return true
                    queue.append(ind)
                    visited[ind] = True
                    parent[ind] = u
                    if ind == t:
                        return True
 
        # We didn't reach sink in BFS starting
        # from source, so return false
        return False

    # Returns the maximum flow from s to t in the given graph
    def FordFulkerson(self, source, sink):
 
        # This array is filled by BFS and to store path
        parent = [-1 for _ in range(self.ROW)]
 
        max_flow = 0 # There is no flow initially
 
        # Augment the flow while there is path from source to sink
        while self.BFS(source, sink, parent) :
 
            # Find minimum residual capacity of the edges along the
            # path filled by BFS. Or we can say find the maximum flow
            # through the path found.
            path_flow = float("Inf")
            s = sink
            while(s !=  source):
                path_flow = min (path_flow, self.graph[parent[s]][s])
                s = parent[s]
 
            # Add path flow to overall flow
            max_flow +=  path_flow
 
            # update residual capacities of the edges and reverse edges
            # along the path
            v = sink
            while(v !=  source):
                u = parent[v]
                if v in self.graph[u]:
                    self.graph[u][v] -= path_flow
                else:
                    self.graph[u][v] = -path_flow
                if u in self.graph[v]:
                    self.graph[v][u] += path_flow
                else:
                    self.graph[v][u] = path_flow
                v = parent[v]
 
        return max_flow


def dist(loc1, loc2):
    return ((loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2)**(1/2)

def findMaxPairing(powerplants, shelters, powerplantsLocations, shelterLocations, maxpowerplants, minshelters, maxshelters):
    graphLen = shelters + powerplants + 2 # need +2 for sink and source
    graph = [{} for j in range(graphLen)] 
    #source is index 0
    #sink is index -1
    pairs = []
    for i in range(powerplants):
        for j in range(shelters):
            if (dist(powerplantsLocations[i], shelterLocations[j]) <= 10):
                pairs.append((i,j))

    # add capacity maxpowerplants from source to powerplants:
    for i in range(powerplants):
        graph[0][i+1] = maxpowerplants

    # add capacity minshelters from shelters to sink:
    first_shelter = 1 + powerplants
    for i in range(shelters):
        graph[first_shelter + i][graphLen - 1] = minshelters

    for dh, d in pairs:
        graph[dh+1][first_shelter + d] = 1

    g = Graph(graph)
    first_run = g.FordFulkerson(0, len(graph)-1)
    if first_run != minshelters * shelters:
        return 0
    g.adjust_capacity(first_shelter, shelters, maxshelters, minshelters)
    additional_pairs = g.FordFulkerson(0, len(graph)-1)
    return first_run + additional_pairs 


if __name__ == "__main__":
    tests = int(input())
    for test in range(tests):
        numpowerplants = int(input())
        numshelters = int(input())
        powerplantLocations = []
        for i in range(numpowerplants):
            newpowerplant = [int(x) for x in input().split(" ")]
            powerplantLocations.append(newpowerplant)
        shelterLocations = []
        for i in range(numshelters):
            newshelter = [int(x) for x in input().split(" ")]
            shelterLocations.append(newshelter)
        maxpowerplants = int(input())
        minshelters = int(input())
        maxshelters = int(input())
        print(findMaxPairing(numpowerplants, numshelters, powerplantLocations, shelterLocations, maxpowerplants, minshelters, maxshelters))