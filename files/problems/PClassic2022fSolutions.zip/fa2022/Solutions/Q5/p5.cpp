#include <bits/stdc++.h>
 
using namespace std;
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()
 
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
 
typedef long long ll;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
const ll inf = 1e16;
 
const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
    T val;
    explicit operator T() const { return val; }
    mi() { val = 0; }
    mi(const long long& v) {
        val = (-MOD <= v && v < MOD) ? v : v % MOD;
        if (val < 0) val += MOD; }
    friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
    friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
    friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
    friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
    mi operator-() const { return mi(-val); }
    mi& operator+=(const mi& m) {
        if ((val += m.val) >= MOD) val -= MOD;
        return *this; }
    mi& operator-=(const mi& m) {
        if ((val -= m.val) < 0) val += MOD;
        return *this; }
    mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
        return *this; }
    friend mi pow(mi a, long long p) {
        mi ans = 1; assert(p >= 0);
        for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
        return ans; }
    friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
    mi& operator/=(const mi& m) { return (*this) *= inv(m); }
    friend mi operator+(mi a, const mi& b) { return a += b; }
    friend mi operator-(mi a, const mi& b) { return a -= b; }
    friend mi operator*(mi a, const mi& b) { return a *= b; }
    friend mi operator/(mi a, const mi& b) { return a /= b; }
};
 
void solve() {
    int n, k; cin >> n >> k;
    char portals[n];
    for (int i = 0; i < n; i++) {
        cin >> portals[i];
    }
 
    vector<char> l = {portals[0]};
    vl ld = {0};
 
    ll last; cin >> last;
 
    for (int i = 1; i < n; i++) {
        ll x; cin >> x;
        if (portals[i] != portals[i - 1]) {
            l.pb(portals[i]);
            ld.pb(last);
        } 
        last += x;
    }
 
    n = l.size();
    int next[n][4];
 
    for (int i = 0; i < 4; i++) {
        next[n - 1][i] = -1; 
    }
    next[n - 1][l[n - 1] - 'A'] = n - 1;
    
    for (int i = n - 2; i >= 0; i--) {
        for (int j = 0; j < 4; j++) {
            next[i][j] = next[i + 1][j];
        }
        next[i][l[i] - 'A'] = i;
    }
 
    for (int i = 0; i < k; i++) {
        char sc, fc; cin >> sc >> fc;
        ll x; cin >> x;
        if (x > last) {
            cout << -1 << "\n";
        }
 
        int s = sc - 'A';
        int f = fc - 'A';
        
 
        bool across = ((f - s) + 4) % 4 == 2 ? 1 : 0;
 
        // find the current teleporter open
        int idx = prev(upper_bound(ld.begin(), ld.end(), x)) - ld.begin();
        ll ret = -1;
 
        if (across) {
            ll adj1 = next[idx][(s + 1) % 4];
            ll adj2 = next[idx][(s + 3) % 4];
            
            if (adj1 >= 0 || adj2 >= 0) {
                ll adj;
                if (adj1 >= 0) {
                    adj = adj1;
                    if (adj2 >= 0) {
                        adj = min(adj, adj2);
                    }
                } else {
                    adj = adj2;
                }
                ret = next[adj][f];
            }
        } else {
            ret = next[idx][f];
        }
 
        if (ret < 0) {
            cout << ret << nl;
        } else {
            cout << max(ld[ret], x) - x << nl;
        }
    }
}
 
int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);
 
    int t; cin >> t;
    while (t--) {
        solve();
    }
}