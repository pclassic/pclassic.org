#include <bits/stdc++.h>

using namespace std;

bool customCompare(vector<int> & v1, vector<int> & v2) {
    if (v1[1] < v2[1]) {
        return true;
    } else if (v1[1] == v2[1]) {
        return v1[0] < v2[0];
    }
    return false;
}

bool pathExists(int w, int h, vector<vector<int>> & portals) {
    // top left = (0, 0)
    // bottom right = (w-1, h-1)
    
    map<pair<int, int>, vector<pair<int, int>>> adjacency;
    map<int, pair<int, int>> colorMap;
    sort(portals.begin(), portals.end(), customCompare);

    if (portals[0][1] != 0) {
        return false;
    } else {
        adjacency[{0, 0}].push_back({portals[0][0], portals[0][1]});
    }
    for (int i = 0; i < portals.size();i ++) {        
        if (i > 0 && portals[i][1] == portals[i-1][1]) {
            adjacency[{portals[i-1][0], portals[i-1][1]}].push_back({portals[i][0], portals[i][1]});
        }
        if (colorMap.find(portals[i][2]) == colorMap.end()) {
            colorMap[portals[i][2]] = {portals[i][0], portals[i][1]};
        } else {
            if (colorMap[portals[i][2]].second != portals[i][1]) {
                adjacency[colorMap[portals[i][2]]].push_back({portals[i][0], portals[i][1]});
                colorMap[portals[i][2]] = {portals[i][0], portals[i][1]};
            }
        }
    }
    if (portals.back()[1] != h-1) {
        return false;
    } else {
        adjacency[{portals.back()[0], portals.back()[1]}].push_back({w-1, h-1});
    }


    // bfs
    queue<pair<int, int>> q;
    set<pair<int, int>> inserted;
    q.push({0, 0});
    inserted.insert({0,0});
    while (!q.empty()) {
        pair<int, int> f = q.front(); q.pop();
        if (f.first == w-1 && f.second == h-1) {
            return true;
        }
        for (const pair<int, int> & next : adjacency[f]) {
            if (inserted.find(next) == inserted.end()) {
                q.push(next);
                inserted.insert(next);
            }
        }
    }
    return false;
}

 
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    #ifndef ONLINE_JUDGE
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif
    
    int T;
    cin >> T;

    while (T--) {
        int W, H; cin >> W >> H;
        int N; cin >> N;
        vector<vector<int>> portals (N, vector<int>(3,0));
        for (int i = 0 ; i < N; i++) {
            cin >> portals[i][0] >> portals[i][1] >> portals[i][2];
        }
        bool ans = pathExists(W, H, portals);
        cout << (ans ? "true" : "false") << '\n';
    }
}