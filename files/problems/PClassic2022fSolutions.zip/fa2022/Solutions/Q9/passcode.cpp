using namespace std;
#include <iostream>
#include <vector>

long long passcode(vector<int> arr, int k) {
	int n = arr.size();
	long long sum = 0;
	for (long long i = 0; i < n; i++) {
		sum += (n - i - 1) * (k * (arr[i] / k));
		sum += i * (arr[i] % k);
	}
	return sum;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(NULL);

	int t;
	cin >> t;

	while (t--) {
		int n, k;
		cin >> n >> k;
		vector<int> arr;
		arr.resize(n);
		for (int i = 0; i < n; i++) {
			cin >> arr[i];
		}
		long long sum = passcode(arr, k);
		cout << sum << endl;
	}
	return 0;
}