#include <bits/stdc++.h>
 
using namespace std;
 
#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n';
#define sz(v) (long long) v.size()
 
#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}
 
typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;
 
const ll inf = 1e18;
 
const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
	T val;
	explicit operator T() const { return val; }
	mi() { val = 0; }
	mi(const long long& v) {
		val = (-MOD <= v && v < MOD) ? v : v % MOD;
		if (val < 0) val += MOD; }
	friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
	friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
	friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
	friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
	mi operator-() const { return mi(-val); }
	mi& operator+=(const mi& m) {
		if ((val += m.val) >= MOD) val -= MOD;
		return *this; }
	mi& operator-=(const mi& m) {
		if ((val -= m.val) < 0) val += MOD;
		return *this; }
	mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
		return *this; }
	friend mi pow(mi a, long long p) {
		mi ans = 1; assert(p >= 0);
		for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
		return ans; }
	friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
	mi& operator/=(const mi& m) { return (*this) *= inv(m); }
	friend mi operator+(mi a, const mi& b) { return a += b; }
	friend mi operator-(mi a, const mi& b) { return a -= b; }
	friend mi operator*(mi a, const mi& b) { return a *= b; }
	friend mi operator/(mi a, const mi& b) { return a /= b; }
};

int curt = 1;
int ot;

void solve() {
	ll n, ladders, robberInit, copInit;
	cin >> n >> ladders >> robberInit >> copInit;

	vl graph[n];
	for (int i = 0; i < n - 1; i++) {
		int u, v; cin >> u >> v;
		graph[u].push_back(v);
		graph[v].push_back(u);
	}

	// find the tree diameter and two leaf endpoints of the diameter

	vector<bool> vis(n);
	vl robberDist(n);
	vl copDist(n);

	queue<pll> q;
	q.push({robberInit, 0});

	int farthest = robberInit;
	robberDist[robberInit] = 0;
	vis[robberInit] = 1;

	while (!q.empty()) {
		pll p = q.front();
		q.pop();
		int v = p.f;
		int d = p.s;
		for (int u: graph[v]) {
			if (!vis[u]) {
				vis[u] = 1;
				robberDist[u] = d + 1;
				q.push({u, d + 1});
				if (robberDist[farthest] < d + 1) {
					farthest = u;
				}
			}
		}
	}

	int l1 = farthest;
	fill(vis.begin(), vis.end(), 0);

	q.push({copInit, 0});
	copDist[copInit] = 0;
	vis[copInit] = 1;

	while (!q.empty()) {
		pll p = q.front();
		q.pop();
		for (int u: graph[p.f]) {
			if (!vis[u]) {
				vis[u] = 1;
				copDist[u] = p.s + 1;
				q.push({u, p.s + 1});
			}
		}
	}

	if (ladders == 0) {
		ll ret = 0;
		for (int i = 0; i < n; i++) {
			if (copDist[i] > robberDist[i]) {
				ret = max(ret, copDist[i]);
			}
		}

		cout << ret << nl;
		return;
	}

	// two more bfs to do D:
	vl distL1(n);
	fill(vis.begin(), vis.end(), 0);

	q.push({l1, 0});
	distL1[l1] = 0;
	vis[l1] = 1;

	farthest = l1;

	while (!q.empty()) {
		pll p = q.front();
		q.pop();
		for (int u: graph[p.f]) {
			if (!vis[u]) {
				vis[u] = 1;
				distL1[u] = p.s + 1;
				q.push({u, p.s + 1});
				if (p.s + 1 > distL1[farthest]) {
					farthest = u;
				}
			}
		}
	}

	ll diameter = distL1[farthest];


	// second leaf in the diameter
	int l2 = farthest;

	vl distL2(n);

	fill(vis.begin(), vis.end(), 0);

	q.push({l2, 0});
	distL2[l2] = 0;
	vis[l2] = 1;

	farthest = l2;

	while (!q.empty()) {
		pll p = q.front();
		q.pop();
		for (int u: graph[p.f]) {
			if (!vis[u]) {
				vis[u] = 1;
				distL2[u] = p.s + 1;
				q.push({u, p.s + 1});
				if (p.s + 1 > distL2[farthest]) {
					farthest = u;
				}
			}
		}
	}

	ll ret = 0;
	// use one ladder
	for (int i = 0; i < n; i++) {
		if (robberDist[i] < copDist[i]) {
			// we can assume that a leaf would be better
			ll tmp = max(0LL, max(distL1[i], distL2[i]) - 2);
			ret = max(ret, copDist[i] - 1 + tmp);
		}
	}

	ret += 1 + ll (ladders - 1) * (diameter - 2);

	cout << ret << nl;
}


int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL);

	int t; cin >> t;
	ot = t;
	while (t--) {
		solve();
		curt++;
	}	
}