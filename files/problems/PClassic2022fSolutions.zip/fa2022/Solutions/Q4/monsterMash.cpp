#include <bits/stdc++.h>

using namespace std;

vector<int> monsterMash(vector<int> v, int k) {
    stack<int> monstack;
    stack<int> numstack;
    
    for (int m : v) {
        
        if (!monstack.empty() && m == monstack.top()) {
            monstack.push(m);
            int t = numstack.top();
            numstack.pop();
            numstack.push(t+1);

            if (numstack.top() == k) {
                int n = numstack.top();
                numstack.pop();
                while (n > 0) {
                    monstack.pop();
                    n--;
                }
            }
        } else {
            monstack.push(m);
            numstack.push(1);
        }
    }

    
    vector<int> rev;
    while(!monstack.empty()) {
        rev.push_back(monstack.top());
        monstack.pop();
    }
    
    reverse(rev.begin(), rev.end());
    return rev;
}

 
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int T;
    cin >> T;

    while (T--) {
        int N; 
        cin >> N;
        vector<int> arr (N);
        for (int i = 0; i < N; i++) {
            cin>>arr[i];
        }
        int K;
        cin >> K;
        vector<int> m = monsterMash(arr, K);
        if (m.size() == 0) {
            cout<<"[]"<<endl;
            continue;
        }
        cout<<'[';
        for (int i = 0; i< m.size()-1; i++) {
            cout<<m[i]<<", ";
        }
        
        if (m.size() > 0) {
            cout<<m[m.size() -1];
        }
        cout<<']'<<endl;

    }
}