#include <bits/stdc++.h>
 
using namespace std;
 
/* Return the shortest time required to print a string given 1 copy operation */
int molasses(int n, char c[], int l[])
{
    //normalize lengths
    
    
    vector<int> v[3];
    int tot = 0, mx[3] = {0,0,0};
    int cur = 0;
    for(int i = 0; i < n; i++)
    {
        tot += l[i];
        int p = (int)c[i]-97;
        cur += l[i];
        if(i == n-1 || c[i+1] != c[i])
        {
            v[p].push_back(cur);
            mx[p] = max(mx[p], cur);
            cur = 0;
        }
    }
    
    for (int i = 0; i < 3; i++) {
        sort(v[i].begin(), v[i].end());
    }
    
    //brute force
    
    
    int mn = tot;
    for(int m = 0; m < 3; m++)
    {
        int curIdx = 0;
        int tc = 2;
        while(tc <= mx[m])
        {
            int res = tot;
            bool f = false;
            //try to copy a length of tc
            for(int i = curIdx; i < v[m].size(); i++)
            {
                if(v[m][i] >= tc)
                {
                    int mult = v[m][i] / tc;
                    if(f)
                    {
                        res -= (mult * (tc-1));
                    }
                    else //initial time takes effort D;
                    {
                        res -= (((mult - 1) * (tc-1))-1);
                        f = true;
                    }
                    
                } else {
                    curIdx++;
                }
            }
            mn = min(mn, res); 
            tc++;
        }
    }
    
    return mn;
}
 
 
 
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(NULL);
    int T,n;
    cin >> T;
    while(T--)
    {
        cin >> n;
        char c[n];
        int l[n];
        for(int i = 0; i < n; i++) cin >> c[i];
        for(int i = 0; i < n; i++) cin >> l[i];
	    cout << molasses(n, c, l) << "\n";
    }
}