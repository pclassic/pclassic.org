#include <bits/stdc++.h>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n'
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
    T val;
    explicit operator T() const { return val; }
    mi() { val = 0; }
    mi(const long long& v) {
        val = (-MOD <= v && v < MOD) ? v : v % MOD;
        if (val < 0) val += MOD; }
    friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
    friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
    friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
    friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
    mi operator-() const { return mi(-val); }
    mi& operator+=(const mi& m) {
        if ((val += m.val) >= MOD) val -= MOD;
        return *this; }
    mi& operator-=(const mi& m) {
        if ((val -= m.val) < 0) val += MOD;
        return *this; }
    mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
        return *this; }
    friend mi pow(mi a, long long p) {
        mi ans = 1; assert(p >= 0);
        for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
        return ans; }
    friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
    mi& operator/=(const mi& m) { return (*this) *= inv(m); }
    friend mi operator+(mi a, const mi& b) { return a += b; }
    friend mi operator-(mi a, const mi& b) { return a -= b; }
    friend mi operator*(mi a, const mi& b) { return a *= b; }
    friend mi operator/(mi a, const mi& b) { return a /= b; }
};

struct DSU {
    vi par, sz;
    vl nobjects, area;

    void init(int n) {
        par = vi(n);
        sz = vi(n);
        nobjects = vl(n);
        area = vl(n);

        for (int i=0; i<n; i++) {
            par[i] = i;
            sz[i] = 1;
            nobjects[i] = 0;
            area[i] = 0;
        }
    }

    int findRoot(int u) {
        if (u != par[u])
            par[u] = findRoot(par[u]);
        return par[u];
    }

    bool unite(int u, int v) {
        u = findRoot(u);
        v = findRoot(v);
        if (u == v)
            return false;
        if (sz[u] < sz[v])
            swap(u, v);

        area[u] += area[v];
        nobjects[u] += nobjects[v];

        par[v] = u;
        sz[u] += sz[v];
        return true;
    }

    void update(int u, ll dA, ll dO) {
        area[findRoot(u)] += dA;
        nobjects[findRoot(u)] += dO;
    }

    ll getArea(int u) {
        return area[findRoot(u)];
    }

    ll getObjects(int u) {
        return nobjects[findRoot(u)];
    }
};

int dr[] = {0, 1, 0, -1};
int dc[] = {1, 0, -1, 0};

void solve() {
    ll r, c; cin >> r >> c;
    int n, k; cin >> n >> k;

    ll walls[n][4];
    ll objects[k][2];

    set<ll> xcoords, ycoords;

    xcoords.insert(0);
    xcoords.insert(c);

    ycoords.insert(0);
    ycoords.insert(r);

    for (int i = 0; i < n; i++) {
        cin >> walls[i][0] >> walls[i][1] >> walls[i][2] >> walls[i][3];

        swap(walls[i][0], walls[i][1]);
        swap(walls[i][2], walls[i][3]);

        xcoords.insert(walls[i][0]);
        xcoords.insert(walls[i][2]);
        ycoords.insert(walls[i][1]);
        ycoords.insert(walls[i][3]);
    }

    int nx = xcoords.size();
    int ny = ycoords.size();
    
    // real x coord to compressed x coord
    // real y coord to compressed y coord 
    map<ll, ll> rxc, ryc;

    // un-compress
    ll cxr[nx], cyr[ny];

    int curx = 0;
    for (ll xc: xcoords) {
        rxc[xc] = curx;
        cxr[curx++] = xc;
    }
    int cury = 0;
    for (ll yc: ycoords) {
        ryc[yc] = cury;
        cyr[cury++] = yc;
    }

    // 0 -> no wall, 1 -> wall
    bool grid[2 * ny - 1][2 * nx - 1];

    int numR = ny - 1, numC = nx - 1;

    ll area[numR][numC];
    vl numObjects[numR][numC];

    ms(grid, 0); 
    ms(numObjects, 0);
    
    for (int row = 0; row < numR; row++) {
        ll dy = cyr[row + 1] - cyr[row];
        for (int col = 0; col < numC; col++) {
            ll dx = cxr[col + 1] - cxr[col];
            area[row][col] = dx * dy;
        }
    }

    f0r(i, n) {
        ll x1 = rxc[walls[i][0]];
        ll y1 = ryc[walls[i][1]];

        ll x2 = rxc[walls[i][2]];
        ll y2 = ryc[walls[i][3]];

        if (x1 == x2) {
            if (y2 < y1) swap(y2, y1);
            for (int row = 2 * y1; row <= 2 * y2; row++) {
                grid[row][2 * x1] = 1;
            }
        } else {
            assert(y1 == y2);
            if (x2 < x1) swap(x2, x1);
            for (int col = 2 * x1; col <= 2 * x2; col++) {
                grid[2 * y1][col] = 1;
            }
        }
    }

    // add in the outside walls
    f0r(i, 2 * ny - 1) {
        grid[i][0] = 1;
        grid[i][2 * nx - 2] = 1;
    }

    f0r(i, 2 * nx - 1) {
        grid[0][i] = 1;
        grid[2 * ny - 2][i] = 1;
    }

    // load in the objects
    f0r(i, k) {
        cin >> objects[i][0] >> objects[i][1];
        swap(objects[i][0], objects[i][1]);

        int cx = rxc[*prev(upper_bound(xcoords.begin(), xcoords.end(), objects[i][0]))];
        int cy = ryc[*prev(upper_bound(ycoords.begin(), ycoords.end(), objects[i][1]))];
        
        numObjects[cy][cx].pb(objects[i][1]);
    }

    // regions
    // top, bottom, area, number of objects, region size
    vector<vl> regions;

    // cell numbering within each region
    int cnum[numR][numC];

    // do bfs
    // row, col
    queue<pll> q;
    vector<vector<int>> vis(numR, vector<int>(numC));

    int regionNum = 1;

    ll mx = 0;

    for (int row = 0; row < numR; row++) {
        for (int col = 0; col < numC; col++) {
            if (!vis[row][col]) {
                ll curArea = 0;
                ll no = 0;

                vis[row][col] = regionNum;
                
                vpl objectsYx;

                // maximize row
                int topRow = row;
                // minimize row
                int botRow = row;

                int numCells = 0;

                q.push({row, col});

                while (!q.empty()) {
                    pll pos = q.front();
                    q.pop();

                    int curr = pos.f, curc = pos.s;
                    int curr2 = curr * 2 + 1, curc2 = curc * 2 + 1;

                    curArea += area[curr][curc];
                    no += numObjects[curr][curc].size();

                    cnum[curr][curc] = numCells;
                    numCells++;

                    topRow = max(topRow, curr);
                    botRow = min(botRow, curr);

                    for (int d = 0; d < 4; d++) {
                        int ncurr = curr + dr[d];
                        int ncurc = curc + dc[d];

                        int ncurr2 = curr2 + dr[d];
                        int ncurc2 = curc2 + dc[d];
                        if (!grid[ncurr2][ncurc2]) {
                            if (!vis[ncurr][ncurc]) {
                                vis[ncurr][ncurc] = regionNum;
                                q.push({ncurr, ncurc});
                            }
                        }
                    }
                }

                regions.pb({topRow, botRow, curArea, no, numCells});
                
                mx = max(mx, curArea * no);

                regionNum++;
            }
        }
    }

    ll best = mx;

    // debug prints
    /*f0r(i, 2 * ny - 1) {
        int asdf = 2 * ny - 1 - i - 1;
        f0r(j, 2 * nx - 1) {
            cout << grid[asdf][j] << " ";
        }
        cout << endl;
    }

    // easy version ends here
    cout << best << endl;*/

    // minimax

    // binary search on the answer
    ll rl = 0, rr = mx;

    while (rl <= rr) {
        ll m = (rl + rr) / 2;

        bool works = 1;

        // do shit
        ll intervalMin = 0;
        ll intervalMax = r + 1;

        regionNum = 1;
        
        for (auto region: regions) {
            if (region[2] * region[3] <= m) {
                regionNum++;
                continue;
            }

            // go from up to down
            int top = region[0];
            int bot = region[1];

            ll realLowest, realHighest;

            {
                // region[4] is the number of cells in the region
                int numCells = region[4];
                DSU d; d.init(numCells);
                
                // the one we care about
                ll lowest = cyr[top + 1];

                // a section contains a representitive column, the width, and the object y coords
                vector<pair<pll, vl>> sections;

                int curSec = 0;
                ll curWidth = 0;
                vl curObjects;

                // do the first row
                for (int col = 0; col < numC; col++) {
                    if (vis[top][col] == regionNum) {
                        // start of new section
                        if (grid[2 * top + 1][2 * col + 2] || vis[top][col + 1] != regionNum) {
                            curWidth += cxr[col + 1] - cxr[col]; 
                            curObjects.insert(curObjects.end(), numObjects[top][col].begin(), numObjects[top][col].end());
                               
                            curSec++;
                            sections.pb({{col, curWidth}, curObjects});
                            curObjects.clear();
                            curWidth = 0;
                        } else {
                            d.unite(cnum[top][col], cnum[top][col + 1]);
                            curObjects.insert(curObjects.end(), numObjects[top][col].begin(), numObjects[top][col].end());
                            curWidth += cxr[col + 1] - cxr[col];
                        }
                    }
                }

                
                ll height = cyr[top + 1] - cyr[top];
                ll highest = 0;

                bool cont = 1;

                for (auto sec: sections) {
                    int root = d.findRoot(cnum[top][sec.f.f]);
                    ll width = sec.f.s;
                    vl objs = sec.s;
                    int no = sz(objs);

                    sort(objs.begin(), objs.end(), greater<ll>());

                    if ((ll) objs.size() * width * height <= m) {
                        d.update(root, width * height, objs.size());
                    } else {
                        ll curlowest = objs[0] + 1;
                        int curIdx = 0;
                        int curNo = 0;
                        ll cur = objs[0];

                        while (curIdx < no) {
                            cur = objs[curIdx];
                            while (curIdx < no && objs[curIdx] == cur) {
                                curNo++;
                                curIdx++;
                            }
                            // if we include and die, then rip
                            height = cyr[top + 1] - cur;
                            if (height * width * curNo > m) {
                                break;
                            } else {
                                ll len = m / (width * curNo);
                                
                                if (curIdx == no) {
                                    curlowest = min(curlowest, cyr[top + 1] - len);
                                } else {
                                    curlowest = min(curlowest, max(cyr[top + 1] - len, objs[curIdx] + 1));
                                }
                            }
                        }

                        highest = max(highest, curlowest);
                        cont = 0;
                    }
                }

                lowest = highest;

                for (int row = top - 1; row >= bot; row--) {
                    if (!cont) {
                        break;
                    }

                    sections.clear();

                    curSec = 0;
                    curWidth = 0;
                    curObjects.clear();

                    // do the next row
                    for (int col = 0; col < numC; col++) {
                        if (vis[row][col] == regionNum) {
                            if (!grid[2 * row + 2][2 * col + 1] && vis[row + 1][col] == regionNum) {
                                d.unite(cnum[row + 1][col], cnum[row][col]);
                            }

                            if (grid[2 * row + 1][2 * col + 2] || vis[row][col + 1] != regionNum) {
                                curWidth += cxr[col + 1] - cxr[col]; 
                                curObjects.insert(curObjects.end(), numObjects[row][col].begin(), numObjects[row][col].end());
                                
                                curSec++;
                                sections.pb({{col, curWidth}, curObjects});
                                curObjects.clear();
                                curWidth = 0;
                            } else {
                                d.unite(cnum[row][col], cnum[row][col + 1]);
                                curObjects.insert(curObjects.end(), numObjects[row][col].begin(), numObjects[row][col].end());
                                curWidth += cxr[col + 1] - cxr[col];
                            }
                        }
                    }

                    // combine the sections that have the same root in d
                    set<int> rootSet;
                    map<int, pair<ll, vl>> rootObjs;

                    for (auto sec: sections) {
                        int root = d.findRoot(cnum[row][sec.f.f]);
                        ll secWidth = sec.f.s;
                        // not in set yet
                        if (rootSet.find(root) == rootSet.end()) {
                            rootSet.insert(root);
                            rootObjs[root] = {secWidth, sec.s};
                        } else {
                            rootObjs[root].f += secWidth;
                            rootObjs[root].s.insert(rootObjs[root].s.end(), sec.s.begin(), sec.s.end());
                        }
                    }

                    highest = 0;

                    for (int root: rootSet) {
                        auto tmp = rootObjs[root];
                        ll width = tmp.f;
                        vl objs = tmp.s;
                        ll tobjs = objs.size();

                        ll curA = d.getArea(root);
                        ll curNobs = d.getObjects(root);

                        height = cyr[row + 1] - cyr[row];


                        if (curA * curNobs + curA * tobjs + tobjs * height * width + curNobs * height * width <= m) {
                            d.update(root, width * height, tobjs);

                        } else {

                            ll curlowest = cyr[row + 1];
                            int curIdx = 0;
                            int curNo = 0;

                            if (sz(objs) > 0) {
                                sort(objs.begin(), objs.end(), greater<ll>());
                            }

                            ll cur = cyr[row + 1];

                            do {
                                if (curIdx == tobjs) {
                                    height = cyr[row + 1] - cyr[row];
                                } else {
                                    height = cyr[row + 1] - objs[curIdx] - 1;
                                }

                                 if (height * width * (curNo + curNobs) + curA * (curNo + curNobs) > m) {

                                    ll len = (m - (curA * (curNo + curNobs))) / (width * (curNo + curNobs));
                                    if (curIdx == tobjs) {
                                        curlowest = min(curlowest, cyr[row + 1] - len);
                                    } else {
                                        curlowest = min(curlowest, max(cyr[row + 1] - len, objs[curIdx]));
                                    }
                                    break;
                                } else {
                                    curlowest = objs[curIdx] + 1;
                                }

                                cur = objs[curIdx];
                                while (curIdx < tobjs && objs[curIdx] == cur) {
                                    curNo++;
                                    curIdx++;
                                }

                            } while (curIdx <= tobjs);

                            cont = 0;
                            highest = max(highest, curlowest);
                        }
                    }

                    lowest = highest;
                }

                realLowest = lowest;
            }

            //cout << "REAL LOWEST " << realLowest << endl;

            // go from down to up

            {
                // region[4] is the number of cells in the region
                int numCells = region[4];
                DSU d; d.init(numCells);
                
                // the one we care about
                ll highest = cyr[bot];

                // a section contains a representitive column, the width, and the object y coords
                vector<pair<pll, vl>> sections;

                int curSec = 0;
                ll curWidth = 0;
                vl curObjects;

                // do the lastrow
                for (int col = 0; col < numC; col++) {
                    if (vis[bot][col] == regionNum) {
                        // start of new section
                        if (grid[2 * bot + 1][2 * col + 2] || vis[bot][col + 1] != regionNum) {
                            curWidth += cxr[col + 1] - cxr[col]; 
                            curObjects.insert(curObjects.end(), numObjects[bot][col].begin(), numObjects[bot][col].end());

                            curSec++;
                            sections.pb({{col, curWidth}, curObjects});
                            curObjects.clear();
                            curWidth = 0;
                        } else {
                            d.unite(cnum[bot][col], cnum[bot][col + 1]);
                            curObjects.insert(curObjects.end(), numObjects[bot][col].begin(), numObjects[bot][col].end());
                            curWidth += cxr[col + 1] - cxr[col];
                        }
                    }
                }

                ll height = cyr[bot + 1] - cyr[bot];

                ll lowest = r + 1;
                bool cont = 1;

                for (auto sec: sections) {
                    int root = d.findRoot(cnum[bot][sec.f.f]);
                    ll width = sec.f.s;
                    vl objs = sec.s;
                    int no = sz(objs);

                    sort(objs.begin(), objs.end());

                    if ((ll) objs.size() * width * height <= m) {
                        d.update(root, width * height, objs.size());
                    } else {
                        ll curhighest = objs[0];
                        int curIdx = 0;
                        int curNo = 0;
                        ll cur = objs[0];

                        while (curIdx < no) {
                            cur = objs[curIdx];
                            while (curIdx < no && objs[curIdx] == cur) {
                                curNo++;
                                curIdx++;
                            }
                            // if we include and die, then rip
                            height = cur + 1 - cyr[bot];
                            if (height * width * curNo > m) {
                                break;
                            } else {
                                ll len = m / (width * curNo);
                                
                                if (curIdx == no) {
                                    curhighest = max(curhighest, cyr[bot] + len);
                                } else {
                                    curhighest = max(curhighest, min(cyr[bot] + len, objs[curIdx]));
                                }
                            }
                        }

                        lowest = min(lowest, curhighest);
                        cont = 0;
                    }
                }

                highest = lowest;

                for (int row = bot + 1; row <= top; row++) {
                    if (!cont) {
                        break;
                    }

                    sections.clear();

                    curSec = 0;
                    curWidth = 0;
                    curObjects.clear();

                    // do the next row
                    for (int col = 0; col < numC; col++) {
                        if (vis[row][col] == regionNum) {
                            if (!grid[2 * row][2 * col + 1] && vis[row - 1][col] == regionNum) {
                                d.unite(cnum[row - 1][col], cnum[row][col]);
                            }

                            // start of new section
                            if (grid[2 * row + 1][2 * col + 2] || vis[row][col + 1] != regionNum) {
                                curWidth += cxr[col + 1] - cxr[col]; 
                                curObjects.insert(curObjects.end(), numObjects[row][col].begin(), numObjects[row][col].end());
                               
                                curSec++;
                                sections.pb({{col, curWidth}, curObjects});
                                curObjects.clear();
                                curWidth = 0;
                            } else {
                                d.unite(cnum[row][col], cnum[row][col + 1]);
                                curObjects.insert(curObjects.end(), numObjects[row][col].begin(), numObjects[row][col].end());
                                curWidth += cxr[col + 1] - cxr[col];
                            }
                        }
                    }

                    // combine the sections that have the same root in d
                    set<int> rootSet;
                    map<int, pair<ll, vl>> rootObjs;

                    for (auto sec: sections) {
                        int root = d.findRoot(cnum[row][sec.f.f]);
                        ll secWidth = sec.f.s;
                        // not in set yet
                        if (rootSet.find(root) == rootSet.end()) {
                            rootSet.insert(root);
                            rootObjs[root] = {secWidth, sec.s};
                        } else {
                            rootObjs[root].f += secWidth;
                            rootObjs[root].s.insert(rootObjs[root].s.end(), sec.s.begin(), sec.s.end());
                        }
                    }

                    lowest = r + 1;

                    for (int root: rootSet) {
                        auto tmp = rootObjs[root];
                        ll width = tmp.f;
                        vl objs = tmp.s;
                        ll tobjs = objs.size();

                        ll curA = d.getArea(root);
                        ll curNobs = d.getObjects(root);

                        height = cyr[row + 1] - cyr[row];

                        if (curA * curNobs + curA * tobjs + tobjs * height * width + curNobs * height * width <= m) {
                            d.update(root, width * height, tobjs);
                        } else {

                            ll curhighest = cyr[row];
                            int curIdx = 0;
                            int curNo = 0;

                            if (tobjs > 0) {
                                sort(objs.begin(), objs.end());
                            }
                            ll cur = cyr[row];

                            do {
                                if (curIdx == tobjs) {
                                    height = cyr[row + 1] - cyr[row];
                                } else {
                                    height = objs[curIdx] - cyr[row];
                                }

                                // while we can grab these objects 
                                if (height * width * (curNo + curNobs) + curA * (curNo + curNobs) > m) {                         
                                    ll len = (m - (curA * (curNo + curNobs))) / (width * (curNo + curNobs));
                                    if (curIdx == tobjs) {
                                        curhighest = max(curhighest, cyr[row] + len);
                                    } else {
                                        curhighest = max(curhighest, min(cyr[row] + len, objs[curIdx]));
                                    }
                                    break;
                                } else {
                                    curhighest = objs[curIdx];
                                }

                                cur = objs[curIdx];
                                while (curIdx < tobjs && objs[curIdx] == cur) {
                                    curNo++;
                                    curIdx++;
                                }

                            } while (curIdx <= tobjs);

                            cont = 0;
                            lowest = min(lowest, curhighest);
                        }
                    }

                    highest = lowest;
                }

                realHighest = highest;
            }

            /*cout << "hey" << endl;
            cout << realLowest << " " << realHighest << endl;*/

            if (realHighest < realLowest || realLowest > intervalMax || realHighest < intervalMin) {
                works = 0;
                break;
            }

            intervalMax = min(intervalMax, realHighest);
            intervalMin = max(intervalMin, realLowest);
        
            regionNum++;
        }

        if (works) {
            best = min(best, m);
            rr = m - 1;
        } else {
            rl = m + 1;
        }
    }

    cout << best << nl;
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(NULL);

    int t = 1;
    while (t--) {
        solve();
    }
}