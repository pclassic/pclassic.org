#include <iostream>

using namespace std;

int findWidestMountain(int n, int arr[])
{
    int max_incr_length = 0;
    int curr = 1;
    bool inc = true;
    for (int i = 1; i < n; i++)
    {
        // Either strinctly increasing or decreasing
        if ((inc && arr[i] > arr[i - 1]) || (!inc && arr[i] < arr[i - 1]))
        {
            curr++;
        }
        // Top of the mountain, needs to start decreasing
        else if (inc && arr[i] < arr[i - 1] && (curr > 1))
        {
            inc = false;
            curr++;
        }
        // End of the mountain.
        else
        {
            if (!inc)
                max_incr_length = max(curr, max_incr_length);
            curr = 1;
            // Check if prev element could be a start of a new mountain
            if (arr[i] > arr[i - 1])
                curr++;
            inc = true;
        }
    }

    // Last mountain has a decrease
    if (!inc)
        max_incr_length = max(curr, max_incr_length);

    if (max_incr_length == 1)
    {
        return 0;
    }

    return max_incr_length;
}

int main()
{
    int t;
    cin >> t;

    while (t > 0)
    {
        t--;
        int n;
        int x;
        cin >> n;
        int array[n];

        for (int i = 0; i < n; i++)
        {
            cin >> x;
            array[i] = x;
        }

        cout << findWidestMountain(n, array) << endl;
    }
}
