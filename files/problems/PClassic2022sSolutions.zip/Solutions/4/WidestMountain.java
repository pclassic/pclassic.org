/* package codechef; // don't place package name! */

import java.util.*;
import java.lang.*;
import java.io.*;

/* Name of the class has to be "Main" only if the class is public. */
class Codechef
{
	public static int findWidestMountain(int n, int[] arr) {
		int maxLength = 0; // arr.length > 0? 1 : 0;
		int currCount = 1;
		boolean mtIncrease = false; // if this mt has already inclined
		boolean mtDecrease = false; // if this mt has already declined
		for (int i = 1; i < n; i++) {
			if (arr[i - 1] < arr[i]) { // incline
				if (mtDecrease) { // starting new mountain
					// maxLength = Math.max(maxLength, currCount);
					currCount = 1;
					mtDecrease = false;
				} // else not starting new mountain (strict inc)
				currCount++;
				mtIncrease = true;
			} else if (arr[i - 1] == arr[i]) { // plateau
			    mtIncrease = false;
			    mtDecrease = true; // allows for new mt start
			} else { // decline
				if (mtIncrease) { // declining after already inclining
					currCount++;
					mtDecrease = true;
					maxLength = Math.max(maxLength, currCount);
				} else {
					// this case doesn't count for anything
				}
			}
		}
		
		return maxLength;
	}

	public static void main(String[] args) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.valueOf(reader.readLine()); // read # of test cases
		
		for (int i = 0; i < t; i++) {
			int length = Integer.valueOf(reader.readLine()); // read length of array
			int[] arr = new int[length];
			String input = reader.readLine(); // read array
			String[] str = input.split(" ");
			for (int a = 0; a < length; a++) {
				arr[a] = Integer.valueOf(str[a]);
			}
			int output = findWidestMountain(length, arr);
			System.out.println(output);
		}

	}
}
