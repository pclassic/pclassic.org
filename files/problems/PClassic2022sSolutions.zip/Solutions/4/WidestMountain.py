def findWidestMountain(n, mountainRange):
    inc = [0] * n
    dec = [0] * n

    #two pointers to calculate inc array
    l = 0
    r = 0
    while (r < n):
        if (l == r):
            r += 1
            continue
       
        if (mountainRange[r] > mountainRange[r - 1]):
            r += 1
        else:
            inc[l] = r - l
            l += 1

    while (l < r):
        inc[l] = r - l
        l += 1

    #two pointers to calculate dec array
    l = 0
    r = 0
    while (r < n):
        if (l == r):
            r += 1
            continue
       
        if (mountainRange[r] < mountainRange[r - 1]):
            r += 1
        else:
            dec[l] = r - l
            l += 1

    while (l < r):
        dec[l] = r - l
        l += 1

    #print(inc)
    #print(dec)

    #find the best answer
    best = 0

    for i in range(n):
        if (inc[i] != 1):
            if (dec[i + inc[i] - 1] != 1):
                best = max(best, inc[i] + dec[i + inc[i] - 1] - 1)

    return best


# Do not modify below this line
if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        length = int(input().strip())
        arr = input().strip().split(' ')
        for i in range(length):
            arr[i] = int(arr[i])
        print(findWidestMountain(length, arr))