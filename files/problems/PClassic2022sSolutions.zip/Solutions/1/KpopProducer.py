def danceCommand(s, arr):
    shift = 0
    for elmt in arr:
        shift += elmt
    shift = shift % len(s)
    shift = (shift + len(s)) % len(s)
    shifted = s[(len(s) - shift):]
    shifted += s[0:(len(s) - shift)]
    return shifted


# Do not modify below this line
if __name__ == "__main__":
    tests = int(input())
    for test in range(tests):
        s = input()
        length = int(input().strip())
        arr = input().strip().split(' ')
        for i in range(length):
            arr[i] = int(arr[i])
        output = danceCommand(s, arr)
        print(output)
