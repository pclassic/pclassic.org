#include <string>
#include <iostream>
#include <vector>
using namespace std;

string danceCommand(string word, vector<int> shifts) {
    long shift = 0;
    for (int i = 0; i < shifts.size(); i++) {
        shift += shifts[i];
    }

    int length = word.length();
    shift = shift % length;
    if (shift == 0)
        return word;

    string part1 = word.substr(length - shift, shift);
    string part2 = word.substr(0, length - shift);
    return part1 + part2;
}

int main() {
    int t;
    cin >> t;
    while (t-- > 0) {
        string word;
        cin >> word;
        int length;
        cin >> length;
        string line;
        vector<int> shifts;
        shifts.resize(length);
        for (int i = 0; i < length; i++) {
            std::cin >> shifts[i];
        }
        std::cout << danceCommand(word, shifts) << std::endl;

    }
}