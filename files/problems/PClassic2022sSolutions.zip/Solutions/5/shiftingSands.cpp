#include <iostream>
#include <vector>
#include <sstream>
using namespace std;

vector<string> tokenize(string s)
{
    vector<string> tokens;
    stringstream ss(s);
    string word;

    while (ss >> word)
    {
        tokens.push_back(word);
    }
    return tokens;
}

vector<vector<int>> create_new_board()
{
    vector<vector<int>> new_board;
    for (int i = 0; i < 4; i++)
    {
        new_board.push_back(vector<int>(4, 0));
    }

    return new_board;
}

vector<vector<int>> compress(vector<vector<int>> board)
{
    vector<vector<int>> new_board = create_new_board();

    for (int i = 0; i < 4; i++)
    {
        int pos = 0;
        for (int j = 0; j < 4; j++)
        {
            if (board[i][j] != 0)
            {
                new_board[i][pos] = board[i][j];
                pos += 1;
            }
        }
    }
    return new_board;
}

vector<vector<int>> merge(vector<vector<int>> board)
{
    vector<vector<int>> new_board = create_new_board();
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
            new_board[i][j] = board[i][j];
    }

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (new_board[i][j] == new_board[i][j + 1] && new_board[i][j] != 0)
            {
                new_board[i][j] = board[i][j] * 2;
                new_board[i][j + 1] = 0;
            }
        }
    }

    return new_board;
}

vector<vector<int>> reverse(vector<vector<int>> board)
{
    vector<vector<int>> new_board = create_new_board();
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
            new_board[i][j] = board[i][3 - j];
    }
    return new_board;
}

vector<vector<int>> transpose(vector<vector<int>> board)
{
    vector<vector<int>> new_board = create_new_board();
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 4; j++)
            new_board[i][j] = board[j][i];
    }
    return new_board;
}

vector<vector<int>> move_west(vector<vector<int>> board)
{
    vector<vector<int>> new_board = compress(board);
    new_board = merge(new_board);
    new_board = compress(new_board);

    return new_board;
}

vector<vector<int>> move_east(vector<vector<int>> board)
{
    vector<vector<int>> new_board = reverse(board);
    new_board = move_west(new_board);
    new_board = reverse(new_board);

    return new_board;
}

vector<vector<int>> move_north(vector<vector<int>> board)
{
    vector<vector<int>> new_board = transpose(board);
    new_board = move_west(new_board);
    new_board = transpose(new_board);

    return new_board;
}

vector<vector<int>> move_south(vector<vector<int>> board)
{
    vector<vector<int>> new_board = transpose(board);
    new_board = move_east(new_board);
    new_board = transpose(new_board);

    return new_board;
}

vector<vector<int>> make_moves(vector<vector<int>> board, vector<string> moves)
{

    for (int i = 0; i < moves.size(); i++)
    {
        string m = moves[i];

        if (m.compare("N") == 0)
            board = move_north(board);

        if (m.compare("S") == 0)
            board = move_south(board);

        if (m.compare("W") == 0)
            board = move_west(board);

        if (m.compare("E") == 0)
            board = move_east(board);
    }

    return board;
}

vector<vector<int>> shiftingsands(vector<vector<int>> board, vector<string> moves)
{
    vector<vector<int>> new_board = make_moves(board, moves);

    return new_board;
}

// Do not modify below this line
int main()
{
    string s;
    int t;
    getline(cin, s);
    t = stoi(s);

    for (int i = 0; i < t; i++)
    {
        vector<vector<int>> board;
        int x;

        for (int j = 0; j < 4; j++)
        {
            vector<int> vector_row;
            getline(cin, s);
            vector<string> vector_row_str = tokenize(s);
            for (int k = 0; k < 4; k++)
            {
                vector_row.push_back(stoi(vector_row_str[k]));
            }
            board.push_back(vector_row);
        }

        vector<string> moves;
        std::getline(cin, s);
        moves = tokenize(s);

        vector<vector<int>> output = shiftingsands(board, moves);
        for (int j = 0; j < 4; j++)
        {
            for (int k = 0; k < 4; k++)
            {
                cout << output[j][k] << " ";
            }
            cout << endl;
        }
    }
}
