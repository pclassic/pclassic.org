import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

    public static int[][] make_moves(int[][] board, String[] moves) {

        for (String m : moves) {

            if (m.equals("N"))
                board = move_north(board);

            if (m.equals("S"))
                board = move_south(board);

            if (m.equals("W"))
                board = move_west(board);

            if (m.equals("E")) {
                board = move_east(board);

            }
        }

        return board;
    }

    public static int[][] move_west(int[][] board) {
        int[][] new_board = compress(board);
        new_board = merge(new_board);
        new_board = compress(new_board);

        return new_board;
    }

    public static int[][] move_east(int[][] board) {
        int[][] new_board = reverse(board);
        new_board = move_west(new_board);
        new_board = reverse(new_board);

        return new_board;
    }

    public static int[][] move_north(int[][] board) {
        int[][] new_board = transpose(board);
        new_board = move_west(new_board);
        new_board = transpose(new_board);

        return new_board;
    }

    public static int[][] move_south(int[][] board) {
        int[][] new_board = transpose(board);
        new_board = move_east(new_board);
        new_board = transpose(new_board);

        return new_board;
    }

    public static int[][] compress(int[][] board) {
        int[][] new_board = new int[5][5];

        for (int i = 0; i < 4; i++) {
            int pos = 0;
            for (int j = 0; j < 4; j++) {
                if (board[i][j] != 0) {
                    new_board[i][pos] = board[i][j];
                    pos += 1;
                }
            }
        }
        return new_board;
    }

    public static int[][] merge(int[][] board) {

        int[][] new_board = new int[5][5];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++)
                new_board[i][j] = board[i][j];
        }

        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 3; j++) {
                if (new_board[i][j] == new_board[i][j + 1] && new_board[i][j] != 0) {
                    new_board[i][j] = board[i][j] * 2;
                    new_board[i][j + 1] = 0;
                }
            }
        }

        return new_board;
    }

    public static int[][] reverse(int[][] board) {
        int[][] new_board = new int[5][5];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++)
                new_board[i][j] = board[i][3 - j];
        }
        return new_board;

    }

    public static int[][] transpose(int[][] board) {
        int[][] new_board = new int[5][5];
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++)
                new_board[i][j] = board[j][i];
        }
        return new_board;
    }

    public static int[][] shiftingSands(int[][] board, String[] moves) {
        int[][] new_board = make_moves(board, moves);

        return new_board;
    }

    // Do not modify below this line
    public static void main(String args[]) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.valueOf(reader.readLine());

        for (int i = 0; i < t; i++) {
            int[][] board = new int[5][5];
            for (int j = 0; j < 4; j++) {
                String line = reader.readLine();
                String[] elems = line.split(" ");
                for (int k = 0; k < 4; k++)
                    board[j][k] = Integer.valueOf(elems[k]);
            }
            String[] moves = reader.readLine().split(" ");
            int[][] output = shiftingSands(board, moves);
            for (int j = 0; j < 4; j++) {
                for (int k = 0; k < 4; k++) {
                    System.out.print(output[j][k] + " ");
                }
                System.out.println();
            }
        }
    }
}