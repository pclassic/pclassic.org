def make_moves(board, moves):

    for m in moves:
        if m == "N":
            board = move_north(board)

        if m == "S":
            board = move_south(board)

        if m == "W":
            board = move_west(board)

        if m == "E":
            board = move_east(board)

    return board


def move_west(board):
    new_board = compress(board)
    new_board = merge(new_board)
    new_board = compress(new_board)

    return new_board


def move_east(board):
    new_board = reverse(board)
    new_board = move_west(new_board)
    new_board = reverse(new_board)

    return new_board


def move_north(board):
    new_board = transpose(board)
    new_board = move_west(new_board)
    new_board = transpose(new_board)

    return new_board


def move_south(board):
    new_board = transpose(board)
    new_board = move_east(new_board)
    new_board = transpose(new_board)

    return new_board


def compress(board):
    new_board = []
    for i in range(4):
        new_board.append([0] * 4)

    for i in range(4):
        pos = 0
        for j in range(4):
            if(board[i][j] != 0):
                new_board[i][pos] = board[i][j]
                pos += 1
    return new_board


def merge(board):
    for i in range(4):
        for j in range(3):
            if(board[i][j] == board[i][j + 1] and board[i][j] != 0):
                board[i][j] = board[i][j] * 2
                board[i][j + 1] = 0
    return board


def reverse(board):
    new_board = []
    for i in range(4):
        new_board.append([])
        for j in range(4):
            new_board[i].append(board[i][3 - j])
    return new_board


def transpose(board):
    new_board = []
    for i in range(4):
        new_board.append([])
        for j in range(4):
            new_board[i].append(board[j][i])
    return new_board


def shiftingsands(board, moves):
    board = make_moves(board, moves)
    return board


# Do not modify below this line
if __name__ == "__main__":
    tests = int(input())
    for test in range(tests):
        board = []
        for i in range(4):
            line = input()
            board.append([])
            line = line.split(" ")
            for j in range(4):
                board[i].append(int(line[j]))

        moves = input().strip().split(" ")

        output = shiftingsands(board, moves)
        outputStr = ""
        for i in range(4):
          for j in range(4):
            outputStr += str(output[i][j])
            if j < 3:
              outputStr += ' '
          if i < 3:
            outputStr += '\n'
 
        print(outputStr)
