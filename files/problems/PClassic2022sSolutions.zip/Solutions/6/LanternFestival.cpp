#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <cstring>
using namespace std;

vector<int> lanternFestival(int n, vector<vector<int>> prefs)
{
    int inDegs[n];
    memset(inDegs, 0, sizeof(inDegs));
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < prefs[i].size(); j++) {
            inDegs[prefs[i][j]]++;
        }
    }
    int source = -1;
    vector<int> failure;
    failure.push_back(-1);
    for (int i = 0; i < n; i++) {
        if (inDegs[i] == 0 && source == -1) {
            source = i;
        } else if (inDegs[i] == 0) {
            // cout << "failed indegree test" << endl;
            return failure; // multiple sources
        }
        if (prefs[i].size() != 0 && prefs[i].size() != 2) {
            // if has # of children != 0, 2
            // cout << "failed outdegree test" << endl;
            return failure;
        }
    }
    if (source == -1) {
        // cout << "failed to have a source" << endl;
        return failure;
    }
    vector<int>  result;

    // bfs
    bool visited[n];
    for (int i = 0; i < n; i++) {
        visited[i] = false;
    }

    std::list<int> queue;
    visited[source] = true;
    queue.push_back(source);

    int c;
    while (!queue.empty()) {
        c = queue.front();
         //cout << c << " ";
        result.push_back(c);
        // cout << "result: " << result << endl;
        queue.pop_front();

        std::sort(prefs[c].begin(), prefs[c].end());
        // lower value sibs before higher values
        for (int i = 0; i < prefs[c].size(); i++) {
            int x = prefs[c][i];
            if (!visited[x]) {
                visited[x] = true;
                queue.push_back(x);
            }
            else {
                // x is child of multiple nodes/cycle
                return failure;
            }
        }
    }

    return result;
}

int main()
{
    // # of tests
    // # of lanterns (n)
    // # of edges/preferences (e)
    // Next x lines are edges: a b
    // Directed

    int tests;
    cin >> tests;

    while (tests > 0)
    {
        tests--;
        int n;
        cin >> n;
        vector<vector<int>> prefs;
        // zero-initialized
        for(int i = 0; i < n; i++) {
            vector<int> temp;
            prefs.push_back(temp);
        }

        int e;
        cin >> e;
        while (e > 0)
        {
            e--;
            int from, to;
            cin >> from;
            cin >> to;
            // cout << "From: " << from << endl;
            // cout << "To: " << to << endl;
            prefs[from].push_back(to);
            // add edge to adj list
        }
        /**/
        vector<int> result = lanternFestival(n, prefs);
        for(int i = 0; i < result.size(); i++) {
            cout << result[i] << endl;
        }
        cout << endl;
    }
    return 0;
}