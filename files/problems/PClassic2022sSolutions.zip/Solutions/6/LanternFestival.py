
def lanternFestival(vertices, edges):
    adjacencyList = []
    inDegree = []
    discovered = []
    for i in range(vertices):
        adjacencyList.append([])
        discovered.append(False)
        inDegree.append(0)
    for e in edges:
        adjacencyList[e[0]].append(e[1])
        inDegree[e[1]] += 1

    sources = 0
    start = 0
    for i in range(0, vertices):
        if inDegree[i] == 0:
            sources += 1
            start = i

    if sources != 1:
        return None

    queue = [start]
    discovered[start] = True
    traversal = [start]
    while queue:
        u = queue.pop(0)

        neighbors = adjacencyList[u]
        numNeighbors = len(neighbors)
        if numNeighbors != 2 and numNeighbors != 0:
            return None

        if numNeighbors == 0:
            continue

        v1 = 0
        v2 = 0
        if neighbors[0] < neighbors[1]:
            v1 = neighbors[0]
            v2 = neighbors[1]
        else:
            v1 = neighbors[1]
            v2 = neighbors[0]

        #print("u: " + str(u) + " v1: " + str(v1) + " v2: " + str(v2) + " " + str(discovered))

        if discovered[v1]:
            return None
        queue.append(v1)
        discovered[v1] = True
        traversal.append(v1)

        if discovered[v2]:
            return None
        queue.append(v2)
        discovered[v2] = True
        traversal.append(v2)

        #print(str(queue))
    return traversal

if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        vertices = int(input())
        numEdges = int(input())
        edges = []
        for e in range(numEdges):
            line = input().split()
            edges.append([int(line[0]), int(line[1])])
        res = lanternFestival(vertices, edges)
        if res is None:
            print(-1)
        else:
            for v in res:
                print(v)

