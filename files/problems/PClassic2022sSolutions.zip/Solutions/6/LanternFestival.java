import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {

    public static int[] lanternFestival(int n, int[][] prefs) {
        LinkedList[] adjList= new LinkedList[n];
        int[] inDegree = new int[n];
        boolean[] discovered = new boolean[n];

        Arrays.fill(discovered, false);
        Arrays.fill(inDegree, 0);
        for (int i = 0; i < n; i++) {
            adjList[i] = new LinkedList();
        }

        int sources = 0;
        int start = 0;
        //fill adjacency Lists
        for (int i = 0; i < prefs.length; i++) {
            LinkedList<Integer> curr = adjList[prefs[i][0]];
            curr.add(prefs[i][1]);
            inDegree[prefs[i][1]]++;
        }

        for (int i = 0; i < n; i++) {
            if (inDegree[i] == 0) {
                sources++;
                start = i;
            }
        }

        LinkedList<Integer> traversal = new LinkedList<>();

        if (sources != 1) {
            traversal.add(-1);
            return traversal.stream().mapToInt(i->i).toArray(); //convert LinkedList to int[]
        }


        LinkedList<Integer> queue = new LinkedList<Integer>();
        queue.add(start);
        discovered[start] = true;
        traversal.add(start);

        //bfs
        while (!queue.isEmpty()) {
            int u = queue.poll();
            LinkedList<Integer> neighbors = adjList[u];
            if (neighbors.size() != 2 && neighbors.size() != 0) {
                traversal.clear();
                traversal.add(-1);
                return traversal.stream().mapToInt(i->i).toArray(); //convert LinkedList to int[]
            }
            
            if (neighbors.size() == 0) {
                continue;
                // return traversal.stream().mapToInt(i->i).toArray(); //convert LinkedList to int[]
            }

            int v1 = 0;
            int v2 = 0;
            if (neighbors.get(0) < neighbors.get(1)) {
                v1 = neighbors.get(0);
                v2 = neighbors.get(1);
            } else {
                v1 = neighbors.get(1);
                v2 = neighbors.get(0);
            }

            if (discovered[v1] || discovered[v2]) {
                traversal.clear();
                traversal.add(-1);
                return traversal.stream().mapToInt(i->i).toArray(); //convert LinkedList to int[]
            }
            queue.add(v1);
            discovered[v1] = true;
            traversal.add(v1);
            queue.add(v2);
            discovered[v2] = true;
            traversal.add(v2);

        }

        return traversal.stream().mapToInt(i->i).toArray(); //convert LinkedList to int[]
    }


    // Do not modify below this line
    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.valueOf(reader.readLine());

        for (int i = 0; i < t; i++) {
            String inputNodes = reader.readLine();
            int n = Integer.valueOf(inputNodes);
            String edgeNum = reader.readLine();
            int k = Integer.valueOf(edgeNum);
            int[][] prefs = new int[k][2];
            for (int z = 0; z < k; z++) {
                String inputEdges = reader.readLine();
                String[] inputE = inputEdges.split(" ");
                prefs[z][0] = Integer.valueOf(inputE[0]);
                prefs[z][1] = Integer.valueOf(inputE[1]);
            }

            int [] output = lanternFestival(n, prefs);
            for (Integer e: output) {
                System.out.println(e);
            }

        }
    }
}