import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.*;

public class Main {
    public static void main(String[] args) throws Exception {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      int tests = Integer.parseInt(br.readLine());
      for (int i = 0; i < tests; i++) {
          String amount = br.readLine();
          int val = Integer.valueOf(amount);
          int itinerary[][] = new int[val][2];
          for(int j = 0; j < val; j++) {
        	  String value = br.readLine();
        	  String[] split = value.split(" ");
        	  itinerary[j][0] = Integer.valueOf(split[0]);
        	  itinerary[j][1] = Integer.valueOf(split[1]);
          }
         System.out.println(maximizeFun(itinerary));
      }
      br.close();
    }
    //Do not modify above this line
    
    public static int maximizeFun(int[][] itinerary) {
    	int dp[][] = new int[itinerary.length][2];
    	dp[itinerary.length - 1][0] = itinerary[itinerary.length - 1][0];
    	dp[itinerary.length - 1][1] = dp[itinerary.length - 1][0] * 2;
    	for(int i = itinerary.length - 2; i >= 0; i--) {
    	    // Skip this event
    		dp[i][0] = Math.max(itinerary[i][0], dp[i + 1][0]);
    		dp[i][1] = Math.max(itinerary[i][0] * 2, dp[i + 1][1]);
    		
    		int nextEvent = i + itinerary[i][1] + 1;
    		if (nextEvent < itinerary.length) {
    		    // Do this event
    		    if (dp[i][0] < dp[nextEvent][0] + itinerary[i][0]) {
        			dp[i][0] = dp[nextEvent][0] + itinerary[i][0];
        		}
        		if (dp[i][1] < dp[nextEvent][1] + itinerary[i][0]) {
        			dp[i][1] = dp[nextEvent][1] + itinerary[i][0];
        		}
        		// Do this event and double
        		if (dp[i][1] < dp[nextEvent][0] + itinerary[i][0] * 2) {
        			dp[i][1] = dp[nextEvent][0] + itinerary[i][0] * 2;
        		}
    		}
    	}
    	return dp[0][1];
    }
}