#include <iostream>
#include <vector>
#include <array>

using namespace std;

int maximizeFun(vector<array<int, 2>>& itinerary) {
    int n = itinerary.size();

    vector<array<int, 2>> dp;
    for (int i = 0; i < n; i++) {
        dp.push_back(array <int, 2> {-1, -1});
    }

    for (int i = n - 1; i >= 0; i--) {
        int funValue = itinerary[i][0];
        int energyRequirement = itinerary[i][1];

        // Fun values for event i if attending or splurging
        int attend_0 = funValue;
        int attend_1 = funValue;
        int splurge_0 = 2 * funValue;

        // Add maximum fun value gained after attending or splurging
        if (i + energyRequirement + 1 <= n - 1) {
            attend_0 += dp[i + energyRequirement + 1][0];
            attend_1 += dp[i + energyRequirement + 1][1];
            splurge_0 += dp[i + energyRequirement + 1][1];
        }

        // Maximum fun value if skipping event i
        int skip_0 = 0;
        int skip_1 = 0;
        if (i != n - 1) {
            skip_0 = dp[i + 1][0];
            skip_1 = dp[i + 1][1];
        }

        // Set maximum fun values for event i
        dp[i][0] = max(attend_0, max(splurge_0, skip_0));
        dp[i][1] = max(attend_1, skip_1);
    }

    return max(dp[0][0], dp[0][1]);
}

int main() {
    int t;
    for (cin >> t; t > 0; t--) {
        cin.get();
        vector<array<int, 2>> itinerary;
        int numEvents;
        for (cin >> numEvents; numEvents > 0; numEvents--) {
            int funValue;
            int energyRequirement;
            cin >> funValue;
            cin >> energyRequirement;
            itinerary.push_back(array<int, 2> {funValue, energyRequirement});     
            if (numEvents > 1) {
                cin.get();
            }
        }
        cout << maximizeFun(itinerary) << endl;
    }
}
