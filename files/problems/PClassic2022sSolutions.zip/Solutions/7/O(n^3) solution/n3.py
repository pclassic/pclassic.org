def maximizeFun(itinerary):
    
    def func(i, currValue, hasBoost):
        if i >= len(itinerary): 
            return currValue
        best = max(func(i + itinerary[i][1] + 1, currValue + itinerary[i][0], hasBoost), func(i+1, currValue, hasBoost))
        if hasBoost:
            return max(best, func(i+ 1+itinerary[i][1], currValue + 2*itinerary[i][0], False))
        return best
    
    best = 0
    for i in range(0, len(itinerary)):
       best = max(best, func(i, 0, True))
    
    return best
    
# Do not modify below this line
if __name__ == '__main__':
  tests = int(input().strip())
  for _ in range(tests):
    numLocations = int(input().strip())
    arr = [[0 for _ in range(2)] for _ in range(numLocations)]
    for i in range(numLocations):
        pair = input().strip().split(" ")
        arr[i] = [int(pair[0]), int(pair[1])]
    print(maximizeFun(arr))