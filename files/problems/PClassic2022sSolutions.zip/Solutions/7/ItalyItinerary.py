# Implement the following method
def maximizeFun(itinerary):
    n = len(itinerary)
    dp = [[-1 for _ in range(2)] for _ in range(n)]

    for i in range(n - 1, -1, -1):
      funValue = itinerary[i][0]
      energyRequirement = itinerary[i][1]

      # Fun values for event i if attending or splurging
      attend_0 = funValue
      attend_1 = funValue
      splurge_0 = 2 * funValue

      # Add maximum fun value gained after attending or splurging
      if i + energyRequirement + 1 <= n - 1:
          attend_0 += dp[i + energyRequirement + 1][0]
          attend_1 += dp[i + energyRequirement + 1][1]
          splurge_0 += dp[i + energyRequirement + 1][1]

      # Maximum fun value if skipping event i
      skip_0 = 0
      skip_1 = 0
      if i != n - 1:
          skip_0 += dp[i + 1][0]
          skip_1 += dp[i + 1][1]

      # Set maximum fun values for event i
      dp[i][0] = max(attend_0, max(splurge_0, skip_0))
      dp[i][1] = max(attend_1, skip_1)
    
    return max(dp[0][0], dp[0][1])



# Do not modify below this line
if __name__ == '__main__':
  tests = int(input().strip())
  for _ in range(tests):
    numLocations = int(input().strip())
    arr = [[0 for _ in range(2)] for _ in range(numLocations)]
    for i in range(numLocations):
        pair = input().strip().split(" ")
        arr[i] = [int(pair[0]), int(pair[1])]
    print(maximizeFun(arr))
