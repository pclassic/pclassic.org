def cross(a, b):
    cp = [0, 0, 0]
    cp[0] = a[1] * b[2] - a[2] * b[1]
    cp[1] = a[2] * b[0] - a[0] * b[2]
    cp[2] = a[0] * b[1] - a[1] * b[0]
    return cp

def terrifyingTetra(ps):
    centroid = [0, 0, 0]

    for i in range(3):
        sum = 0
        for j in range(4):
            sum += ps[j][i]
        sum /= 4
        centroid[i] = sum

    es = [[0, 0, 0] for _ in range(3)]
    for i in range(3):
        for j in range(3):
            es[i][j] = ps[i + 1][j] - ps[0][j]
            
    eMag = [0, 0, 0]
    for i in range(3):
        sum = 0
        for j in range(3):
            sum += pow(es[i][j], 2)
        eMag[i] = sum

    cp12 = cross(es[0], es[1])
    cp31 = cross(es[2], es[0])
    cp23 = cross(es[1], es[2])

    for i in range(3):
        cp12[i] = cp12[i] * eMag[2]
        cp31[i] = cp31[i] * eMag[1]
        cp23[i] = cp23[i] * eMag[0]

    detA = es[0][0] * es[1][1] * es[2][2] + es[0][1] * es[1][2] * es[2][0] + es[0][2] * es[1][0] * es[2][1] - es[0][2] * es[1][1] * es[2][0] - es[0][1] * es[1][0] * es[2][2] - es[0][0] * es[1][2] * es[2][1]

    sumCP = [0, 0, 0]
    skewDet = 1 / (2 * detA)
    for i in range(3):
        sumCP[i] = (cp12[i] + cp31[i] + cp23[i]) * skewDet

    circ = [0, 0, 0]
    for i in range(3):
        circ[i] = sumCP[i] + ps[0][i]

    monge = [0, 0, 0]
    for i in range(3):
        monge[i] = 2 * centroid[i] - circ[i]
    return monge

# Do not modify below this line
if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        points = [[0, 0, 0] for _ in range(4)]
        for i in range(4):
            point = input()
            split = point.split()
            for j in range(3):
                points[i][j] = float(split[j])
        output = terrifyingTetra(points)
        s = ""
        for i in range(len(output)):
            s += str(round(output[i] * 10.0) / 10.0) + " "
        print(s[:-1])