import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.io.*;

public class Main {
    public static double[] terrifyingTetra(double[][] ps) {
        double[] centroid = new double[3];

        for (int i = 0; i < 3; i++) {
            double sum = 0;
            for (int j = 0; j < 4; j++) {
                sum += ps[j][i];
            }
            sum /= 4;
            centroid[i] = sum;
        }

        double[][] es = new double[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                es[i][j] = ps[i + 1][j] - ps[0][j];
            }
        }

        double[] eMag = new double[3];
        for (int i = 0; i < 3; i++) {
            double sum = 0;
            for (int j = 0; j < 3; j++) {
                sum += Math.pow(es[i][j], 2);
            }
            eMag[i] = sum;
        }

        double[] cp12 = cross(es[0], es[1]);
        double[] cp31 = cross(es[2], es[0]);
        double[] cp23 = cross(es[1], es[2]);

        for (int i = 0; i < 3; i++) {
            cp12[i] = cp12[i] * eMag[2];
            cp31[i] = cp31[i] * eMag[1];
            cp23[i] = cp23[i] * eMag[0];
        }

        double detA = es[0][0] * es[1][1] * es[2][2] + es[0][1] * es[1][2] * es[2][0] + es[0][2] * es[1][0] * es[2][1]
                - es[0][2] * es[1][1] * es[2][0] - es[0][1] * es[1][0] * es[2][2] - es[0][0] * es[1][2] * es[2][1];

        double[] sumCP = new double[3];
        double skewDet = 1 / (2 * detA);
        for (int i = 0; i < 3; i++) {
            sumCP[i] = (cp12[i] + cp31[i] + cp23[i]) * skewDet;
        }

        double[] circ = new double[3];
        for (int i = 0; i < 3; i++) {
            circ[i] = sumCP[i] + ps[0][i];
        }
        double[] monge = new double[3];
        for (int i = 0; i < 3; i++) {
            monge[i] = 2 * centroid[i] - circ[i];
        }
        return monge;
    }

    public static double[] cross(double[] a, double[] b) {
        double[] cp = new double[3];
        cp[0] = a[1] * b[2] - a[2] * b[1];
        cp[1] = a[2] * b[0] - a[0] * b[2];
        cp[2] = a[0] * b[1] - a[1] * b[0];
        return cp;
    }

    public static void main(String[] args) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.valueOf(reader.readLine());
        for (int i = 0; i < t; i++) {
            double[][] points = new double[4][3];
            for (int j = 0; j < 4; j++) {
                String point = reader.readLine();
                String[] split = point.split(" ");
                for (int a = 0; a < 3; a++) {
                    points[j][a] = Double.valueOf(split[a]);
                }
            }
            double[] output = terrifyingTetra(points);
            for (int j = 0; j < output.length; j++) {
                System.out.print((Math.round(output[j] * 10.0) / 10.0) + " ");
            }
            System.out.println();
        }
    }
}