#include <iostream>
#include <string>
#include <map>
#include <sstream>
#include <vector>
#include <set>
#include <math.h>
#include <iomanip>

using namespace std;

vector<double> cross(vector<double> a, vector<double> b) {
    vector<double> cp;
    cp.push_back(a[1] * b[2] - a[2] * b[1]);
    cp.push_back(a[2] * b[0] - a[0] * b[2]);
    cp.push_back(a[0] * b[1] - a[1] * b[0]);
    return cp;
}

vector<double> terrifyingTetra(vector<vector<double>> ps) {
    vector<double> centroid;

    for (int i = 0; i < 3; i++) {
        double sum = 0;
        for (int j = 0; j < 4; j++) {
            sum += ps[j][i];
        }
        sum /= 4;
        centroid.push_back(sum);
    }
    // centroid is calculated correctly 


    vector<vector<double>> es;
    for (int i = 0; i < 3; i++) {
        vector<double> temp;
        for (int j = 0; j < 3; j++) {
            temp.push_back(ps[i + 1][j] - ps[0][j]);
        }
        es.push_back(temp);
    }

    // es calculated correctly 


    vector<double> eMag;
    for (int i = 0; i < 3; i++) {
        double sum = 0;
        for (int j = 0; j < 3; j++) {
            sum += pow(es[i][j], 2);
        }
        eMag.push_back(sum);
    }

    vector<double> cp12 = cross(es[0], es[1]);
    vector<double> cp31 = cross(es[2], es[0]);
    vector<double> cp23 = cross(es[1], es[2]);

    for (int i = 0; i < 3; i++) {
        cp12[i] = cp12[i] * eMag[2];
        cp31[i] = cp31[i] * eMag[1];
        cp23[i] = cp23[i] * eMag[0];
    }

    double detA = es[0][0] * es[1][1] * es[2][2] + es[0][1] * es[1][2] * es[2][0] + es[0][2] * es[1][0] * es[2][1]
            - es[0][2] * es[1][1] * es[2][0] - es[0][1] * es[1][0] * es[2][2] - es[0][0] * es[1][2] * es[2][1];

    vector<double> sumCP;
    double skewDet = 1 / (2 * detA);
    for (int i = 0; i < 3; i++) {
        sumCP.push_back((cp12[i] + cp31[i] + cp23[i]) * skewDet);
    }

    vector<double> circ;
    for (int i = 0; i < 3; i++) {
        circ.push_back(sumCP[i] + ps[0][i]);
    }


    vector<double> monge;
    for (int i = 0; i < 3; i++) {
        monge.push_back(2 * centroid[i] - circ[i]);
    }
    return monge;
}

int main() {
    int t;
    for (cin >> t; t > 0; t--) {
        vector<vector<double>> points;
        for (int j = 0; j < 4; j++) {
            string point0, point1, point2;
            cin >> point0;
            cin >> point1;
            cin >> point2;
            vector<double> temp;
            temp.push_back(stod(point0));
            temp.push_back(stod(point1));
            temp.push_back(stod(point2));
            points.push_back(temp);
        }
        vector<double> output = terrifyingTetra(points);
        cout << setprecision(1) << fixed;
        for (int j = 0; j < output.size(); j++) {
            cout << (round(output[j] * 10.0) / 10.0);
            if (j < output.size() - 1) {
                cout << " ";
            }
        }
		cout << "\n";
    }
}