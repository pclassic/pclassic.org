import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.TreeSet;

public class Biblioburro {

    public static boolean efficientTrip(long[] mountainList) {
        if (mountainList.length <= 2)
            return true;

        TreeSet<Long> left = new TreeSet<>();
        TreeSet<Long> leftMinus = new TreeSet<>();
        left.add(mountainList[0]);
        leftMinus.add(-mountainList[0]);
        long[] suffixMax = new long[mountainList.length];
        long[] suffixMin = new long[mountainList.length];
        suffixMax[mountainList.length - 1] = Long.MIN_VALUE;
        suffixMin[mountainList.length - 1] = Long.MAX_VALUE;

        for (int i = mountainList.length - 2; i >= 0; i--) {
            suffixMax[i] = Math.max(suffixMax[i + 1], mountainList[i + 1]);
            suffixMin[i] = Math.min(suffixMin[i + 1], mountainList[i + 1]);
        }

        for (int i = 1; i < mountainList.length - 1; i++) {
            if (left.contains(mountainList[i]) && i != mountainList.length - 1) {
                return false;
            }
            Long closestSmall = left.lower(mountainList[i]); //closest element smaller than current
            Long closestLarge = leftMinus.lower(- mountainList[i]); //closest element larger than current
            long diffMax = Math.abs(suffixMax[i] - mountainList[i]);
            long diffMin = Math.abs(suffixMin[i] - mountainList[i]);
            long diff = Math.max(diffMax, diffMin);

            if ((closestSmall != null && Math.abs(closestSmall - mountainList[i]) <= diff)
                || (closestLarge != null && Math.abs(- closestLarge - mountainList[i]) <= diff)) {
                return false;
            }
            left.add(mountainList[i]);
            leftMinus.add(- mountainList[i]);
        }
        return true;
    }


    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(reader.readLine());
        long time = System.currentTimeMillis();
        while (t-- > 0) {
            int length = Integer.parseInt(reader.readLine());
            long[] mountainList = new long[length];
            String[] elements = reader.readLine().split(" ");
            for (int i = 0; i < length; i++) {
                mountainList[i] = Long.parseLong(elements[i]);
            }
            boolean result = efficientTrip(mountainList);
            if (result) {
                System.out.println(1);
            } else {
                System.out.println(0);
            }
        }
    }
}
