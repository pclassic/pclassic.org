import math

def biblioburro(mountainList):
    suffixMax = list(range(len(mountainList)))
    suffixMin = list(range(len(mountainList)))
    suffixMax[len(mountainList) - 1] = 0
    suffixMin[len(mountainList) - 1] = math.inf
    for i in range(len(mountainList) - 2, -1, -1):
        suffixMax[i] = max(suffixMax[i + 1], mountainList[i + 1])
        suffixMin[i] = min(suffixMin[i + 1], mountainList[i + 1])

    for i in range(1, len(mountainList) - 1):
        furthest = max(abs(mountainList[i] - suffixMax[i]), abs(mountainList[i] - suffixMin[i]))
        closest = math.inf
        for j in range(0, i):
            closest = min(closest, abs(mountainList[i] - mountainList[j]))

        if closest <= furthest:
            return False
    return True


if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        length = int(input())
        line = input().split()
        mountainList = []
        for e in line:
            mountainList.append(int(e))
        res = biblioburro(mountainList)
        if res:
            print(1)
        else:
            print(0)

