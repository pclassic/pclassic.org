#include <bits/stdc++.h>

using namespace std;

#define f0r(a, b) for (long long a = 0; a < b; a++)
#define f1r(a, b, c) for (long long a = b; a < c; a++)
#define f0rd(a, b) for (long long a = b; a >= 0; a--)
#define f1rd(a, b, c) for (long long a = b; a >= c; a--)
#define ms(arr, v) memset(arr, v, sizeof(arr))
#define mp(a, b) make_pair(a, b)
#define pb push_back
#define f first
#define s second
#define nl '\n';
#define sz(v) (long long) v.size()

#define ao(a, n) {for (int ele = 0; ele < n; ele++) { if (ele) cout << " "; cout << a[ele]; } cout << '\n';}

typedef long long ll;
typedef double ld;
typedef long double lld;
typedef unsigned long long ull;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef vector<pii> vpi;
typedef vector<pll> vpl;

const ll inf = 1e16;

const int MOD = 1e9 + 7;
typedef decay<decltype(MOD)>::type T;
struct mi {
	T val;
	explicit operator T() const { return val; }
	mi() { val = 0; }
	mi(const long long& v) {
		val = (-MOD <= v && v < MOD) ? v : v % MOD;
		if (val < 0) val += MOD; }
	friend ostream& operator<<(ostream& os, const mi& a) { return os << a.val; }
	friend bool operator==(const mi& a, const mi& b) { return a.val == b.val; }
	friend bool operator!=(const mi& a, const mi& b) { return !(a == b); }
	friend bool operator<(const mi& a, const mi& b) { return a.val < b.val; }
	mi operator-() const { return mi(-val); }
	mi& operator+=(const mi& m) {
		if ((val += m.val) >= MOD) val -= MOD;
		return *this; }
	mi& operator-=(const mi& m) {
		if ((val -= m.val) < 0) val += MOD;
		return *this; }
	mi& operator*=(const mi& m) { val = (long long) val * m.val % MOD;
		return *this; }
	friend mi pow(mi a, long long p) {
		mi ans = 1; assert(p >= 0);
		for (; p; p /= 2, a *= a) if (p & 1) ans *= a;
		return ans; }
	friend mi inv(const mi& a) { assert(a != 0); return pow(a, MOD - 2); }
	mi& operator/=(const mi& m) { return (*this) *= inv(m); }
	friend mi operator+(mi a, const mi& b) { return a += b; }
	friend mi operator-(mi a, const mi& b) { return a -= b; }
	friend mi operator*(mi a, const mi& b) { return a *= b; }
	friend mi operator/(mi a, const mi& b) { return a /= b; }
};

struct Tree {
	// F(s, t) = a * s^b * t^c
	// S(s) = c * s;
	mi a; 
	mi b;
	mi c;

	Tree (mi ea, mi eb, mi ec) {
		a = ea;
		b = eb;
		c = ec;
	}

	Tree (vector<int> v) {
		a = 1;
		b = 0;
		c = 1;

		int sz = v.size();
		for (int i = sz - 1; i > 0; i--) {
			int val = v[i];
			a = pow(a, val);
			b = b * val;
			c = c * val;

			b += 1;
			a *= c;
		}
		//cout << a << " " << b << " " << c << endl;
	}


	//identity element is a = 1, b = 0, c = 1
	Tree op(Tree t) {
		
		a = a * pow(t.c, (int) b) * pow(t.a, (int) c);
		b = b + c * t.b;
		c = c * t.c;

		return Tree(a, b, c);
	}
};

vector<Tree> tarr;


struct segtree {
  int n, depth;
  vector<Tree> tree, lazy;

  void init(int s) {
    n = s;

	for (int i = 0; i < 4 * s; i++) {
		tree.pb(Tree(mi(1), mi(0), mi(1)));
		lazy.pb(Tree(mi(1), mi(0), mi(1)));
	}

    init(0, 0, n - 1);
  }

  Tree init(int i, int l, int r) {
    if (l == r) return tree[i] = tarr[l];

    int mid = (l + r) / 2;
    Tree a = init(2 * i + 1, l, mid),
          b = init(2 * i + 2, mid + 1, r);
    return tree[i] = a.op(b);
  }
    
  Tree query(int l, int r) {
    return query(0, 0, n-1, l, r);
  }

  Tree query(int i, int tl, int tr, int ql, int qr) {
	//cout << tl << " " << tr << " " << ql << " " << qr << endl;
    if (ql <= tl && tr <= qr) {
		//cout << "hi! " << tree[i].a << " " << tree[i].b << " " << tree[i].c << endl;
		return tree[i];
	}
	if (tr < ql || qr < tl) {
		//cout << "hi2!" << endl;
		return Tree(mi(1), mi(0), mi(1));
	}

    int mid = (tl + tr) / 2;
    Tree a = query(2 * i + 1, tl, mid, ql, qr),
         b = query(2 * i + 2, mid + 1, tr, ql, qr);
    return a.op(b);
  }
};

int main() {
	ios_base::sync_with_stdio(false); cin.tie(NULL);
	int n, q; 

	cin >> n >> q;

	f0r(i, n) {
		int s; cin >> s;
		vi v(s);
		f0r(j, s) {
			cin >> v[j];
		}
		tarr.pb(Tree(v));
	}

	segtree st;
	st.init(n);

	for (int i = 0; i < q; i++) {
		int l, r; cin >> l >> r;
	
		cout << st.query(l - 1, r - 1).a << nl;
	}
}
