#include <bits/stdc++.h>
 
using namespace std;

vector<string> tubeAdventures(int n, int m, int q, string islands[], int queries[]) {
    bool grid[n][m];
    vector<string> response;
    int nd = 0;

    //x -> there is a door, . -> there is no door
    for (int i = 0; i < n; i++) {
        string s = islands[i];
        for (int j = 0; j < m; j++) {
            grid[i][j] = 0;
            if (s[j] == 'x') {
                grid[i][j] = 1;
                nd++;
            }
        }
    }

    //doors that you can add
    vector<int> pos_additions;
    int req = 0;
    int num_diags = 0;

    int mn = min(m, n);

    //number of open long diagonals (size mn)
    int long_diags = 0;

    //iterate through all of the diagonals
    for (int i = 0; i < m; i++) {
        int sz = 0;
        int doors = 0;
        int cur_row = 0;
        int cur_col = i;
        while (cur_row < n && cur_col < m) {
            doors += grid[cur_row][cur_col];
            sz++;
            cur_row++;
            cur_col++;
        }
        if (doors > 0) {
            num_diags++;
            req += sz - doors;
        } else {
            if (sz < mn) {
                pos_additions.push_back(sz);
            } else {
                long_diags++;
            }
        }
    }

    //repeat for the lower diagonals
    for (int i = 1; i < n; i++) {
        int sz = 0;
        int doors = 0;
        int cur_row = i;
        int cur_col = 0;
        while (cur_row < n && cur_col < m) {
            doors += grid[cur_row][cur_col];
            sz++;
            cur_row++;
            cur_col++;
        }
        if (doors > 0) {
            num_diags++;
            req += sz - doors;
        } else {
            if (sz < mn) {
                pos_additions.push_back(sz);
            } else {
                long_diags++;
            }
        }
    }

    //cout << num_diags << endl;

    bool dp[mn * mn + 1][2];
    bool ndp[mn * mn + 1][2];

    memset(dp, 0, sizeof(dp));
    memset(ndp, 0, sizeof(dp));

    dp[0][num_diags % 2] = 1;
    ndp[0][num_diags % 2] = 1;

    // do dp
    for (int x: pos_additions) {
        for (int i = 0; i <= mn * mn; i++) {
            if (i + x > mn * mn) {
                break;
            }
            if (dp[i][0]) {
                ndp[i + x][1] = 1;
            }
            if (dp[i][1]) {
                ndp[i + x][0] = 1;
            }
        }

        for (int i = 0; i <= mn * mn; i++) {
            dp[i][0] = ndp[i][0];
            dp[i][1] = ndp[i][1];
        }
    }

    //cout << dp[0][0] << endl;
    
    int md = 2 * mn;
    vector<int> mddp[md][2];

    for (int i = 0; i <= mn * mn; i++) {
        if (dp[i][0]) {
            mddp[i % md][0].push_back(i);
        }
        if (dp[i][1]) {
            mddp[i % md][1].push_back(i);
        }
    }

    for (int i = 0; i < q; i++) {
        int add = queries[i];
        if (add < req || add + nd > m * n) {
            response.push_back("NO");
            continue;
        }
        add -= req;

        bool pos = 0;

        //find mod
        int addmd = add % md;

        if (mddp[addmd][0].size() > 0) { 
            auto it = upper_bound(mddp[addmd][0].begin(), mddp[addmd][0].end(), add);
            if (it != mddp[addmd][0].begin()) {
                int val = *(it - 1);
                int diff = (add - val)/mn;
                if (diff <= long_diags) {
                    pos = 1;
                }
            }
        }

        if (add >= mn) {
            addmd = (add - mn) % md;

            if (mddp[addmd][1].size() > 0) { 
                auto it = upper_bound(mddp[addmd][1].begin(), mddp[addmd][1].end(), add);
                if (it != mddp[addmd][1].begin()) {
                    int val = *(it - 1);
                    int diff = (add - val)/mn;
                    if (diff <= long_diags) {
                        pos = 1;
                    }
                }
            }
        }
        
        if (pos) {
            response.push_back("YES");
        } else {
            response.push_back("NO");
        }
    }
    return response;
}

int main() {
    int t;
    cin >> t;
    while (t--) {
        int n, m, q;
        cin >> n >> m >> q;
        int grid[n][m];
        string islands[n];
        int queries[q];
        for (int i = 0; i < n; i++) {
            string s; cin >> s;
            islands[i] = s;
        }
        for (int i = 0; i < q; i++) {
            int s; cin >> s;
            queries[i] = s;
        }
        vector<string> output = tubeAdventures(n, m, q, islands, queries);
        for (string s : output) {
            cout << s << endl;
        }
    }
}