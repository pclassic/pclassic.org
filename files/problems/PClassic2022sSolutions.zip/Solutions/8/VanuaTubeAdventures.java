import java.io.*;
import java.util.ArrayList;

public class Main {
    
    public static void main(String[] args) throws IOException{
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int cases = Integer.parseInt(br.readLine());
        for (int j = 0; j < cases; j++) {
            String str = br.readLine();
            String[] splitStr = str.trim().split("\\s+");   
            int n = Integer.parseInt(splitStr[0]);
            int m = Integer.parseInt(splitStr[1]);
            int q = Integer.parseInt(splitStr[2]);
            String[] islands = new String[n];
            int[] queries = new int[q];
            for (int i = 0; i < n; i++) {
                String s = br.readLine();
                islands[i] = s;
            }
            for (int i = 0; i < q; i++) {
                String s = br.readLine();
                queries[i] = Integer.parseInt(s);
            }
            ArrayList<String> results = tubeAdventures(n, m, q, islands, queries);
            for (String s : results) {
                System.out.println(s);
            }
        }
            br.close();
    }

    public static ArrayList tubeAdventures(int n, int m, int q, String[] islands, int[] queries){
        //n -> rows
        //m -> cols
        //q -> number of queries
        //int n, m, q; cin >> n >> m >> q;
        int[][] grid = new int[n][m];
        ArrayList<String> out = new ArrayList<>();
        //x -> there is a door, . -> there is no door
        for (int i = 0; i < n; i++) {
            String s = islands[i];
            for (int j = 0; j < m; j++) {
                grid[i][j] = 0;
                if (s.charAt(j) == 'x') {
                    grid[i][j] = 1;
                }
            }
        }

        //doors that you can add
        ArrayList<Integer> pos_additions = new ArrayList();
        int req = 0;
        int num_diags = 0;

        int mn = Math.min(m, n);

        //number of open long diagonals (size mn)
        int long_diags = 0;

        //iterate through all of the diagonals
        for (int i = 0; i < m; i++) {
            int sz = 0;
            int doors = 0;
            int cur_row = 0;
            int cur_col = i;
            while (cur_row < n && cur_col < m) {
                doors += grid[cur_row][cur_col];
                sz++;
                cur_row++;
                cur_col++;
            }
            if (doors > 0) {
                num_diags++;
                req += sz - doors;
            } else {
                if (sz < mn) {
                    pos_additions.add(sz);
                } else {
                    long_diags++;
                }
            }
        }

        //repeat for the lower diagonals
        for (int i = 1; i < n; i++) {
            int sz = 0;
            int doors = 0;
            int cur_row = i;
            int cur_col = 0;
            while (cur_row < n && cur_col < m) {
                doors += grid[cur_row][cur_col];
                sz++;
                cur_row++;
                cur_col++;
            }
            if (doors > 0) {
                num_diags++;
                req += sz - doors;
            } else {
                if (sz < mn) {
                    pos_additions.add(sz);
                } else {
                    long_diags++;
                }
            }
        }

        //cout << num_diags << endl;

        int[][] dp = new int[mn * mn + 1][2];
        int[][] ndp = new int[mn * mn + 1][2];

        dp[0][num_diags % 2] = 1;
        ndp[0][num_diags % 2] = 1;

        // do dp
        for (int x: pos_additions) {
            for (int i = 0; i <= mn * mn; i++) {
                if (i + x > mn * mn) {
                    break;
                }
                if (dp[i][0] == 1) {
                    ndp[i + x][1] = 1;
                }
                if (dp[i][1] == 1) {
                    ndp[i + x][0] = 1;
                }
            }

            for (int i = 0; i <= mn * mn; i++) {
                dp[i][0] = ndp[i][0];
                dp[i][1] = ndp[i][1];
            }
        }

        //cout << dp[0][0] << endl;
        
        int md = 2 * mn;
        ArrayList<Integer>[][] mddp = (ArrayList<Integer>[][]) new ArrayList[md][2];
        
        for(int i = 0; i < mddp.length; i++){
            for(int j = 0; j < mddp[i].length; j++){
                mddp[i][j] = new ArrayList<Integer>();
            }
        }
        


        for (int i = 0; i <= mn * mn; i++) {
            if (dp[i][0] == 1) {
                mddp[i % md][0].add(i);
            }
            if (dp[i][1] == 1) {
                mddp[i % md][1].add(i);
            }
        }

        for (int i = 0; i < q; i++) {
            //int add; cin >> add;
            int add = queries[i];
            if (add < req) {
                out.add("NO");
                continue;
            }
            add -= req;

            int pos = 0;

            //find mod
            int addmd = add % md;
            if (mddp[addmd][0].size() > 0) { 
                int it = upper_bound(mddp[addmd][0].stream().mapToInt(j -> j).toArray(), 0, mddp[addmd][0].size(), add);
                if (it != 0) {
                    int val = mddp[addmd][0].get(it - 1);
                    int diff = (add - val)/mn;
                    if (diff <= long_diags) {
                        pos = 1;
                    }
                }
            }

            if (add >= mn) {
                addmd = (add - mn) % md;

                if (mddp[addmd][1].size() > 0) { 
                    int it = upper_bound(mddp[addmd][1].stream().mapToInt(j -> j).toArray(), 0, mddp[addmd][1].size(), add);
                    if (it != 0) {
                        int val = mddp[addmd][1].get(it - 1);
                        int diff = (add - val)/mn;
                        if (diff <= long_diags) {
                            pos = 1;
                        }
                    }
                }
            }
            
            if (pos == 1) {
                out.add("YES");
            } else {
                out.add("NO");
            }
        }
        return out;
    }

    static int upper_bound(int[] a, int low, int high, int element) {
        while (low < high) {
            int middle = low + (high - low) / 2;
            if (a[middle] > element) {
                high = middle;
            } else {
                low = middle + 1;
            }
        }
        return low;
    }

}