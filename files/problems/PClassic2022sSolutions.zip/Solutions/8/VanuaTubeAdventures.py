def tubeAdventures(n, m, q, islands, queries): 
    #n -> rows
    #m -> cols
    #q -> number of queries
	#int n, m, q; cin >> n >> m >> q;
    #bool grid[n][m];
    grid = []
    out = []
    #x -> there is a door, . -> there is no door
    for s in islands:
        row = []
        for ch in s:
            if (ch == 'x'):
                row.append(1)
            else:
                row.append(0)
        grid.append(row)

    #doors that you can add
    pos_additions = []
    req = 0
    num_diags = 0

    mn = min(m, n)

    #number of open long diagonals (size mn)
    long_diags = 0

    #iterate through all of the diagonals
    for i in range (0,m):
        sz = 0
        doors = 0
        cur_row = 0
        cur_col = i
        while cur_row < n and cur_col < m:
            doors += grid[cur_row][cur_col]
            sz+=1
            cur_row+=1
            cur_col+=1
        if doors > 0:
            num_diags+=1
            req += sz - doors
        else:
            if (sz < mn):
                pos_additions.append(sz)
            else:
                long_diags+=1
            
        
    

    #repeat for the lower diagonals
    for i in range(1,n):
        sz = 0
        doors = 0
        cur_row = i
        cur_col = 0
        while cur_row < n and cur_col < m:
            doors += grid[cur_row][cur_col]
            sz+=1
            cur_row+=1
            cur_col+=1
        if (doors > 0):
            num_diags+=1
            req += sz - doors
        else:
            if (sz < mn):
                pos_additions.append(sz)
            else:
                long_diags+=1
            
        
    

    #cout << num_diags << endl;
    rows, cols = (mn * mn + 1, 2)
    dp = [[0 for i in range(cols)] for j in range(rows)]
    ndp = [[0 for i in range(cols)] for j in range(rows)]

    dp[0][num_diags % 2] = 1
    ndp[0][num_diags % 2] = 1

    # do dp
    for  x in pos_additions:
        for i in range(mn * mn + 1):
            if (i + x > mn * mn):
                break
            if (dp[i][0]):
                ndp[i + x][1] = 1
            if (dp[i][1]):
                ndp[i + x][0] = 1
        for i in range(mn * mn + 1):
            dp[i][0] = ndp[i][0]
            dp[i][1] = ndp[i][1]

    md = 2 * mn
    rows, cols = (md,2)
    mddp = [[ [] for i in range(cols)] for j in range(rows)]

    for i in range(mn * mn + 1):
        if (dp[i][0]):
            mddp[i % md][0].append(i)
        if (dp[i][1]):
            mddp[i % md][1].append(i)

    for i in range(q):
        add = queries[i]
        if (add < req):
            out.append("NO")
            continue
        add -= req
        pos = 0
        #find mod
        addmd = add % md
        if len(mddp[addmd][0]) > 0:
            it = bisect_right(mddp[addmd][0], 0, len(mddp[addmd][0]), add)
            if (it != 0):
                val = mddp[addmd][0][it - 1]
                diff = (add - val)/mn
                if (diff <= long_diags):
                    pos = 1

        if (add >= mn):
            addmd = (add - mn) % md
            if (len(mddp[addmd][1]) > 0):
                it = bisect_right(mddp[addmd][1], 0, len(mddp[addmd][1]), add)
                if (it != 0):
                    val = mddp[addmd][1][it - 1]
                    diff = (add - val)/mn
                    if (diff <= long_diags):
                        pos = 1
        if (pos == 1):
            out.append("YES")
        else:
            out.append("NO")
    return out

def bisect_right(a, low, high, element):
    while (low < high):
        middle = low + (high - low) // 2
        if (a[middle] > element):
            high = middle
        else:
            low = middle + 1
    return low


#n, m, q, grid, queries
if __name__ == "__main__":
    tests = int(input())
    for i in range(tests):
        nmq = input().split(" ")
        n = int(nmq[0])
        m = int(nmq[1])
        q = int(nmq[2])
        islands = []
        queries = []
        for i in range(n):
            row = input().strip()
            islands.append(row)
        for i in range(q):
            queries.append(int(input().strip()))
        results = tubeAdventures(n, m, q, islands, queries)
        for result in results:
            print(result)