#include <iostream>
#include <string>
#include <map>
#include <sstream>
#include <vector>
#include <set>

using namespace std;

int arms(vector<vector<int>> rbff, set<int> visited, int node, int length, int otherarm) {
    if (node == otherarm) {
        return 0;
    }
    visited.insert(node);
    vector<int> neighbors = rbff[node];
    if (neighbors.size() == 0) {
        return length;
    }
    int best = 0;
    for (int neighbor: neighbors) {
         best = max(best, arms(rbff, visited, neighbor, length + 1, otherarm));
    }
    return best;
}

int superhero(int n, vector<int> bff) {
    // Reversed graph
	vector<vector<int>> rbff(n);
	for (int i = 0; i < n; i++) {
	    rbff[bff[i]].push_back(i);
	}

	// Find cycle
	int bestCycle = 0;
	set<int> visited;
	set<int> finished;
	int sum2Cycle = 0;
	
	
	for (int i = 0; i < n; i++) {
	    int curr = i;
	    if (!finished.count(i)) {
	        while (!visited.count(curr) && !finished.count(curr)) {
	            visited.insert(curr);
	            curr = bff[curr];
	        }
	        if (visited.count(curr)) {
	            // found cycle, count cycle
	            int cycleSize = 1;
	            int cycleEnd = curr;
	            while (bff[curr] != cycleEnd) {
	                cycleSize += 1;
	                curr = bff[curr];
	            }
	            if (cycleSize == 2) {
	                // 2 cycle case
	                int l = curr;
	                int r = cycleEnd;
	                sum2Cycle += 2;
	                sum2Cycle += arms(rbff, visited, l, 0, r);
                    sum2Cycle += arms(rbff, visited, r, 0, l);
	            }
	            bestCycle = max(bestCycle, cycleSize);
	        }
	        finished.insert(visited.begin(), visited.end());
            visited.clear();
	    }
	}
	return max(bestCycle, sum2Cycle);
}

int main() {
    int t;
    for (cin >> t; t > 0; t--) {
        int n;
        cin >> n;
        vector<int> bff;
        for (int i = 0; i < n; i++) {
            int k;
            cin >> k;
            bff.push_back(k);
        }

        cout << superhero(n, bff) << endl;
    }
}