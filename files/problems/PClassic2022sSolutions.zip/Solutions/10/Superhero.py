def superhero(n, bff):
    # Reversed graph
    rbff = [[] for _ in bff]
    for i in range(len(bff)):
        rbff[bff[i]].append(i)
    # Find cycle
    bestCycle = 0
    visited = set()
    finished = set()
    sum2Cycle = 0
    
    def arms(node, length, otherarm):
        if node == otherarm:
            return 0
        visited.add(node)
        neighbors = rbff[node]
        if len(neighbors) == 0:
            return length
        return max([arms(neighbor, length + 1, otherarm) for neighbor in neighbors])
    
    for i in range(n):
        curr = i
        if not i in finished:
            while not curr in visited and not curr in finished:
                visited.add(curr)
                curr = bff[curr]
            if curr in visited:
                # found cycle, count cycle
                cycleSize = 1
                cycleEnd = curr
                while bff[curr] != cycleEnd:
                    cycleSize += 1
                    curr = bff[curr]
                if cycleSize == 2:
                    # 2 cycle case
                    l = curr
                    r = cycleEnd
                    sum2Cycle += 2
                    sum2Cycle += arms(l, 0, r)
                    sum2Cycle += arms(r, 0, l)
                bestCycle = max(bestCycle, cycleSize)
            finished = finished.union(visited)
            visited = set()
    return max(bestCycle, sum2Cycle)
                

# Do not modify below this line
if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        n = int(input())
        bff = []
        for i in range(n):
            bff.append(int(input()))
        print(superhero(n, bff))