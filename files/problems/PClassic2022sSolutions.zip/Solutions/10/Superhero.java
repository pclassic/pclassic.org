import java.io.*;
import java.util.*;

public class Main {
	public static int superhero(int n, int[] bff) {
		// Reversed graph
		ArrayList<ArrayList<Integer>> rbff = new ArrayList<ArrayList<Integer>>(n);
		while (rbff.size() < n) {
		    rbff.add(new ArrayList<Integer>());
		}
		for (int i = 0; i < n; i++) {
		    rbff.get(bff[i]).add(i);
		}

		// Find cycle
		int bestCycle = 0;
		Set<Integer> visited = new HashSet<Integer>();
		Set<Integer> finished = new HashSet<Integer>();
		int sum2Cycle = 0;
		
		
		for (int i = 0; i < n; i++) {
		    int curr = i;
		    if (!finished.contains(i)) {
		        while (!visited.contains(curr) && !finished.contains(curr)) {
		            visited.add(curr);
		            curr = bff[curr];
		        }
		        if (visited.contains(curr)) {
		            // found cycle, count cycle
		            int cycleSize = 1;
		            int cycleEnd = curr;
		            while (bff[curr] != cycleEnd) {
		                cycleSize += 1;
		                curr = bff[curr];
		            }
		            if (cycleSize == 2) {
		                // 2 cycle case
		                int l = curr;
		                int r = cycleEnd;
		                sum2Cycle += 2;
		                sum2Cycle += arms(rbff, visited, l, 0, r);
                        sum2Cycle += arms(rbff, visited, r, 0, l);
		            }
		            bestCycle = Math.max(bestCycle, cycleSize);
		        }
		        finished.addAll(visited);
	            visited = new HashSet<Integer>();
		    }
		}
		return Math.max(bestCycle, sum2Cycle);
	}
	
	public static int arms(ArrayList<ArrayList<Integer>> rbff, Set<Integer> visited, int node, int length, int otherarm) {
		    if (node == otherarm) {
		        return 0;
		    }
		    visited.add(node);
		    ArrayList<Integer> neighbors = rbff.get(node);
		    if (neighbors.size() == 0) {
		        return length;
		    }
		    int max = 0;
		    for (int neighbor: neighbors) {
		         max = Math.max(max, arms(rbff, visited, neighbor, length + 1, otherarm));
		    }
		    return max;
		}

	// Do not modify below this line
	public static void main(String[] args) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		int t = Integer.valueOf(reader.readLine());
		for (int i = 0; i < t; i++) {
			int n = Integer.valueOf(reader.readLine());
			int[] bff = new int[n];
			for (int j = 0; j < n; j++) {
			    bff[j] = Integer.valueOf(reader.readLine());
			}
			int output = superhero(n, bff);
			System.out.println(output);
		}
	}
	
	
}