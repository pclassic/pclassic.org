import java.util.*;
import java.io.*;
import java.math.*;

public class Main {
    
    public static String[][] fillMosaic(int gridWidth, int gridHeight) {
        int rows = gridHeight;
        int cols = gridWidth;
        String[][] grid = new String[rows][cols];
        for (int j = 0; j < cols; j++) grid[0][j] = ".";
        grid[0][(int) Math.floor(cols/2)] = "#";
        Map<String, String> rules = new HashMap<>();
        rules.put("###", ".");
        rules.put("##.", "#");
        rules.put("#.#", "#");
        rules.put("#..", "#");
        rules.put(".##", "#");
        rules.put(".#.", "#");
        rules.put("..#", "#");
        rules.put("...", ".");
        for (int i = 1; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                String northeast = j != 0 ? grid[i-1][j-1] : ".";
                String north = grid[i-1][j];
                String northwest = j != cols-1 ? grid[i-1][j+1] : ".";
                String rule = northeast + north + northwest;
                grid[i][j] = rules.get(rule);
            }
        }
        return grid;
    }
    
 // Do not modify below this line
    public static void printMosaic(String[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                System.out.print(grid[i][j]);
            }
            System.out.println();
        }
    }
    
    public static void main (String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        while (n-->0) {
            String[] sa = br.readLine().split(" ");
            printMosaic(fillMosaic(Integer.parseInt(sa[0]),Integer.parseInt(sa[1])));
        }
    }
}
