using namespace std;

#include <iostream>

#include <bits/stdc++.h>

void printarray(vector<vector<char>> arr, int width, int height) {
    for(int i = 0; i < height; i++) {
        for(int j = 0; j < width; j++) {
            cout << arr[i][j];
        }
        cout << endl;
    }

}

char mapper(char l, char m, char r) {
    if (l == '#') {
        if (m == '#') {
            if (r == '#') {
                return '.';
            } else {
                return '#';
            }
        } else {
            return '#';
        }
    } else {
        if (m == '#') {
            return '#';
        } else {
            return r;
        }
    }
}

vector<vector<char>> fillMosaic(int width, int height) {
    vector<vector<char>> val;
    vector<char> v1(width);
    
    for (int i = 0; i < width; i++) {
        if (width / 2 == i) {
            v1[i] = '#';
        }
        else {
            v1[i] = '.';
        }
    }
    
    val.push_back(v1);

    for (int i = 1; i < height; i++) {
        vector<char> v2;
        for (int j = 0; j < width; j++) {
            int amount = 0;
            char northwest = j != 0 ? val[i - 1][j - 1] : '.';
            char north = val[i - 1][j];
            char northeast = j != width - 1 ? val[i - 1][j + 1] : '.';
            v2.push_back(mapper(northwest, north, northeast));
        }
        val.push_back(v2);
        // for (int j = 0; j < width; j++) {
        //     cout << val[i][j] << endl;
        // }
    }
    return val;

}

int main() {
    int tests, width, height;
    cin >> tests;
    for (int i = 0; i < tests; i++) {
        cin >> width >> height;
        printarray(fillMosaic(width, height), width, height);
    }
}
