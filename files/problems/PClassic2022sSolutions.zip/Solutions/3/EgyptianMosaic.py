import math

def fillMosaic(gridWidth, gridHeight):
    cols = gridWidth
    rows = gridHeight
    grid = [['.' for i in range(cols)] for j in range(rows)]
    grid[0][math.floor(cols/2)] = '#'
    rules = dict()
    rules['###'] = '.'
    rules['##.'] = '#'
    rules['#.#'] = '#'
    rules['#..'] = '#'
    rules['.##'] = '#'
    rules['.#.'] = '#'
    rules['..#'] = '#'
    rules['...'] = '.'
    for i in range(1, rows):
        for j in range(cols):
            northwest =  grid[i-1][j-1] if j != 0 else '.'
            north = grid[i-1][j]
            northeast = grid[i-1][j+1] if j != cols-1 else '.'
            rule = northwest + north + northeast
            grid[i][j] = rules[rule]
    return grid

# Do not modify below this line
def printMosaic(grid):
    for i in range(len(grid)):
        for j in range(len(grid[0])):
            print(grid[i][j], end="")
        print()
    return

if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        line = input().split()
        printMosaic(fillMosaic(int(line[0]), int(line[1])))