import java.io.*;
import java.util.HashMap;

public class Main {      
    public static boolean checkMessages(String s, String t) {
        if (s.length() != t.length()) {
            return false;
        }
        
        HashMap<Character, Character> map = new HashMap<>();
        for (int i = 0; i < s.length(); i++) {
            if (map.containsKey(s.charAt(i))) {
                if ((Character) map.get(s.charAt(i)) != (t.charAt(i))) {
                    return false;
                }
            } else {
                if (map.containsValue(t.charAt(i))) {
                    return false;
                }
                map.put(s.charAt(i), t.charAt(i));
            }
        }
        return true;
    }

    // Do not modify below this line  
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tests = Integer.parseInt(br.readLine());
        for (int i = 0; i < tests; i++) {
            String s = br.readLine();
            String t = br.readLine();
            if (checkMessages(s,t)) {
                System.out.println("yes");
            } else {
                System.out.println("no");
            }
        }
        br.close();
    }

}