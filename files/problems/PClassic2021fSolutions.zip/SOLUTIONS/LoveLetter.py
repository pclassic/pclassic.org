# Implement the following method
def checkMessages(s, t):
  dictST = {}
  dictTS = {}
  if len(s) != len(t):
    return False
  else:
    for i in range(len(s)):
      if s[i] in dictST and t[i] not in dictTS or s[i] not in dictST and t[i] in dictTS:
        return False
      elif s[i] in dictST and t[i] in dictTS:
        if dictST.get(s[i]) != t[i] or dictTS.get(t[i]) != s[i]:
          return False
      else:
        dictST[s[i]] = t[i]
        dictTS[t[i]] = s[i]
  return True


# Do not modify below this line
if __name__ == '__main__':
    tests = int(input().strip())
    for tests in range(tests):
        s = input().strip()
        t = input().strip()
        if checkMessages(s, t):
            print("yes")
        else:
            print("no")
