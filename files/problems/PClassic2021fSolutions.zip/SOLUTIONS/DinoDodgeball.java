import java.util.*;
import java.io.*;
public class Main{
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        int t = Integer.parseInt(reader.readLine());
        for (int q=0; q<t; q++) {
            String[] sa = reader.readLine().split(" ");
            int n = Integer.parseInt(sa[0]);
            int k = Integer.parseInt(sa[1]);
            int[][] hits = new int[k][3];
            for (int i = 0; i < k; i++) {
            	String[] sa2 = reader.readLine().split(" ");
                hits[i][0] = Integer.parseInt(sa2[0]);
                hits[i][1] = Integer.parseInt(sa2[1]);
                hits[i][2] = Integer.parseInt(sa2[2]);

            }
            int count = netTemperature(n, hits);
            System.out.println(count);
        }
        reader.close();
    }

    public static int netTemperature(int n, int[][] temperatures) {
        int[] temps = new int[n];
        int k = temperatures.length;
        for (int i = 0; i < k; i++) {
            int pterodactyl = temperatures[i][1];
            int temp = temperatures[i][2];
            temps[pterodactyl] += temp;
        }
        int result = 0;
        for (int i = 0; i < n; i++) {
            if (temps[i] == 0) {
                result++;
            }
        }
        return result;
    }
}