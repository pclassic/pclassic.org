import java.io.*;
import java.util.*;

public class PandaLand {
    public static int pandaLand (int n, int m, String s) {

        int[] collect_rows = new int[n];
        int[] collect_cols = new int[m];

        int[][] path = new int[n + m - 1][2];

        //row, col
        int curr = 0;
        int curc = 0;

        collect_rows[0]++;
        collect_cols[0]++;
        path[0][0] = 0;
        path[0][1] = 0;
        for (int i = 0; i < n + m - 2; i++) {
            char c = s.charAt(i);
            if (c == 'R') {
                curc++;
            } else {
                curr++;
            }
            collect_rows[curr]++;
            collect_cols[curc]++;
            path[i + 1][0] = curr;
            path[i + 1][1] = curc;
        }

        long[] power1 = new long[2 * (n + m + 1)];
        long[] power2 = new long[2 * (n + m + 1)];

        ArrayList<ArrayList<Long>> p1 = new ArrayList<>();
        ArrayList<ArrayList<Long>> p2 = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            power1[collect_rows[i]]++;
        }
        for (int i = 0; i < m; i++) {
            power2[collect_cols[i]]++;
        }

        for (int i = 0; i < n + m + 1; i++) {
            if (power1[i] > 0) {
                p1.add(new ArrayList<>());
                p1.get(p1.size() - 1).add((long) i);
                p1.get(p1.size() - 1).add(power1[i]);
            }
            if (power2[i] > 0) {
                p2.add(new ArrayList<>());
                p2.get(p2.size() - 1).add((long) i);
                p2.get(p2.size() - 1).add(power2[i]);
            }
        }

        //multiply polynomials
        long[] powers = new long[400005];
        for (ArrayList<Long> x: p1) {
            for (ArrayList<Long> y: p2) {
                powers[(int) (x.get(0) + y.get(0))] += (long) x.get(1) * y.get(1);
            }
        }

        //delete overlap
        for (int i = 0; i < n + m - 1; i++) {
            int overlap = collect_rows[path[i][0]] + collect_cols[path[i][1]];
            powers[overlap]--;
            powers[overlap - 1]++;
        }

        ArrayList<long[]> ret = new ArrayList<>();
        for (int i = 0 ; i < 400005; i++) {
            if (powers[i] > 0) {
                ret.add(new long[2]);
                ret.get(ret.size() - 1)[0] = i;
                ret.get(ret.size() - 1)[1] = powers[i];
            }
        }

        //greedily assign
        final long MOD = 1000000007;

        long ans = 0;
        long val = 0;

        for (int i = ret.size() - 1; i >= 0; i--) {
            long[] p = ret.get(i);
            long pow = p[0] % MOD;
            long num = p[1];

            long nxt = val + num;
            long part1;
            if (nxt % 2 == 0) {
                part1 = (((nxt/2) % MOD) * ((nxt - 1) % MOD)) % MOD;
            } else {
                part1 = (((nxt) % MOD) * ((nxt - 1)/2 % MOD)) % MOD;
            }
            long part2;
            if (val == 0) {
                part2 = 0;
            } else if (val % 2 == 0) {
                part2 = (((val/2) % MOD) * ((val - 1) % MOD)) % MOD;
            } else {
                part2 = (((val) % MOD) * ((val - 1)/2 % MOD)) % MOD;
            }

            long pw = part1 - part2;
            if (pw < 0) {
                pw += MOD;
            }
            pw %= MOD;

            ans = (ans + (pow * pw) % MOD) % MOD;
            val = nxt;
        }

        return (int) ans;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tests = Integer.parseInt(br.readLine());
        for (int i = 0; i < tests; i++) {
            String[] inp = br.readLine().split(" ");
            int n = Integer.parseInt(inp[0]);
            int m = Integer.parseInt(inp[1]);
            String s = br.readLine();
            System.out.println(pandaLand(n, m, s));
        }
        br.close();
    }
}
