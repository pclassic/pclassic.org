def maxPoints(s, t):
    match = 1
    mismatch = -1
    gap = -2

    n = len(s)
    m = len(t)

    table = [[0 for j in range(m + 1)] for i in range(n + 1)]

    for j in range(m + 1):
        table[0][j] = gap * j
    for i in range(n + 1):
        table[i][0] = gap * i

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            diagonal = table[i - 1][j - 1]
            if (s[i - 1] == t[j - 1]):
                diagonal += match
            else:
                diagonal += mismatch

            left = table[i][j - 1] + gap
            up = table[i - 1][j] + gap

            table[i][j] = max(diagonal, left, up)

    return table[n][m]


# Do not modify below this line
if __name__ == '__main__':
    tests = int(input().strip())
    for test in range(tests):
        s = input().strip()
        t = input().strip()
        print(maxPoints(s, t))
