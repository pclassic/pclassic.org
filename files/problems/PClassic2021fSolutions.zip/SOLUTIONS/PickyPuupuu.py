# Implement the following method
def magicSquare(grid):
    n = len(grid)
    m = len(grid[0])
    for i in range(0, n):
        for j in range(0,m):
            if i + 3 >n or j + 3 >m:
                continue
            if isMagicSquare(i, j, grid):
                return True
    
    return False


def isMagicSquare(i, j, grid):
    sum = grid[i][j]+grid[i][j+1] + grid[i][j+2]
    for k in range(i,i+3):
        if grid[k][j]+grid[k][j+1] + grid[k][j+2] != sum:
            return False
            
    for k in range(j,j+3):
        if grid[i][k]+grid[i+1][k] + grid[i+2][k] != sum:
            return False
        
    if grid[i][j]+grid[i+1][j+1] + grid[i+2][j+2] != sum:
        return False
        
    if grid[i][j+2]+grid[i+1][j+1] + grid[i+2][j] != sum:
        return False
        
    return True



if __name__ == '__main__':
    tests = int(input().strip())
    for test in range(tests):
        grid = []
        while True:
            s = input().strip()
            if s == '':
                break
            row = s.split(" ")
            row = list(map(int, row))
            grid.append(row)
        if magicSquare(grid):
            print("true")
        else:
            print("false")
