def decode(s, k):
    minRange = ord('a')
    ans = ""
    for c in s:
        if c.isalpha():
              ans += chr(((ord(c) - minRange - k) % 26) + minRange)
        else:
            ans += c
    return ans

if __name__ == '__main__':
    tests = int(input())
    for _ in range(tests):
        s = input()
        k = int(input())
        print(decode(s, k))