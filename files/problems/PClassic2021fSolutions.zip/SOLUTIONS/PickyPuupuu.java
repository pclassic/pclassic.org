import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import java.util.stream.*;
import static java.util.stream.Collectors.toList;

public class Main {
    // Do not modify below this line
    public static void main(String[] args) throws Exception {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      int tests = Integer.parseInt(br.readLine());
      for (int i = 0; i < tests; i++) {
          List<List<Integer>> arr = new ArrayList<>();

          while (true) {
              String s = br.readLine();
              if (s.equals("")) {
                  break;
              }
              arr.add(Stream.of(s.trim().split(" ")).map(Integer::parseInt).collect(toList()));
          }

          int[][] grid = new int[arr.size()][arr.get(0).size()];

          for (int k = 0; k < arr.size(); k++) {
              for (int j = 0; j < arr.get(0).size(); j++) {
                  grid[k][j] = arr.get(k).get(j);
              }
          }

          if (magicSquare(grid)) {
              System.out.println("true");
          } else {
              System.out.println("false");
          }
      }
      br.close();
    }

    // Do not modify above this line

    public static boolean magicSquare(int[][] grid) {
        for (int i = 0; i <= grid.length - 3; i++) {
            for (int j = 0; j <= grid[i].length - 3; j++) {
                if (isMagicSquare(i, j, grid)) {
                    return true;
                }
            }
        }
        return false;

    }
    
    public static boolean isMagicSquare(int i, int j, int[][] grid) {
    // determines from upper left corner of square
        int sum = grid[i][j] + grid[i][j + 1] + grid[i][j + 2];

        for (int k = i; k < i + 3; k++) { // each row
            if (grid[k][j] + grid[k][j + 1] + grid[k][j + 2] != sum) {
                return false;
            }
        }
        for (int k = j; k < j + 3; k++) { // each col
            if (grid[i][k] + grid[i + 1][k] + grid[i + 2][k] != sum) {
                return false;
            }
        }

        if (grid[i][j] + grid[i + 1][j + 1] + grid[i + 2][j + 2] != sum) return false;
        if (grid[i + 2][j] + grid[i + 1][j + 1] + grid[i][j + 2] != sum) return false;
        return true;
    }

}