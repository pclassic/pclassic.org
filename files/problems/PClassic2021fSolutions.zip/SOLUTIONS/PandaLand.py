def pandaLand(n, m, s):
    #modulo
    MOD = 1000000007

    collect_rows = [0] * n
    collect_cols = [0] * m

    #keep track of the path
    path = [[0, 0]]

    #cur is the position (row, column)
    cur = [0, 0]
    collect_rows[0] = 1
    collect_cols[0] = 1
    
    for c in s:
        if c == 'R':
            cur[1] += 1
        else:
            cur[0] += 1
        collect_rows[cur[0]] += 1
        collect_cols[cur[1]] += 1
        path.append([cur[0], cur[1]])

    #construct polynomials for the row/col
    power1 = [0] * (n + m + 1)
    power2 = [0] * (n + m + 1)
    p1 = []
    p2 = []
    
    for i in range(n):
        power1[collect_rows[i]] += 1
        
    for i in range(m):
        power2[collect_cols[i]] += 1

    for i in range(n+m+1):
        if power1[i] > 0:
            p1.append([i, power1[i]])
        if power2[i] > 0:
            p2.append([i, power2[i]])
        

    #multiply polynomials
    powers = [0] * 200005
    for x in p1:
        for y in p2:
            powers[x[0] + y[0]] += x[1] * y[1]

    #delete overlap
    for p in path:
        overlap = collect_rows[p[0]] + collect_cols[p[1]]
        powers[overlap] -= 1
        powers[overlap - 1] += 1

    #construct resulting polynomial
    ret = []
    for i in range(200005):
        if powers[i] > 0:
            ret.append([i, powers[i]])

    #greedily assign values to cells
    ans = 0
    val = 0
    for i in range(len(ret)):
        p = ret[len(ret) - i - 1]
        cpow = p[0]
        num = p[1]

        nxt = val + num
        pw = 0
        if nxt % 2 == 0:
            pw += int(nxt/2) * (nxt - 1)
        else:
            pw += nxt * int((nxt - 1)/2)

        if val % 2 == 0:
            pw -= int(val/2) * (val - 1)
        else:
            pw -= val * int((val - 1)/2)

        ans += cpow * pw
        val = nxt

    return int(ans % MOD)

# Do not modify below this line
def main():
    line1 = input()
    testCases = int(line1.split()[0])
    for i in range(0, testCases):
        inp = input().split()
        n = int(inp[0])
        m = int(inp[1])
        path = input().strip()
        print(pandaLand(n, m, path))

if __name__ == "__main__":
    main()
