import java.io.*;

public class CactusFarm {
    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tests = Integer.parseInt(br.readLine());
        for (int i = 0; i < tests; i++) {
            String s = br.readLine();
            String t = br.readLine();
            if (matchable(s, t))
                System.out.println("1");
            else
                System.out.println("0");
        }
        br.close();
    }
    //Do not modify above this line

    public static void or(StringBuilder s, StringBuilder res) {
        int sLength = s.length();
        int resLength = res.length();
        int count = 0;
        while (count < sLength && count < resLength) {
            if (s.charAt(count) == '1') {
                res.setCharAt(count, '1');
            }
            count++;
        }
        if (count == resLength) {
            res.append(s.substring(count));
        }
    }

    public static boolean shiftPossible(StringBuilder s, String t) {
        int sLength = s.length();
        int tLength = t.length();
        int count = 0;
        while (count < sLength && count < tLength) {
            if (s.charAt(count) == '1' && t.charAt(count) == '0')
                return false;
            count++;
        }
        if (count != sLength)
            return false;
        return true;
    }

    public static boolean matchable(String initialPattern, String finalPattern) {
        StringBuilder s2 = new StringBuilder(initialPattern);
        StringBuilder res = new StringBuilder(initialPattern);
        StringBuilder shifted = new StringBuilder(initialPattern);
        int sLen = s2.length();
        int tLen = finalPattern.length();
        int shifts = tLen - sLen;
        for (int shift = 1; shift <= shifts; shift++) {
            shifted.insert(0, '0');
            if (shiftPossible(shifted, finalPattern)) 
                or(shifted, res);
        }
        return res.toString().equals(finalPattern);
    }
        
}