import java.io.*;

public class SecretCode {
    public static void main(String[] args) throws Exception {
      BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
      int tests = Integer.parseInt(br.readLine());
      for (int i = 0; i < tests; i++) {
          String msg = br.readLine();
          int shift = Integer.parseInt(br.readLine());
          System.out.println(decode(msg,shift));
      }
      br.close();
    }
    //Do not modify above this line
    
    public static String decode(String s, int k) {
       k = -k % 26;
       s = s.toLowerCase();
       char[] ca = s.toCharArray();
        for (int i = 0; i < ca.length; i++) {
            if (!Character.isLetter(ca[i])) continue;
            int num = (int) ca[i] - 97 + k;
            if (num >= 26) {
                num -= 26;
            }
            else if (num < 0) {
                num += 26;
            }
            ca[i] = (char) (97 + num);
        }
      return String.valueOf(ca);
    }
}
