import java.io.*;

public class Main {
  public static int maxPoints(String s, String t) {
    int match = 1;
    int mismatch = -1;
    int gap = -2;
    int n = s.length();
    int m = t.length();
    int[][] table = new int[n + 1][m + 1];

    for (int j = 0; j < m + 1; j++) {
      table[0][j] = gap * j;
    }
    for (int i = 0; i < n + 1; i++) {
      table[i][0] = gap * i;
    }
    for (int i = 1; i < n + 1; i++) {
      for (int j = 1; j < m + 1; j++) {
        int diagonal = table[i - 1][j - 1];
        if (s.charAt(i - 1) == t.charAt(j - 1)) {
          diagonal += match;
        } else { 
          diagonal += mismatch;
        }
        int left = table[i][j - 1] + gap;
        int up = table[i - 1][j] + gap;
        table[i][j] = Math.max(diagonal, Math.max(left, up));
      }
    }
    return table[n][m];
  }

  // Do not modify below this line
  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    int tests = Integer.parseInt(br.readLine());
    for (int i = 0; i < tests; i++) {
      String s = br.readLine();
      String t = br.readLine();
      System.out.println(maxPoints(s, t));
    }
    br.close();
  }
}
