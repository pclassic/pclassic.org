import java.util.*;
import java.io.*;

public class PretentiousPeacocks {
    final static int maxv = 100005;
    static int[] st = new int[2 * maxv];
    public static int ret = 0;

    static int query(int l, int r) {
        return query(0, 0, maxv-1, l, r);
    }

    static int query(int v, int tl, int tr, int l, int r) {
        if (l > r) return 0;
        if (l == tl && r == tr) {
            return st[v];
        }
        int tm = (tl + tr)/2;

        return Math.max(query(v+1, tl, tm, l, Math.min(tm, r)),
                        query(v + 2 * (tm - tl + 1), tm + 1, tr, Math.max(l, tm + 1), r));
    }

    public static void upd(int pos, int newVal) {
        upd(0, 0, maxv - 1, newVal, pos);
    }

    static void upd(int v, int tl, int tr, int newVal, int pos) {
        if (tl == tr) {
            st[v] = newVal;
        } else {
            int tm = (tl + tr)/2;

            if (pos <= tm) {
                upd(v+1, tl, tm, newVal, pos);
            } else {
                upd(v + 2 * (tm - tl + 1), tm + 1, tr, newVal, pos);
            }
            st[v] = Math.max(st[v+1], st[v + 2 * (tm - tl + 1)]);
        }
    }

    static ArrayList<ArrayList<Integer>> revg;
    static int[][] vals;

    static void dfs(int v) {
        int a = vals[v][0], b = vals[v][1];
        if (query(a, maxv-1) < b) {
            ret++;
        }
        int prev = query(a, a);
        if(prev < b) {
            upd(a, b);
        }
        for (int u: revg.get(v)) {
            dfs(u);
        }

        if (prev < b) {
            upd(a, prev);
        }
    }

    public static int unbeatable(int n, int[][] pvals, int[] out) {
        vals = pvals;
        st = new int[2 * maxv];
        ret = 0;

        revg = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            revg.add(new ArrayList<>());
            out[i]--;
            vals[i][0] += 1;
            vals[i][1] += 1;
        }

        for (int i = 0; i < n; i++) {
            int u = i;
            int v = out[i];
            revg.get(v).add(u);
        }

        ArrayList<ArrayList<Integer>> cycles = new ArrayList<>();
        int cur = 0;
        boolean[] vis = new boolean[n];

        for (int i = 0; i < n; i++) {
            if (!vis[i]) {
                int v = out[i];
                vis[i] = true;
                Set<Integer> seen = new HashSet<>();
                seen.add(i);

                while (!vis[v]) {
                    seen.add(v);
                    vis[v] = true;
                    v = out[v];
                }
                if (!seen.contains(v)) continue;
                cycles.add(new ArrayList<>());
                cycles.get(cur).add(v);
                v = out[v];
                while (v != cycles.get(cur).get(0)) {
                    cycles.get(cur).add(v);
                    v = out[v];
                }
                cur++;
            }
        }

        vis = new boolean[n];

        for (int i = 0; i < cur; i++) {
            for (int j = 0; j < cycles.get(i).size(); j++) {
                int v = cycles.get(i).get(j);
                vis[v] = true;
                int a = vals[v][0], b = vals[v][1];
                if (query(a, a) < b) {
                    upd(a, b);
                }
            }

            for (int j = 0; j < cycles.get(i).size(); j++) {
                int v = cycles.get(i).get(j);
                int a = vals[v][0], b = vals[v][1];
                if (query(a+1, maxv-1) < b && query(a, a) == b) {
                    ret++;
                }

                for (int u: revg.get(v)) {
                    if (!vis[u]) {
                        dfs(u);
                    }
                }
            }
            for (int j = 0; j < cycles.get(i).size(); j++) {
                int v = cycles.get(i).get(j);
                int a = vals[v][0];
                upd(a, 0);
            }
        }

        return ret;
    }

    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tests = Integer.parseInt(br.readLine());
        for (int i = 0; i < tests; i++) {
            int n = Integer.parseInt(br.readLine());
            int[][] pvals = new int[n][2];
            int[] nout = new int[n];
            for (int j = 0; j < n; j++) {
                String[] tmp = br.readLine().split(" ");
                pvals[j][0] = Integer.parseInt(tmp[0]);
                pvals[j][1] = Integer.parseInt(tmp[1]);
            }
            for (int j = 0; j < n; j++) {
                nout[j] = Integer.parseInt(br.readLine());
            }
            System.out.println(unbeatable(n, pvals, nout));
        }
        br.close();
    }
}
