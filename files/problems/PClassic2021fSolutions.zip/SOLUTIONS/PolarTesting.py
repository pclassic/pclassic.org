import math
def testing(bears, testtime, totaltime):
    states = (totaltime / testtime) + 1
    return math.ceil(math.log(bears) / math.log(states))

if __name__ == '__main__':
    while True:
        s = input().strip()
        if s == '':
            break
        for i in range(int(s)):
            sa = input().strip().split(" ")
            print(testing(int(sa[0]), int(sa[1]), int(sa[2])))
        break
