def reversedMessage(message, k):
    newMessage = []
    for i in range(len(message) - k):
        newMessage.append(message[i])
    for i in range(len(message) - 1, len(message) - k - 1, -1):
        newMessage.append(message[i])
    return "".join(newMessage)

# Do not modify below this line
if __name__ == '__main__':
    tests = int(input())
    for test in range(tests):
        line = input().split()
        print(reversedMessage(line[0], int(line[1])))
