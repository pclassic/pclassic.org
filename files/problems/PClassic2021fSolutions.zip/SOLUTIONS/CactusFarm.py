def orString(s, t):
    sLen = len(s)
    tLen = len(t)
    count = 0
    while (count < sLen and count < tLen):
        if s[count] == '1':
            t[count] = '1'
        count = count + 1
    if (count == tLen):
        t.extend(s[count:])

def shiftPossible(s, t):
    sLen = len(s)
    tLen = len(t)
    count = 0
    while (count < sLen and count < tLen):
        if s[count] == '1' and t[count] == '0':
            return False
        count = count + 1
    
    if count != sLen:
        return False
    return True
        

def matchable(initialPattern, finalPattern):
    tList = list(finalPattern)
    shifted = list(initialPattern)
    res = list(initialPattern)
    shifts = len(finalPattern) - len(initialPattern)
    for i in range(1, shifts + 1):
        shifted.insert(0, '0')
        if (shiftPossible(shifted, tList)):
            orString(shifted, res)
    return res == tList
    

if __name__ == "__main__":
    line1 = input()
    testCases = int(line1.split()[0])
    for i in range(0, testCases):
        s = input()
        t = input()
        res = matchable(s, t)
        if res:
            print('1')
        else:
            print('0')