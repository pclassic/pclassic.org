import java.util.*;
import java.io.*;

public class PompousPeacocks {
    public void run() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int tests = Integer.parseInt(br.readLine());
        for (int i = 0; i < tests; i++) {
            List<List<Integer>> peacockStats = new ArrayList<>();
            int pos = 0;
            while (true) {
                String peacockStatsLine = br.readLine();
                if (peacockStatsLine == null || peacockStatsLine.equals(""))
                    break;
                peacockStats.add(new ArrayList<Integer>());

                String[] peacockStat = peacockStatsLine.split(" ");
                peacockStats.get(pos).add(Integer.parseInt(peacockStat[0]));
                peacockStats.get(pos).add(Integer.parseInt(peacockStat[1]));
                pos++;
            }

            int[][] peacocks = new int[peacockStats.size()][peacockStats.get(0).size()];

            for (int k = 0; k < peacockStats.size(); k++) {
                for (int j = 0; j < peacockStats.get(0).size(); j++) {
                    peacocks[k][j] = peacockStats.get(k).get(j);
                }
            }

            System.out.println(unbeatable(peacocks));
        }
        br.close();
    }

    public static void main(String[] args) throws Exception {
        new PompousPeacocks().run();
    }
    // Do not modify above this line

    public int unbeatable(int[][] peacocks) {
        List<Pair> list = new LinkedList<>();
        // Create a list of pairs
        for (int[] peacock : peacocks) {
            list.add(new Pair(peacock[0], peacock[1]));
        }
        Collections.sort(list);
        int bestB = Integer.MIN_VALUE; // Best value seen from index 1
        int bestA = Integer.MAX_VALUE; // Best value seen from index 0
        int count = 0;
        for (Pair p : list) {
            if (p.b > bestB || (p.a == bestA && p.b == bestB)) {
                count++;
                bestB = p.b;
                bestA = p.a;
            }
        }
        return count;
    }

}

class Pair implements Comparable<Pair> {
    int a;
    int b;

    public Pair(int x, int y) {
        this.a = x;
        this.b = y;
    }

    @Override
    public int compareTo(Pair o) {
        if (a > o.a) {
            return -1;
        } else if (a == o.a) {
            if (b > o.b) {
                return -1;
            } else if (b == o.b) {
                return 0;
            } else {
                return 1;
            }
        } else {
            return 1;
        }
    }
}