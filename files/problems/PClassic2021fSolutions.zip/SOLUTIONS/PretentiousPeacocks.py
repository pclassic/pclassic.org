maxv = 100005
t = [0] * (2 * maxv + 1)
ret = 0

def clear():
    t = [0] * (2 * maxv + 1)

def mx(l, r):
    return mx_util(1, 0, maxv-1, l, r)

def mx_util(v, tl, tr, l, r):
    if l > r:
        return 0
    if l == tl and r == tr:
        return t[v]
    tm = int((tl + tr)/2)
    
    return max(mx_util(v+1, tl, tm, l, min(r, tm)),
               mx_util(v + 2 * (tm - tl + 1), tm + 1, tr, max(l, tm + 1), r))

def upd(pos, new_val):
    return upd_util(1, 0, maxv - 1, pos, new_val)

def upd_util(v, tl, tr, pos, new_val):
    if tl == tr:
        t[v] = new_val
    else:
        tm = int((tl + tr)/2)
        if pos <= tm:
            upd_util(v+1, tl, tm, pos, new_val)
        else:
            upd_util(v + 2 * (tm - tl + 1), tm + 1, tr, pos, new_val)
        t[v] = max(t[v + 1], t[v + 2 * (tm - tl + 1)])


def unbeatable(n, vals, out):
    global ret
    revg = []
    clear()

    ret = 0

    for i in range(n):
        vals[i][0] += 1
        vals[i][1] += 1
        revg.append([])
        out[i] -= 1

    for i in range(n):
        u = i
        v = out[i]
        revg[v].append(u)

    #find cycles
    cur = 0
    vis = [0] * n
    cycles = []

    for i in range(n):
        if vis[i] == 0:
            v = out[i]
            vis[i] = 1
            seen = set({})
            seen.add(i)

            while not vis[v]:
                seen.add(v)
                vis[v] = 1
                v = out[v]
            if not (v in seen):
                continue
            cycles.append([v])
            v = out[v]
            while (v != cycles[cur][0]):
                cycles[cur].append(v)
                v = out[v]
            cur += 1

    vis = [0] * n    

    for i in range(cur):
        for j in range(len(cycles[i])):
            v = cycles[i][j]
            vis[v] = 1
            a = vals[v][0]
            b = vals[v][1]
            if mx(a, a) < b:
                upd(a, b)

        
        def dfs(v):
            global ret
            a = vals[v][0]
            b = vals[v][1]
            
            if mx(a, maxv-1) < b:
                ret += 1

            prev = mx(a, a)
            if prev < b:
                upd(a, b)

            for u in revg[v]:
                dfs(u)

            if prev < b:
                upd(a, prev)

        for j in range(len(cycles[i])):
            v = cycles[i][j]
            a = vals[v][0]
            b = vals[v][1]
            if mx(a+1, maxv-1) < b and mx(a, a) == b:
                ret += 1
            for u in revg[v]:
                if not vis[u]:
                    dfs(u)

        for j in range(len(cycles[i])):
            v = cycles[i][j]
            a = vals[v][0]
            b = vals[v][1]
            upd(a, 0)

    return ret
        

if __name__ == "__main__":
    line1 = input()
    testCases = int(line1.split()[0])
    for i in range(0, testCases):
        n = int(input())
        vals = []
        out = [0] * n
        for i in range(n):
            inp = input().split()
            vals.append([int(inp[0]), int(inp[1])])
        for i in range(n):
            inp = input().split()
            u = i
            v = int(inp[0])
            out[u] = v
        print(unbeatable(n, vals, out))
