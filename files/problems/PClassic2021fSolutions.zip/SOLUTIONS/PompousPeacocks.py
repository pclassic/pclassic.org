from sys import maxsize
import sys


def unbeatable(peacocks):
    #peacocks[0] = vibrancy
    #peacocks[1] = confidence
    sortedByConfidence = sorted(peacocks, key=lambda x: x[1], reverse=True)
    sortedByVibrancy = sorted(
        sortedByConfidence, key=lambda x: x[0], reverse=True)
    count = 0
    lastVibrancy = peacocks[0][0]
    x = -maxsize
    for i in range(0, len(sortedByVibrancy)):
        # unbeatable if confidence > to all previous peacocks
        if sortedByVibrancy[i][1] > x:
            x = sortedByVibrancy[i][1]
            count += 1
        # unbeatable if it has max vibrancy
        elif sortedByVibrancy[i][0] == lastVibrancy and sortedByVibrancy[i][1] == x:
            count += 1
        lastVibrancy = peacocks[i][0]
    return count


# do not modify below
if __name__ == "__main__":
    total = int(sys.stdin.readline().strip())
    for i in range(total):
        sumos = []
        while True:
            s = sys.stdin.readline().strip()
            if s == '':
                break
            sumo = s.split(" ")
            sumo[0] = int(sumo[0])
            sumo[1] = int(sumo[1])
            sumos.append(sumo)
        print(unbeatable(sumos))
