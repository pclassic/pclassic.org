import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Pokepark {
	// Before submitting, make sure the main method hasn't been changed!
    // DO NOT MODIFY BELOW THIS LINE
    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("PokeparkIN.txt"));
        String[] data = br.readLine().split(" ");
        int testCases = Integer.parseInt(data[0]);
        for( ; testCases > 0; testCases--) {
	        data = br.readLine().split(" ");
	        int N = Integer.parseInt(data[0]);
	        int[] list = new int[N];
            data = br.readLine().split(" ");
	        for(int i = 0; i < N; i++){
	            list[i]=Integer.parseInt(data[i]);
	        }
	        System.out.println( solve(list) );
        }
        br.close();
       
    }   
    
    // DO NOT MODIFY ABOVE THIS LINE
 
    // Fill out the body of this method
    public static int solve(int[] list) {
        int n = list.length;
        int[][] dp = new int[n][n];
        int[][] opt = new int[n][n];
        int[] sp = new int[n+1];
        sp[0] = 0;
        for(int i=0; i<n; i++) {
        	sp[i+1] = sp[i] + list[i];
        }
        for(int i=0; i<n; i++) {
        	dp[i][i] = 0;
        	opt[i][i] = i;
        }
        for(int size=1; size < n; size++) {
        	for(int i=0; i<n; i++) {
        		int j = (i+size)%n;
        		int first = opt[i][(i+size-1)%n];
        		int last = opt[(i+1)%n][j];
        		dp[i][j] = dp[i][first] + dp[(first+1)%n][j];
        		opt[i][j] = first;
        		for(int k=first; ; k=(k+1)%n) {
        			if( dp[i][k] + dp[(k+1)%n][j] < dp[i][j] ) {
        				dp[i][j] = dp[i][k] + dp[(k+1)%n][j];
        				opt[i][j] = k;
        			}
        			if(k == last) break;
        		}
        		if( i < j ) {
        			dp[i][j] += sp[j+1] - sp[i];
        		}
        		else {
        			dp[i][j] += sp[n] - sp[i] + sp[j+1];
        		}
        	}
        }
        int answer = dp[0][n-1];
        for(int i=0; i<n-1; i++) {
        	answer = Math.min(answer, dp[i+1][i]);
        }
        return answer;
    }
}
