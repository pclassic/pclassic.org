def careerPivot(A):
    A.sort();
    minimum = 2147483647
    for i in range(len(A)-1):
        minimum = min(minimum, int(A[i]) ^ int(A[i+1]))
    return minimum

#Do not modify below this line
if __name__ == '__main__':
    with open('CareerPivotIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            s = s.split()
            s = [int(i) for i in s]
            print(careerPivot(s))
