def findNums(A, hp):
    cnt = 0
    found = False
    A.sort()
    for i in range(len(A) - 1):
        l = i + 1
        r = len(A) - 1
        x = A[i]
        while (l < r):
            if (x + A[l] + A[r] == hp):
                cnt += 1
                l += 1
                r -= 1
                found = True
            elif (x + A[l] + A[r] < hp):
                l += 1
            else:
                r -= 1
    if (found == True):
        return cnt
    else:
        return 0

#Do not modify below this line
if __name__ == '__main__':
    with open('BeatThatClefairyIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            t = f.readline().strip()
            if s == '':
                break
            t = (t.split(','))
            t = [int(i) for i in t]
            print(findNums(t, int(s)))
