import java.io.*;
import java.math.*;
import java.util.*;
 
public class GottaCatchEmAll {
   
  // Before submitting, make sure the main method hasn't been changed!
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("GottaCatchEmAllIN.txt"));

        while (br.ready()) {
            int n = Integer.parseInt(br.readLine());
            int rows = Integer.parseInt(br.readLine());
            String[] data = br.readLine().split(", ");
            long[][] A = new long[rows][data.length];
            
            for (int i = 0; i < data.length; i++) {
                A[0][i] = Long.parseLong(data[i]);
            }
            for (int i = 1; i < rows; i++) {
                data = br.readLine().split(", ");
                for (int j = 0; j < data.length; j++) {
                    A[i][j] = Long.parseLong(data[j]);
                }
            }
            System.out.println(gottaCatchEmAll(n, rows, A));
        }
        br.close();
    }

    public static String gottaCatchEmAll(int n, int rows, long[][] A) {
        int i = 0;
        int j = A[0].length - 1;
        // Start with top right element
        while (i < rows && j >= 0) {
            if (A[i][j] == n) return i + "," + j;
            if (A[i][j] > n) j--;
            else i++;
        }
        return "Pikachu is lost";
    }
}