from collections import defaultdict

def dfs(edges, query):
    fro, to = query
    if fro not in edges or to not in edges:
        return -1
    stack = [(fro, 1)]
    visited = set()
    while stack:
        current, current_rate = stack.pop()
        if current == to:
            # Reached our goal
            return current_rate
        if current not in visited:
            visited.add(current)
            for neighbor, rate in edges[current]:
                if neighbor not in visited:
                    stack.append((neighbor, current_rate*rate))
    return -1

def homefun(equations, values, queries):
    edges = defaultdict(list)
    q = []
    for i, eq in enumerate(equations):
        edges[eq[0]].append((eq[1], values[i]))
        edges[eq[1]].append((eq[0], 1 / values[i]))
    for query in queries:
        rate = float(dfs(edges, query))
        q.append(rate)
    return q
    
        

#Do not modify below this line
if __name__ == '__main__':
    with open('HomefunIN.txt', 'r') as f:
        num_eqs = int(f.readline().strip())
        eqs = []
        values = []
        for i in range(num_eqs):
            n1, n2, value = f.readline().split()
            value = float(value)
            eqs.append([n1, n2])
            values.append(value)
        num_queries = int(f.readline().strip())
        queries = []
        for i in range(num_queries):
            query = f.readline().split()
            queries.append(query)
        results = homefun(eqs, values, queries)
        for r in results:
            print ('%.2f' % r)
