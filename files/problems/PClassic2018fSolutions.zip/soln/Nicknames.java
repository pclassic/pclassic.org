import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.Math;

public class Nicknames {
	
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("NicknamesIN.txt"));
		
		while (br.ready()) {
			String s = br.readLine();
			System.out.println(getMostRepeating(s)); 
		} 
		
	}
	
	public static String getMostRepeating (String s) {
		int counter = 0;
		int highestCounter = 0;
		char longestChar = s.charAt(0);
		char currentChar = s.charAt(0);
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == currentChar) {
				counter++;
			} else {
				counter = 1;
				currentChar = s.charAt(i);
			}
			
			if (counter > highestCounter) {
				highestCounter = counter;
				longestChar = currentChar;
			}
		}
		
		String soln = "";
		for (int i = 0; i < highestCounter; i++) {
			soln += String.valueOf(longestChar);
		}
		
		return soln;
	}

}
