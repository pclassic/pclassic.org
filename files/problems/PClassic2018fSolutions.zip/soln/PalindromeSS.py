#!/usr/bin/env python3


def palindrome(s):
    for i in range(len(s), 0, -1):
        for j in range(0, len(s) - i + 1):
            if s[j:j+i] == s[j:j+i][::-1]:
                return s[j:j+i]
    return ""


if __name__ == "__main__":
    with open("PalindromeSSIN.txt", "r") as f:
        n = int(f.readline())
        for i in range(n):
            print(palindrome(f.readline().strip()))
