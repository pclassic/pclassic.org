import java.util.*;
import java.io.*;
import java.math.*;

public class Portals {
	static char[][] m;
	static int[][] sm;
	static TreeMap<Character, int[][]> tm;
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("PortalsIN.txt"));
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
	    while (n-->0) {
		    st = new StringTokenizer(br.readLine());
		    int r = Integer.parseInt(st.nextToken());
		    int c = Integer.parseInt(st.nextToken());
		    char[][] map = new char[r][c];
		    for (int i = 0; i < r; i++) {
		    	map[i] = br.readLine().toCharArray();
		    }
		    System.out.println(distance(map));
		    
		/*  //Uncomment to print shadow matrix
		  	for (int i = 0; i < r; i++) {
		    	for (int j = 0; j < c; j++) {
		    		String s = "";
		    		if (sm[i][j] == Integer.MAX_VALUE) s+= "M";
		    		else s+=sm[i][j];
		    		while(s.length() < 3) s+=" ";
		    		System.out.print(s);
		    	}
		    	System.out.println();
		    } */
	    }
	}
	
	public static int distance(char[][] map) {
		int r = map.length;
		int c = map[0].length;
		m = map;
		sm = new int[r][c];
		tm = new TreeMap<>();
		int sr = -1;
		int sc = -1;
		int er = -1;
		int ec = -1;
		for (int i = 0; i < r; i++) {
			Arrays.fill(sm[i], Integer.MAX_VALUE);
			for (int j = 0; j < c; j++) {
				if (m[i][j] == '$') {
					sr = i;
					sc = j;
				}
				if (m[i][j] == '&') {
					er = i;
					ec = j;
				}
				if (Character.isAlphabetic(m[i][j])) {
					if (tm.containsKey(m[i][j])) {
						int[][] tmap = tm.get(m[i][j]);
						tmap[1][0] = i;
						tmap[1][1] = j;
					}
					else {
						int[][] tmap = new int[2][2];
						tmap[0][0] = i;
						tmap[0][1] = j;
						tm.put(m[i][j], tmap);
					}
				}
			}
		}
		solve(sr, sc, 0);
		return sm[er][ec];
	}
	
	public static void solve (int r, int c, int dist) {
		if (r < 0 || r >= m.length || c < 0 || c >= m[r].length || m[r][c] == '#' || sm[r][c] <= dist) return;
		sm[r][c] = dist;
		solve(r+1, c, dist+1);
		solve(r-1, c, dist+1);
		solve(r, c+1, dist+1);
		solve(r, c-1, dist+1);
		if (Character.isAlphabetic(m[r][c])) {
			int[][] tmap = tm.get(m[r][c]);
			if (r == tmap[0][0] && c == tmap[0][1]) {
				solve(tmap[1][0],tmap[1][1],dist);
			}
			else {
				solve(tmap[0][0],tmap[0][1],dist);
			}
		}
	}
}
