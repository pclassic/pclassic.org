import java.util.*;
import java.io.*;
import java.math.*;

public class Homefun {
	double answer;
	
	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("HomefunIN.txt"));
		//given equations
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		String[][] equations = new String[n][2];
		double[] values = new double[n];
	    for (int i = 0; i < n; i++) { 
		    st = new StringTokenizer(br.readLine());
		    String num = st.nextToken();
		    String denom = st.nextToken();
		    double ans = Double.parseDouble(st.nextToken());
		    equations[i] = new String[]{num, denom};
		    values[i] = ans;
	    }
	    //queries
	    st = new StringTokenizer(br.readLine());
		n = Integer.parseInt(st.nextToken());
		String[][] queries = new String[n][2];
		for (int i = 0; i < n; i++) { 
		    st = new StringTokenizer(br.readLine());
		    String num = st.nextToken();
		    String denom = st.nextToken();
		    queries[i] = new String[]{num, denom};
	    }
		double[] answers = solve(equations, values, queries);
		for (double a : answers) {
			System.out.printf("%.2f%n",a);
		}
	}
	
	public double[] solve(String[][] equations, double[] values, String[][] queries) {
		double[] ans = new double[queries.length];
		List<String> ul = new ArrayList<String>();
		for (String[] sa : equations) {
			String num = sa[0];
			String denom = sa[1];
			if (!ul.contains(num)) ul.add(num);
			if (!ul.contains(denom)) ul.add(denom);
		}
		double[][] am = new double[ul.size()][ul.size()];
		for (int i = 0; i < equations.length; i++) {
			String[] sa = equations[i];
			double va = values[i];
			String num = sa[0];
			String denom = sa[1];
			int indn = ul.indexOf(num);
			int indd = ul.indexOf(denom);
			am[indn][indd] = va;
			am[indd][indn] = 1/va;
		}
		for (int i = 0; i < queries.length; i++) {
			String[] sa = queries[i];
			String num = sa[0]; //start
			String denom = sa[1]; //end
			if (!ul.contains(num) || !ul.contains(denom)) {
				ans[i] = -1.0;
				continue;
			}
			if (num.equals(denom)) {
				ans[i] = 1.0;
				continue;
			}
			int indn = ul.indexOf(num);
			int indd = ul.indexOf(denom);
			List<Integer> v = new ArrayList<Integer>();
			answer = 0;
			recur(am, indn, indd, v, 1.0);
			ans[i] = answer;
			if(ans[i] == 0) ans[i] = -1;
		}
		return ans;
		
	}
	
	public void recur(double[][] am, int cur, int end, List<Integer> visited, double ans) {
		if (visited.contains(cur)) return;
		List<Integer> v = new ArrayList<Integer>();
		for (int i : visited) v.add(i);
		v.add(cur);
		if (cur == end) {
			answer = ans;
			return;
		}
		if (am[cur][end] != 0) {
			recur(am, end, end, visited, ans * am[cur][end]);
			return;
		}
		for (int i = 0; i < am[0].length && answer == 0; i++) {
			if (am[cur][i] != 0) recur(am, i, end, v, ans * am[cur][i]);
		}
		
	}
	
	public static void main (String[] args) throws Exception {
		new Homefun().run();
	}
}
