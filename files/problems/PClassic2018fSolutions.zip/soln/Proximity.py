def proximity(l, m):
    out = []
    if len(l) == 1:
        l.append(l[0])
    for num in m:
        out.extend(sorted(l, key=lambda x: abs(x - num))[:2])
    return out


if __name__ == "__main__":
    with open("ProximityIN.txt", "r") as f:
        while True:
            one, two = f.readline(), f.readline()
            if not two:
                break
            l = [int(x) for x in one.split(" ")]
            m = [int(x) for x in two.split(" ")]
            print((" ".join(str(x) for x in proximity(l, m))) + " ")
