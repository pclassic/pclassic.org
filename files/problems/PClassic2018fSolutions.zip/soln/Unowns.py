#!/usr/bin/env python3

from collections import deque


def challenge(k, lst):
    out = []
    queue = deque()
    maxqueue = deque()
    for i in range(len(lst)):
        while maxqueue and maxqueue[-1][0] <= lst[i]:
            maxqueue.pop()
        while queue and queue[-1][0] >= lst[i]:
            queue.pop()
        queue.append((lst[i], i))
        maxqueue.append((lst[i], i))
        while queue and queue[0][1] <= i - k:
            queue.popleft()
        while maxqueue and maxqueue[0][1] <= i - k:
            maxqueue.popleft()
        if i >= k - 1:
            out.append(maxqueue[0][0] - queue[0][0])
    return out


# DO NOT EDIT BELOW THIS LINE
if __name__ == "__main__":
    with open("UnownsIN.txt", "r") as f:
        for line in f:
            k, n = line.split(" ", 1)
            print(" ".join(str(x) for x in challenge(int(k), [int(x) for x in n.split(" ")])))
