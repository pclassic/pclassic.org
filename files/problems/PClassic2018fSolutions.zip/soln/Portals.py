#!/usr/bin/env python3

import sys
sys.setrecursionlimit(10000)


def portals(r, c, om):
    links = {}
    m = om
    sm = [[100**10 for j in range(len(m[i]))] for i in range(len(m))]
    pm = [[100**10 for j in range(len(m[i]))] for i in range(len(m))]

    start, end = None, None
    for row in range(len(m)):
        for col in range(len(m[row])):
            if m[row][col] == '$':
                start = (row, col)
            elif m[row][col] == '&':
                end = (row, col)
            elif 'A' <= m[row][col] <= 'Z':
                if m[row][col] in links:
                    links[m[row][col]] = ((row, col), links[m[row][col]])
                else:
                    links[m[row][col]] = (row, col)

    queue = []
    queue.append((start[0], start[1], 0, 0))
    while queue:
        r, c, d, p = queue.pop()
        if not (0 <= r < len(m)) or not (0 <= c < len(m[0])) or m[r][c] == '#' or sm[r][c] <= d or (sm[r][c] == d and sm[r][c] <= p):
            continue

        sm[r][c] = d
        pm[r][c] = p
        queue.append((r+1, c, d+1, p))
        queue.append((r-1, c, d+1, p))
        queue.append((r, c+1, d+1, p))
        queue.append((r, c-1, d+1, p))
        if 'A' <= m[r][c] <= 'Z':
            one, two = links[m[r][c]]
            if (r, c) == one:
                queue.append((two[0], two[1], d, p+1))
            else:
                queue.append((one[0], one[1], d, p+1))
    return sm[end[0]][end[1]]


if __name__ == "__main__":
    with open("PortalsIN.txt", "r") as f:
        n = int(f.readline())
        for i in range(n):
            r, c = [int(x) for x in f.readline().split()]
            m = [list(f.readline()) for _ in range(r)]
            print(portals(r, c, m))
