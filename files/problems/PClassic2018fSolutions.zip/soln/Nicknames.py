def iterationHelper(s, n, cSeq):
    longest = ""
    cnt = 1
    loc = 1
    for i in range(1, len(s)):
        if s[0] == s[i]:
            cnt += 1
        else:
            loc = i #location of the end of the subsequence + 1
            break
    if cnt > n:
        n = cnt
        cSeq = s[0]
    if loc != len(s) - 1:
        return iterationHelper(s[loc:], n, cSeq)
    else:
        for c in range(n):
            longest += cSeq
    return longest

def findLongestSubstring(s):
    if len(s) > 1:
        return iterationHelper(s, 0, "")
    else:
        return s

    
#Do not modify below this line
if __name__ == '__main__':
    with open('NicknamesIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            print(findLongestSubstring(s))
