import java.util.*;
import java.io.*;
import java.math.*;

public class PalindromeSS {
	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("PalindromeSSIN.txt"));
		int n = Integer.parseInt(br.readLine());
	    while (n-->0) {
		    String s = br.readLine();
		    System.out.println(solve(s));
	    }
	}
	
	public String solve(String s) {
		for (int len = s.length(); len > 0; len--) {
	    	for (int ind = 0; ind <= s.length()-len; ind++) {
	    		String sb = s.substring(ind,ind+len);
	    		if (sb.charAt(0) != sb.charAt(sb.length()-1)) continue;
	    		if (new StringBuffer(sb).reverse().toString().equals(sb)) return sb;
	    	}
	    }
		return "";
	}
	
	public static void main (String[] args) throws Exception {
		new PalindromeSS().run();
	}
}
