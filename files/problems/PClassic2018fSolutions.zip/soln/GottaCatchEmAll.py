def search(n, rows, A):
    i = 0
    j = len(A[0]) - 1
    while (i < rows and j >= 0):
        if (int(arr[i][j]) == n):
            return (str(i) + ',' + str(j))
        elif (int(arr[i][j]) < n):
            i += 1
        else:
            j -= 1
    return ("Pikachu is lost")

#Do not modify below this line
if __name__ == '__main__':
    with open('GottaCatchEmAllIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            t = f.readline().strip()
            if s == '':
                break
            arr = []
            for i in range(int(t)):
                u = f.readline().strip().split(', ')
                u = [int(i) for i in u]
                arr.append(u)
            print(search(int(s), int(t), arr))
