import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
 
public class Rectangles {
   
	// Before submitting, make sure the main method hasn't been changed!
	// DO NOT MODIFY BELOW THIS LINE
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("RectanglesIN.txt"));
 
		String[] data = br.readLine().split(" ");
		int testCases = Integer.parseInt(data[0]);
		for( ; testCases > 0; testCases--) {
			data = br.readLine().split(" ");
			int[] field = new int[4];
			for(int i=0; i<4; i++) field[i] = Integer.parseInt(data[i]);
			data = br.readLine().split(" ");
			int N = Integer.parseInt(data[0]);
			int M = Integer.parseInt(data[1]);
			int[][] list1 = new int[N][4];
			int[][] list2 = new int[N][4];
			for(int i = 0; i < N; i++){
			    data = br.readLine().split(" ");
			    for(int j = 0; j < 4; j++) {
			    	list1[i][j] = Integer.parseInt(data[j]);
			    }
			}
			for(int i = 0; i < M; i++){
			    data = br.readLine().split(" ");
			    for(int j = 0; j < 4; j++) {
			  		list2[i][j] = Integer.parseInt(data[j]);
			    }
			}
		    System.out.println( solve(field, list1, list2) );
		}
		br.close();
	}	
	
	// DO NOT MODIFY ABOVE THIS LINE
 
    // Fill out the body of this method
  	public static long solve(int[] field,  int[][] l1, int[][] l2) {
  		int n = l1.length;
  		int m = l2.length;
  		long answer = (field[2] - field[0]) * (field[3] - field[1]);
  		for(int i = 0; i < n; i++) {
  			l1[i][0] = Math.max(l1[i][0], field[0]);
  			l1[i][1] = Math.max(l1[i][1], field[1]);
  			l1[i][2] = Math.min(l1[i][2], field[2]);
  			l1[i][3] = Math.min(l1[i][3], field[3]);
  		}
  		for(int i = 0; i < m; i++) {
  			l2[i][0] = Math.max(l2[i][0], field[0]);
  			l2[i][1] = Math.max(l2[i][1], field[1]);
  			l2[i][2] = Math.min(l2[i][2], field[2]);
  			l2[i][3] = Math.min(l2[i][3], field[3]);
  		}
  	  	for(int i = 0; i < n; i++) {
  			answer -= ( l1[i][2] - l1[i][0] )*( l1[i][3] -l1[i][1] );
  		}
  		for(int j = 0; j < m; j++) {
  			answer -= ( l2[j][2] - l2[j][0] )*( l2[j][3] -l2[j][1] );
  		}
  		int x1,y1,x2,y2;
  		for(int i = 0; i < n; i++) {
  			for(int j = 0; j < m; j++) {
  				x1 = Math.max( l1[i][0] , l2[j][0] );
  				y1 = Math.max( l1[i][1] , l2[j][1] );
  				x2 = Math.min( l1[i][2] , l2[j][2] );
  				y2 = Math.min( l1[i][3] , l2[j][3] );
  				if( x1 < x2 && y1 < y2) {
  					answer += (x2 - x1)*(y2 - y1);
  				}
  			}
  		}
	  	return answer;
  	}
}