import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class AliensAmongUs {
	
	public static String findAlien (String[][] data) {
		
		HashMap<String, Integer>[] freqs = new HashMap[data[0].length-1];
		
		for (int i = 0; i < freqs.length; i++) {
			freqs[i] = new HashMap<String, Integer>();
			for (int j = 0; j < data.length; j++) {
				Integer t = freqs[i].get(data[j][i+1]);
				if (t == null)
					freqs[i].put(data[j][i+1], 0);
				else
					freqs[i].put(data[j][i+1], t+1);
			}
		}
		
		String[] modes = new String[data[0].length-1];
		for (int i = 0; i < modes.length; i++) {
			modes[i] = getMode(freqs[i]);
		}
		
		int[] deviations = new int[data.length];
		int max = 0;
		
		for (int i = 0 ; i < deviations.length; i++) {
			for (int j = 1; j < data[i].length; j++) {
				if (!modes[j-1].equals(data[i][j]))
					deviations[i]++;
			}
			if (deviations[max] <  deviations[i]) {
				max = i;
			}
		}
		return data[max][0];
	}
	public static String getMode(HashMap<String, Integer> hm) {
		Set<String> s = hm.keySet();
		String mode = "";
		int modeCount = 0;
		for (String key: s) {
			int m = hm.get(key);
			if (m > modeCount) {
				modeCount = m;
				mode = key;
			}
		}
		return mode;
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("AliensAmongUs.txt"));
		
		while(br.ready()){
			int people = Integer.parseInt(br.readLine());
			String[][] data = new String[people][];
			for (int i = 0; i < people; i++) {
				data[i] = br.readLine().split(",\\s*");
			}
			System.out.println(findAlien(data));
		}
		br.close();
	}
}
