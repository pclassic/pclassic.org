import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FindTheGeneral {
	
	public static class Asteroid {
		int id;
		boolean isAlien;
		List<Integer> adjacentAsteroids;
		
		public Asteroid (int id, boolean isAlien, List<Integer> adjacent){
			this.id = id;
			this.isAlien = isAlien;
			this.adjacentAsteroids = adjacent;
		}
	}
	
	public static int fastestRouteToGeneral (Asteroid source, Asteroid target, List<Asteroid> graph){
		final class AsteroidTuple{
			Asteroid ast;
			int depth;
			
			AsteroidTuple(Asteroid ast, int depth){
				this.ast = ast;
				this.depth = depth;
			}
		}
		
		Queue<AsteroidTuple> q = new ArrayDeque<AsteroidTuple>();
				
		AsteroidTuple current = new AsteroidTuple(source, 0);
		
		q.add(current);
		
		while(!q.isEmpty()){
			current = q.poll();
			

			if(current.ast.id == target.id){
				return current.depth;
			}
			
			for(Integer i : current.ast.adjacentAsteroids){
				if(!getAsteroid(i, graph).isAlien){
					q.add(new AsteroidTuple(getAsteroid(i, graph), current.depth + 1));
				}
			}
		}
		
		return -1;
	}
	
	private static Asteroid getAsteroid(Integer i, List<Asteroid> graph){
		for(Asteroid ast : graph){
			if(i == ast.id){
				return ast;
			}
		}
		
		return null;
	}
	
	
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader (new FileReader ("FindTheGeneral.txt"));
		while (br.ready()) {
			List<Asteroid> graph = new ArrayList<Asteroid>();
			String line = br.readLine();
			line = line.trim();
			String[] sourceTarget = line.split(",");
			int source = Integer.parseInt(sourceTarget[0]);
			int target = Integer.parseInt(sourceTarget[1]);
			Asteroid sourceNode = null;
			Asteroid targetNode = null;
			line = br.readLine();
			while (line.length() != 1 && (! line.equals("="))) {
				String[] inputArray = line.split(",");
				int id = Integer.parseInt(inputArray[0]);
				boolean isAlien = Boolean.parseBoolean(inputArray[1]);
				List<Integer> adjacent = new ArrayList<Integer> ();
				for (int i = 2; i < inputArray.length; i++) {
					adjacent.add(new Integer(inputArray[i]));
				}
				Asteroid current = new Asteroid (id, isAlien, adjacent);
				graph.add(current);
				if (id == source) {
					sourceNode = current;
				}
				else if (id == target) {
					targetNode = current;
				}
				line = br.readLine();
			}
			System.out.println (fastestRouteToGeneral  (sourceNode, targetNode, graph));
		}
		br.close();
	}

}
