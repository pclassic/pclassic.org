import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class TallestTower {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NumberFormatException 
	 */
	public static void main(String[] args) 
			throws NumberFormatException, IOException {
		BufferedReader reader = new BufferedReader(
				new FileReader("TallestTower.txt"));
		
		while(reader.ready()){
			String x = reader.readLine();
			String y = reader.readLine();
			
			System.out.println(getTallestTower(Integer.parseInt(x),
					Integer.parseInt(y)));
		}
		
		reader.close();

	}
	
	/*
	 * There is a number-theory theorem that any linear combination
	 * of two numbers is a multiple of their greatest common divisor
	 * (this is a consequence of something called Bezout's Identity). 
	 * Therefore, if the GCD != 1, we return -1. Otherwise, Bezout's
	 * Identity tells us that the positive solutions to their
	 * Diophantine (integer) equation is (x - 1) * (y - 1); we
	 * subtract one at the end for the problem
	 */
	public static int getTallestTower(int x, int y){
		//Check a couple of edge cases
		if(x == 1 || y == 1){
				return 0;
			}
		if(x < 1 || y < 1 || x == y){
			return -1;
		}

		//Now to the real logic
		if(gcd(x, y) == 1){
			return (x - 1) * (y - 1) - 1;
		}
		else{
			return -1;
		}
	}
	
	private static int gcd(int x, int y){
		int r = x % y;
		while(r != 0){
			x = y;
			y = r;
			r = x % y;
		}
		return y;
	}

}
