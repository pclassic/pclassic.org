import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
 The aliens trying to invade Earth are really superstitious and consider it really bad luck
 to invade coordinates that are both palindromes and primes. So, naturally, Earth's commanders
 think it a good idea to set up headquarters in one such coordinate.
 
 Your mission, should you choose to accept it, is to write a Java method that takes an int
 as an input and return a boolean value indicating whether the int is a palindromic prime or not.
 
 FYI, the largest palindromic prime known is 10314727 - (8 × 10 ^ 157363) - 1, and if the memory and 
 runtime limitation of your program does not exist (in an ideal world), your code should work on this.
 You may write any helper functions you feel are necessary for this problem.
 
 Sample Input

	1. 131
	2. 1
	3. 121
	4. 1234

 Sample Output

	1. true
	2. true
	3. false
	4. false	
*/
public class PalindromicPrime {
	
	public static boolean isPalindrome (String input) {
		char[] inputArray = input.toCharArray();
		
		for (int i = 0; i < (inputArray.length / 2); i++) {
			if (inputArray[i] != inputArray[inputArray.length - 1 - i]) {
				return false;
			}
		}
		
		return true;
	}
	
	public static boolean isPrime (int input) {
		if (input != 2 && (input % 2 == 0)) {
			return false;
		}
		int sqrtInput = (int) Math.sqrt(input);
		for (int i = 2; i <= sqrtInput; i++) {
			if (input % i == 0) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean isPalindromePrime (int input) {
		if (isPalindrome ("" + input)) {
			if (isPrime (input)) {
				return true;
			}
		}
		return false;
	}
	
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader (new FileReader ("PalindromePrime.txt"));
		while (br.ready()) {
			String line = br.readLine();
			line = line.trim();
			System.out.println (isPalindromePrime (Integer.parseInt(line)));
		}
		br.close();
	}

}
