package PlanetaryProjectiles;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class PlanetaryProjectiles {
	
	public static String collide(double[] args) {
		int numPlanets = (int)args[0];
		Planet[] planets = new Planet[numPlanets];
		for (int i = 1; i < args.length-4; i += 3)
			planets[(i-1)/3] = new Planet((int)args[i], (int)args[i+1], args[i+2]);
		
		int ship_x = (int)args[args.length - 4], ship_y = (int)args[args.length - 3];
		
		int vx = (int)args[args.length - 2], vy = (int)args[args.length - 1];
		
		double minD = -1;
		int minI = -1;
		for (int i = 0 ; i < planets.length; i++) {
			double t = planets[i].collideMe(ship_x, ship_y, vx, vy);
			if ((t >= 0 && t < minD) || minD == -1) {
				minD = t;
				minI = i;
			}
		}
		if (minD == -1)
			return "MISS";
		if (minI == 0)
			return "HIT EARTH";
		
		return "HIT PLANET";
	}
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("PlanetaryProjectiles.txt"));
		while(br.ready()){
			String[] line = br.readLine().split("\\s");
			double[] doubleData = new double[line.length];
			for (int i = 0; i < line.length; i++)
				doubleData[i] = Double.parseDouble(line[i]);
			System.out.println(collide(doubleData));
		}
		br.close();
	}
	private static class Planet {
		public int x, y;
		public double r;
		
		public Planet(int x, int y, double r) {
			this.x = x;
			this.y = y;
			this.r = r;
		}
		
		public double collideMe(int x, int y, int vx, int vy) {
			double v1_x = this.x-x;
			   
		    double v1_y = this.y-y;
		    double v2_x = -vy;
		    double v2_y = vx;
		    double dp = v1_x*v2_x+v1_y*v2_y;
		    double t = (v2_x*v2_x+v2_y*v2_y);
		    double dp2 = v1_x*vx+v1_y*vy;
		    
		    double d = (double)Math.abs(dp/Math.sqrt(v2_x*v2_x + v2_y*v2_y));
		    
		    if (d*d < this.r*this.r && dp2 >= 0) {
		      //System.out.println(dp2);
		      double d2 = (double)Math.sqrt(this.r*this.r - d*d);
		      double dp3 = vx*v1_x+vy*v1_y;
		      double d3 = (float)Math.abs(dp3/Math.sqrt(vx*vx+vy*vy));
		      return d3 - d2;
		    }
		    else return -1;
		}
		
	}
}
