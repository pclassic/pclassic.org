package bracketParsing;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AlienDNA {
	private static final String PATH = "/Users/Nate/Google Drive/Workspace/PClassic/src/bracketParsing";
	
	public static String validBrackets(String brackets) {
		int bcount = 0;
		for(int i = 0; i < brackets.length(); i++) {
			char at = brackets.charAt(i);
			if (at == '[')
				bcount++;
			else if (at == ']')
				bcount--;
			
			if (bcount < 0)
				return "INVALID";
		}
		if (bcount > 0)
			return "INVALID";
		
		return "VALID";
	}
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("AlienDNA.txt"));
		while(br.ready()){
			String line = br.readLine();
			
			System.out.println(validBrackets(line));
		}
		br.close();

	}

}
