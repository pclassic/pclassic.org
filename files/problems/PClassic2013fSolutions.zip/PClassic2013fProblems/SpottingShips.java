package SpottingShips;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class SpottingShips {
  public static int numSpots (int N, int M, char[][] grid) {
    
    


    // label both spots
    boolean firstSpot = true;
    for (int r=0; r<N; r++) {
      for (int c = 0; c<M; c++) {
        if (grid[r][c] == 'X') {
          if (firstSpot) {
            label (grid, r, c, '1');
            firstSpot = false;
          }
          else
            label (grid, r, c, '2');
        }
      }
    }

    //calculate the minimum distance between any 2 points in different spots
    int min = Integer.MAX_VALUE;
    for (int r1 = 0; r1 < N; r1 ++) 
      for (int c1 = 0; c1 < M; c1 ++)
        if (grid[r1][c1] == '1')
          for (int r2 = 0; r2 < N; r2 ++)
            for (int c2 = 0; c2 < M; c2 ++)
              if (grid[r2][c2] == '2')
                if (Math.abs(r1-r2) + Math.abs(c1-c2) < min)
                  min = Math.abs(r1-r2) + Math.abs(c1-c2);

    //solution is 1 less than the distance
    return min - 1;
  }
  private static void label (char[][] grid, int r, int c, char n) {
    if (grid[r][c] != 'X') 
      return;
    grid[r][c] = n;
    if (r>0)
      label(grid, r-1, c, n);
    if (c>0)
      label(grid, r, c-1, n);
    if (r < grid.length - 1)
      label (grid, r+1, c, n);
    if (c < grid[0].length - 1)
      label (grid, r, c+1, n);
  }
  
  
  public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("SpottingShips.txt"));
		
		while(br.ready()){
			int lines = Integer.parseInt(br.readLine());
			char[][] paint = new char[lines][];
			for (int i = 0; i < lines; i++) {
				String line = br.readLine();
				paint[i] = new char[line.length()];
				for (int j = 0; j < line.length(); j++) {
					paint[i][j] = line.charAt(j);
				}
			}
			System.out.println(numSpots(lines, paint[0].length, paint));
		}
		br.close();
	}
}