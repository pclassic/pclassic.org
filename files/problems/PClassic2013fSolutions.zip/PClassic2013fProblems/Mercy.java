import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.HashSet;

public class Mercy {

	/**
	 * @param args
	 */
	public static void main(String[] args) 
			throws NumberFormatException, IOException {
		BufferedReader reader = new BufferedReader(
				new FileReader("mercy.txt"));
		
		while(reader.ready()){
			String x = reader.readLine();
			
			System.out.println(mercy(Long.parseLong(x)));
		}
		
		reader.close();
		
	}

		
	public static int mercy(long n){
		Set<Integer> primesUnderSqrt = primesUnderSqrt(n);
		return max(primesUnderSqrt, n) - min(primesUnderSqrt) + 1;
	}
	
	
	private static int max(Set<Integer> primes, long n){
		return sum(logarithms(primes, n));
	}
	
	
	private static int min(Set<Integer> primes){
		return primes.size();
	}
	
	
	private static Set<Integer> primesUnderSqrt(long num){
		//Want 0 - sqrt[n]
		boolean[] sieve = new boolean[(int)Math.sqrt(num) + 1];

		//Assume everything is a prime
		for(int i = 0; i < sieve.length; i++){
			sieve[i] = true;
		}
		
		//Start at 2, not 0 or 1
		int n = 2;
		
		
		while(n < Math.sqrt(sieve.length - 1)){
			for(int i = n + n; i < sieve.length; i += n){
				sieve[i] = false;
			}
			
			n++;
			
			while(!sieve[n]){
				n++;
			}
			
		}
		
		Set<Integer> primes = new HashSet<Integer>();
		
		for(int i = 0; i < sieve.length; i++){
			if(sieve[i] && i > 1){
				primes.add(i);
			}
		}
		
		return primes;
	}
	
	
	
	private static List<Integer> logarithms(Set<Integer> bases, long number){
		List<Integer> logarithms = new LinkedList<Integer>();

		for(int base : bases){
			int logarithm = (int) (Math.log(number) / Math.log(base));
			logarithms.add(logarithm);
		}

		return logarithms;
	}
	
	
	private static int sum(List<Integer> list){
		int sum = 0;
		
		for(Integer num : list){
			sum += num;
		}
		
		return sum;
	}

}
