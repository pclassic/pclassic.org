package Wages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class SoldiersWages {
	private static final String PATH = "/Users/Nate/Google Drive/Workspace/PClassic/src/Wages";

	public static int calculateWage(int[] hours) {
		int wage = 0;
		int totalHours = 0;
		
		for (int i = 1; i < 6; i++) {
			totalHours += hours[i];
			if (hours[i] > 8) {
				wage += 80 + 12*(hours[i] - 8);
			} else {
				wage += 10*hours[i];
			}
		}
		
		wage += hours[0]*15;
		totalHours += hours[0];
		
		wage += hours[6]*13;
		totalHours += hours[6];
		
		if (totalHours > 40)
			wage += totalHours-40;
		
		
		return wage;
	}
	
	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("SoldiersWages.txt"));
		while(br.ready()){
			String[] line = br.readLine().split("\\s");
			int[] hours = new int[line.length];
			for (int i = 0; i < hours.length; i++) {
				hours[i] = Integer.parseInt(line[i]);
			}
			System.out.println(calculateWage(hours));
		}
		br.close();
	}
	

}
