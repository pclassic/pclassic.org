import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/*
* One of your brilliant scientists have a theory that the alien
* language does not contain any two similar adjacent characters.
* This means that the alien language cannot have any character
* of the alphabet next to each other (like aaron because of the a's).
* 
* Your mission is to help this mad, yet brilliant scientist test his 
* theory by writing a Java function that takes in an input String indexed 
* 1, 2,...., n where n is the size of the input string. It then
* returns a String in which each character is immediately repeated by the
* the character's index number. Therefore something a word as simple as
* abc becomes abbccc, which can then be used to confuse the aliens.
* 
* Sample Input
* 
* 1. abc
* 2. abc1
* 3. Eagles!
* 
* Sample Output
* 
* 1. abbccc
* 2. abbccc1111
* 3. Eaaggglllleeeee!!!!!!
*/

public class WeirdRepeat {
	
	public static String weirdRepeat (String input) {
		String toReturn = "";
		for (int i = 0; i < input.length(); i++) {
			for (int j = 1; j <= i + 1; j++) {
				toReturn += input.charAt(i);
			}
		}
		return toReturn; 
	}
	
	
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader (new FileReader ("WeirdRepeat.txt"));
		while (br.ready()) {
			String line = br.readLine();
			line = line.trim();
			System.out.println (weirdRepeat (line));
		}
		br.close();
	}

}
