import java.util.Arrays;
import java.io.BufferedReader;
import java.util.Comparator;
import java.io.FileReader;
import java.io.IOException;

public class KingSort {
	public static void main (String[] args) throws IOException {
		BufferedReader br = new BufferedReader (new FileReader ("KingSort.txt"));

		while (br.ready ()) {
			System.out.println (kingSort (br.readLine ()));
		}
		br.close ();
	}

	public static String kingSort (String kingString) {
		String[] kings = kingString.split(","); // unsorted kings
		String output = "";

		Arrays.sort (kings, new Comparator<String> () {
			public int compare (String kingStr1, String kingStr2) {
				String[] king1 = kingStr1.split(" ");
				String name1 = king1[0]; // king's name, i.e. Gilgamesh
				String number1 = king1[1]; // king's number, i.e. Y

				String[] king2 = kingStr2.split(" ");
				String name2 = king2[0];
				String number2 = king2[1];

				if (!name1.equals (name2)) return name1.compareTo (name2);
				else if (convert (number1) < convert (number2)) return -1;
				else if (convert (number1) == convert (number2)) return 0;
				else return 1;
			}
		});

		for (int i = 0; i < kings.length; i++) {
			output += kings[i];
			if (i != kings.length - 1) output += ",";
		}
		return output;
	}

	private static int convert (String number) {
		int value = 0;
		int maxDigit = Integer.MIN_VALUE;
		char[] digitChars = number.toCharArray ();
		int[] digits = new int[digitChars.length];

		for (int i = 0; i < digits.length; i++) {
			char digitChar = digitChars[i];
			if (digitChar == 'X') digits[i] = 10;
			else if (digitChar == 'Y') digits[i] = 5;
			else if (digitChar == 'Z') digits[i] = 1;
		}

		for (int i = digits.length - 1; i >= 0; i--) {
			int digit = digits[i];
			if (digit >= maxDigit) {
				value += digit;
				maxDigit = digit;
			} else {
				value -= digit;
			}
		}

		return value;
	}
}