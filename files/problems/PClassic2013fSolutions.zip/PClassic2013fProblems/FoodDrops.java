import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FoodDrops {
	public static String getTimes(String[] flights, int[] times) {
		for (int i = 0; i < times.length; i++) {
			for (int j = 0; j < flights.length - 1; j++) {
				int t1;
				String t2;
				
				if (times[j] > times[j+1]) {
					t1 = times[j+1];
					times[j+1] = times[j];
					times[j] = t1;
					
					t2 = flights[j+1];
					flights[j+1] = flights[j];
					flights[j] = t2;
				}
			}
		}
		String out = "[";
		for (int i = 0; i < flights.length - 1; i++)
			out += flights[i] + ", ";
		out += flights[flights.length - 1] + "]";
			
		return out;
	}

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader("FoodDrops.txt"));
		while(br.ready()){
			String[] line1 = br.readLine().split("\\s");
			String[] line2 = br.readLine().split("\\s");
			int[] int_line2 = new int[line2.length];
			for (int i = 0; i < line2.length; i++)
				int_line2[i] = Integer.parseInt(line2[i]);
			System.out.println(getTimes(line1, int_line2));
		}
		br.close();

	}
}