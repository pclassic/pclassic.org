import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


	public class Question7Test {

		@Before
		public void setUp() throws Exception {
		}
		
		
		@Test(timeout=5000)
		public void testQuestion7(){
			int s1 = 0;
			int s2 = 872;
			int s3 = 2000000000;
			int s4 = (int) (Math.pow(10, 5) * 2);
			int s5 = 1155;
			
			
			String g1 = Question7.calcMonth(s1);
			String g2 = Question7.calcMonth(s2);
			String g3 = Question7.calcMonth(s3);
			String g4 = Question7.calcMonth(s4);
			String g5 = Question7.calcMonth(s5);
			
			String e1 = "February";
			String e2 = "July";
			String e3 = "February";
			String e4 = "September";
			String e5 = "April";
			
			assertEquals(g1, e1);
			assertEquals(g2, e2);
			assertEquals(g3, e3);
			assertEquals(g4, e4);
			assertEquals(g5, e5);

			
		}
		}