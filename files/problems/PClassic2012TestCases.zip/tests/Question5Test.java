
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class Question5Test {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testQuestion1(){

		

		assertTrue(Question5.validateCard("4012888888881881"));
		assertFalse(Question5.validateCard("4012888888881882"));
		assertFalse(Question5.validateCard("3435375372"));
		assertFalse(Question5.validateCard("34353753732"));
		assertTrue(Question5.validateCard("9331275835"));
		assertFalse(Question5.validateCard("123423146"));
		assertFalse(Question5.validateCard("531249984"));
		assertFalse(Question5.validateCard("73439"));
		assertTrue(Question5.validateCard("734392"));
	}

}
