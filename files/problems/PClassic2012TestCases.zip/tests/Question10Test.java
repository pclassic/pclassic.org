import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


	public class Question10Test {

		@Before
		public void setUp() throws Exception {
		}
		
		
		@Test
		public void testQuestion10(){
			assertEquals(Question10.parseExpression("(3+2)*5"), 25);
			assertEquals(Question10.parseExpression("12"), 12);
			assertEquals(Question10.parseExpression("1+((4+7)*3)"), 34);
			assertEquals(Question10.parseExpression("(11)"), 11);
			assertEquals(Question10.parseExpression("((5+2)*(2+1))+(9*1)"), 30);
			assertEquals(Question10.parseExpression("(5)"), 5);
			assertEquals(Question10.parseExpression("(((2)+1)*3)+4"), 13);
			assertEquals(Question10.parseExpression("((5+5))"), 10);


			
		}
	}