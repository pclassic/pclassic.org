
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;

public class Question2Test {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void testQuestion1(){

		
		int[] o1 = Question2.fuzzNumbers(150, 120);
		int[] o2 = Question2.fuzzNumbers(2000, 1000);
		int[] o4 = Question2.fuzzNumbers(2200, 2000);
		int[] o5 = Question2.fuzzNumbers(400, 380);
		int[] o8 = Question2.fuzzNumbers(17000, 16534);
		int[] o9 = Question2.fuzzNumbers(4000, 417);
		
		int[] e1 = {127, 127};
		int[] e2 = {1973, 1013};
		int[] e4 = {2161, 2017};
		int[] e5 = {383, 383};
		int[] e8 = {16979, 16547};
		int[] e9 = {3967, 439};

		
		myEquals(o1, e1, 150, 120);
		myEquals(o2, e2, 2000, 1000);
//		assertTrue(Arrays.equals(o3, e3));
		myEquals(o4, e4, 2200, 2000);
		myEquals(o5, e5, 400, 380);
//		assertTrue(Arrays.equals(o6, e6));
//		assertTrue(Arrays.equals(o7, e7));
		myEquals(o8, e8, 17000, 16534);
		myEquals(o9, e9, 4000, 417);
	}
	
	public void myEquals(int[] ar1, int[] ar2, int a1, int a2){
		int mydiff = Math.abs(ar1[1] - a2) + Math.abs(ar1[0] - a1);
		int theirdiff = Math.abs(ar2[1] - a2) + Math.abs(ar2[0] - a1);
		assertEquals(mydiff, theirdiff);
		assertTrue(isPrime(ar1[0]));
		assertTrue(isPrime(ar1[1]));
		assertTrue(isPrime((ar1[0] + ar1[1])/2));
	}
	
	 public static boolean isPrime(int num)
	 {
	   for(int i = 2; i <= Math.sqrt(num); i++)
	     if(num%i==0)
	     return false;
	   return true;
	 }	

}
