import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashSet;

import org.junit.Test;


	

	public class Question8Test {

		
		@Test
		public void testQuestion8(){
			String[] input1 = { "dog", "cat", "god", "act", "fish", "tac"}; //General 1
			String[] input2 = { "wool", "loww", "rabble", "barrle"}; // No answer
			String[] input3 = { "dogl", "gdol", "p", "q", "p"}; //General 2
			String[] input4 = {}; //Empty
			String[] input5 = { "javalq", "langua", "vaajql", "ngaalu", "random"}; //General 3
			String[] input6 = {"abcde", "bacde", "cabde", "dbace", "cadbe", "aebcd"}; //All anagrams of each other


		
			
			String[][] g1 = Question8.groupAnagrams(input1);
			String[][] g2 = Question8.groupAnagrams(input2);
			String[][] g3 = Question8.groupAnagrams(input3);
			String[][] g4 = Question8.groupAnagrams(input4);
			String[][] g5 = Question8.groupAnagrams(input5);
			String[][] g6 = Question8.groupAnagrams(input6);

			
			String[][] e1 = {{"dog", "god"}, {"cat", "act", "tac"}, {"fish"}};
			String[][] e2 =  {{"wool"}, {"loww"}, {"rabble"}, {"barrle"}};
			String[][] e3 = {{"dogl", "gdol"}, {"p", "p"}, {"q"}};
			String[][] e4 = {};
			String[][] e5 = {{"javalq", "vaajql"}, {"langua", "ngaalu"}, {"random"}};
			String[][] e6 = {{"abcde", "bacde", "cabde", "dbace", "cadbe", "aebcd"}};

			
			


			equalEnough(g1, e1);
			equalEnough(e1, g1);		
			equalEnough(g2, e2);	
			equalEnough(e2, g2);
			equalEnough(g3, e3);	
			equalEnough(e3, g3);		
			equalEnough(g4, e4);		
			equalEnough(e4, g4);		
			equalEnough(g5, e5);		
			equalEnough(e5, g5);		
			equalEnough(g6, e6);		
			equalEnough(g6, e6);		
		}
		
		public void equalEnough(String[][] ar1, String[][] ar2){
			for(String[] s: ar1){
				assertTrue(containsSubarray(ar2, s));
			}
		}
		
		public boolean containsSubarray(String[][] ar2, String[] s){
			for(String[] s2 : ar2){
				if(equalAsSet(s2, s)){
					return true;
				}
			}
			
			return false;
		}
		
		public boolean equalAsSet(String[] s1, String[] s2){
			HashSet<String> a1 = new HashSet<String>();
			HashSet<String> a2 = new HashSet<String>();
			for(String s : s1){
				a1.add(s);
			}
			for(String s : s2){
				a2.add(s);
			}
			return a1.equals(a2);
		}
		
	}