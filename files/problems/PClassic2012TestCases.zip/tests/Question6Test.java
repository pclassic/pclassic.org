import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import java.util.Arrays;

	

	public class Question6Test {

		
		@Test
		public void testQuestion6(){
			char[][] board1 = {{ ' ', '*', ' ', ' ', '*', '*' },
                               { '*', ' ', ' ', '*', '*', ' ' },
                               { '*', ' ', '*', ' ', ' ', ' ' },
                               { '*', '*', '*', ' ', ' ', ' ' },
                               { ' ', ' ', ' ', ' ', ' ', ' ' },
                               { ' ', '*', '*', '*', ' ', '*' } };; //given example
            
            int[][] moves11 = { {0, 0}, {0, 2}};
            int[][] moves12 = {};
            int[][] moves13 = { {5, 1}, {0, 0}};
            int[][] moves14 = { {3, 5}, {5, 0}};
            int[][] moves15 = { {3, 5}, {5, 0}, {0,0}, {2, 0}};
            int[][] moves16 = { {0, 1} };
            
            char[][] expected11 = {{ '2', '_', '2', '_', '_', '_' },
                                  { '_', '_', '_', '_', '_', '_' },
                                  { '_', '_', '_', '_', '_', '_' },
                                  { '_', '_', '_', '_', '_', '_' },
                                  { '_', '_', '_', '_', '_', '_' },
                                  { '_', '_', '_', '_', '_', '_' } };
            
            char[][] expected12 = {{ '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' } };
            
            char[][] expected13 = {{ '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '*', '_', '_', '_', '_' } };
            
            char[][] expected14 = {{ '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '4', '2', '1' },
                                   { '_', '_', '_', '2', '0', '0' },
                                   { '_', '_', '_', '3', '2', '1' },
                                   { '1', '_', '_', '_', '_', '_' } };
                                   
            char[][] expected15 = {{ '2', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '*', '_', '_', '4', '2', '1' },
                                   { '_', '_', '_', '2', '0', '0' },
                                   { '_', '_', '_', '3', '2', '1' },
                                   { '1', '_', '_', '_', '_', '_' } };
                                   
            char[][] expected16 = {{ '_', '*', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' },
                                   { '_', '_', '_', '_', '_', '_' } };
            
            
            char[][] board2 = {{ '*', '*', ' ', '*' },
                               { '*', ' ', ' ', ' ' },
                               { '*', ' ', ' ', '*' } };
            
            int[][] moves21 = { {1, 1}, {0, 2}};
            int[][] moves22 = { {0, 0}, {0, 2}};
            int[][] moves23 = { {1, 1}, {2, 1}, {2,2}, {1,2}, {0,0}, {1,0}};
            
            char[][] expected21 = {{ '_', '_', '2', '_' },
                                   { '_', '4', '_', '_' },
                                   { '_', '_', '_', '_' } };
                                   
            char[][] expected22 = {{ '*', '_', '_', '_' },
                                   { '_', '_', '_', '_' },
                                   { '_', '_', '_', '_' } };
                                   
            char[][] expected23 = {{ '*', '_', '_', '_' },
                                   { '_', '4', '2', '_' },
                                   { '_', '1', '1', '_' } };
            
            char[][] res11 = Question6.playMoves(board1, moves11);
            char[][] res12 = Question6.playMoves(board1, moves12);
            char[][] res13 = Question6.playMoves(board1, moves13);
            char[][] res14 = Question6.playMoves(board1, moves14);
            char[][] res15 = Question6.playMoves(board1, moves15);
            char[][] res16 = Question6.playMoves(board1, moves16);
            char[][] res21 = Question6.playMoves(board2, moves21);
            char[][] res22 = Question6.playMoves(board2, moves22);
            char[][] res23 = Question6.playMoves(board2, moves23);

			assertTrue(Arrays.deepEquals(expected11,res11));
            assertTrue(Arrays.deepEquals(expected12,res12));
            assertTrue(Arrays.deepEquals(expected13,res13));
            assertTrue(Arrays.deepEquals(expected14,res14));
            assertTrue(Arrays.deepEquals(expected15,res15));
            assertTrue(Arrays.deepEquals(expected16,res16));
            assertTrue(Arrays.deepEquals(expected21,res21));
            assertTrue(Arrays.deepEquals(expected22,res22));
            assertTrue(Arrays.deepEquals(expected23,res23));
            
        
		}

	}
