import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.util.Arrays;

	

	public class Question3Test {

		
		@Test(timeout=5000)
		public void testQuestion3(){
			String[] input1 = { "JUICE$", "W$#RDS", "EAGLES", "EAGERS", "W$$RDS"}; //General 1
			String[] input2 = { "AP$L#S", "###$$$", "AP$L##", "####$$"}; // General 2
			String[] input3 = { "W$#RAM"}; //Single
			String[] input4 = { "A####A", "W$#RDS", "A####A"}; // Repeated
			String[] input5 = {}; //Empty
			String[] input6 = { "LANGUA", "JAVACO", "#VOFL#", "VOFLTA", "DEP$#I"};

		
			
			String[] g1 = Question3.wackySort(input1);
			String[] g2 = Question3.wackySort(input2);
			String[] g3 = Question3.wackySort(input3);
			String[] g4 = Question3.wackySort(input4);
			String[] g5 = Question3.wackySort(input5);
			String[] g6 = Question3.wackySort(input6);
			
			
			String[] e1 = {"JUICE$", "EAGLES", "EAGERS", "W$#RDS", "W$$RDS"};
			String[] e2 = {"AP$L#S", "AP$L##", "####$$", "###$$$"};
			String[] e3 = {"W$#RAM"};
			String[] e4 = {"A####A", "A####A",  "W$#RDS"};
			String[] e5 = {};
			String[] e6 = {"VOFLTA", "LANGUA", "JAVACO", "DEP$#I", "#VOFL#"};

			
			

			assertTrue(Arrays.equals(g1, e1));
			assertTrue(Arrays.equals(g2, e2));
			assertTrue(Arrays.equals(g3, e3));
			assertTrue(Arrays.equals(g4, e4));
			assertTrue(Arrays.equals(g5, e5));
			assertTrue(Arrays.equals(g6, e6));
		}

	}

