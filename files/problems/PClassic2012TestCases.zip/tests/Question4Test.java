
	import static org.junit.Assert.*;

	import org.junit.Before;
	import org.junit.Test;


	public class Question4Test {

		@Before
		public void setUp() throws Exception {
		}
		
		@Test
		public void testQuestion4(){
			double[] s1 = {101.01, 99.9, 46.10, 53.90}; //Case when greedy doesnt work
			double[] s2 = {}; //Empty array
			double[] s3 = {101.00}; //No possible
			double[] s4 = {99.00, 0.50}; //Simple case
			double[] s5 = { 4.77, 81.42, 18.53}; //General
			double[] s6 = {0.70}; //Case of one no

			
			double g1 = Question4.maxSpending(s1);
			double g2 = Question4.maxSpending(s2);
			double g3 = Question4.maxSpending(s3);
			double g4 = Question4.maxSpending(s4);
			double g5 = Question4.maxSpending(s5);
			double g6 = Question4.maxSpending(s6);
			
			
			double e1 = 100.0;
			double e2 = 0.0;
			double e3 = 0.0;
			double e4 = 100.0;
			double e5 = 99.95;
			double e6 = 99.4;
			
			assertEquals(g1, e1, 0.0);		
			assertEquals(g2, e2, 0.0);
			assertEquals(g3, e3, .0);		
			assertEquals(g4, e4, .0);		
			assertEquals(g5, e5, .0);		
			assertEquals(g6, e6, .0);		
		}

	}

