
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import java.util.Arrays;


public class Question9Test {

	@Before
	public void setUp() throws Exception {
	}
	
	public boolean assertArrayEquals(String[] a, String[] b) {
		return Arrays.equals(a,b);
	}
	
	@Test
	public void testQuestion1(){

		String[] words1 = {"AXE","TOOTH","BANANA","PEEPS","APPLE"};
		String[] words2 = {"BOOKKEEPER","FEET"};
		String[] words3 = {"MEAT","MEET","METE","MEME","MOTE","DADA"};

		assertArrayEquals(Question9.findMatchingWords(words1, "XJJXI"), new String[] {"TOOTH","PEEPS"});
		assertArrayEquals(Question9.findMatchingWords(words1, "M"), new String[] {});
		assertArrayEquals(Question9.findMatchingWords(words1, "XJJYI"), new String[] {"APPLE"});
		
		assertArrayEquals(Question9.findMatchingWords(words2, "FEET"), new String[] {"FEET"});
		assertArrayEquals(Question9.findMatchingWords(words2, "ZXXP"), new String[] {"FEET"});
		assertArrayEquals(Question9.findMatchingWords(words2, "ZXXX"), new String[] {});
		assertArrayEquals(Question9.findMatchingWords(words2, "ABCD"), new String[] {});
		assertArrayEquals(Question9.findMatchingWords(words2, "ACCBBDDEDF"), new String[] {"BOOKKEEPER"});
		assertArrayEquals(Question9.findMatchingWords(words2, "ABBCCDDEFG"), new String[] {});
		
		assertArrayEquals(Question9.findMatchingWords(words3, "XKCD"),new String[] {"MEAT","MOTE"});
		assertArrayEquals(Question9.findMatchingWords(words3, "NOOB"),new String[] {"MEET"});
		assertArrayEquals(Question9.findMatchingWords(words3, "GAGA"),new String[] {"MEME","DADA"});
		assertArrayEquals(Question9.findMatchingWords(words3, "ABBA"),new String[] {});
		assertArrayEquals(Question9.findMatchingWords(words3, "WEEE"),new String[] {});
		assertArrayEquals(Question9.findMatchingWords(words3, "ZZZZ"),new String[] {});


	}

}
