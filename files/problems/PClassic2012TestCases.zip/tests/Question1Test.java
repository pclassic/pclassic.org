
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class Question1Test {

	@Before
	public void setUp() throws Exception {
	}
	
	@Test(timeout=3000)
	public void testQuestion1(){
		String s1 = "A A A B+ D- C+ A B";
		String s2 = "C";
		String s3 = "F F F F F F F F";
		String s4 = "C A+ B D F";
		String s5 = "A A- D- B+ A+ D+";
		String s6 = "C C- B- C A A";
		
		double g1 = Question1.calculateGPA(s1);
		double g2 = Question1.calculateGPA(s2);
		double g3 = Question1.calculateGPA(s3);
		double g4 = Question1.calculateGPA(s4);
		double g5 = Question1.calculateGPA(s5);
		double g6 = Question1.calculateGPA(s6);
		
		
		double e1 = 3.1625;
		double e2 = 2.00;
		double e3 = 0.0;
		double e4 = 2.0;
		double e5 = 2.8333;
		double e6 = 2.7333;
		
		assertEquals(g1, e1, .001);		
		assertEquals(g2, e2, 0.0);
		assertEquals(g3, e3, .001);		
		assertEquals(g4, e4, .001);		
		assertEquals(g5, e5, .001);		
		assertEquals(g6, e6, .001);		
	}

}
