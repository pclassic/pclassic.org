import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

public class Cookies {
	// Before submitting, make sure the main method hasn't been changed!
    // DO NOT MODIFY BELOW THIS LINE
    
    public static void main(String[] args) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("CookiesIN.txt"));
        String[] data = br.readLine().split(" ");
        int testCases = Integer.parseInt(data[0]);
        for( ; testCases > 0; testCases--) {
        	System.out.println( solve( br.readLine() ) );
        }
        br.close();
    }   
    
    // DO NOT MODIFY ABOVE THIS LINE

    
    // Fill out the body of this method
    public static int solve(String str) {				// Btw, the python solution is clearer, check it out
        int cur = 0;
        int n = str.length();
    	Stack<Integer> stack = new Stack<Integer>();
        for(int i = 0; i < n; i++) {
        	char c = str.charAt(i);
        	if( '0' <= c &&  c <= '9') {
        		cur *= 10;
        		cur += c - '0';
        	}
        	else{
				if(cur > 0) stack.push(cur);
				tryAddition(stack);
        		cur = 0;
        		if( c == 'T')  stack.push( -1 );		// We are using negative values to identify operations and 
        		else if( c == 'F')  stack.push( -2 );	// boolean values in the stack. This is fine since our
	        	else if( c == '+')  stack.push( -3 );	// operations only ever produce positive integers. For a more
	        	else if( c == '>')  stack.push( -4 );	// general and overall better approach it would be ideal to
	        	else if( c == '<')  stack.push( -5 );	// create a StackElement class that can be either a number, an
	        	else if( c == '=')  stack.push( -6 );	// operation or a boolean.
	        	else if( c == '?') {
	        		tryAddition(stack);
					booleanEvaluation(stack);
	        	}
	        	else if( c == ')') {
	        		tryAddition(stack);
					conditionalEvaluation(stack);
					int num = stack.pop();
					stack.pop();
					stack.push(num);
	        	}
	        	else if( c == '(') {
	        		stack.push( -7 ); 
	        	}
        	}
        }
        if(cur != 0) stack.push(cur);
        tryAddition(stack);
        return stack.pop();
    }

    
    public static void tryAddition(Stack<Integer> stack) {
    	if(stack.size() < 3) return;
		int num2 = stack.pop();
		if(num2 < 0) {
			stack.push(num2);
			return;
		}
		int op = stack.pop();
		int num1 = stack.pop();
		while(op == -3) {
			stack.push(num1 + num2);
			if(stack.size() < 3) return;
			num2 = stack.pop();
			op = stack.pop();
			num1 = stack.pop();
		}
		stack.push(num1);
		stack.push(op);
		stack.push(num2);
    }

    public static void booleanEvaluation(Stack<Integer> stack) {
    	if(stack.size() < 3) return;
	    int num2 = stack.pop();
	    if(num2 == -1 || num2 == -2) {
	    	stack.push(num2);
	    	return;
	    }
		int op = stack.pop();
		int num1 = stack.pop();
		if(op == -4) {
			if(num1 > num2) stack.push(-1);
			else stack.push(-2);
		}
		else if(op == -5) {
			if(num1 < num2) stack.push(-1);
			else stack.push(-2);
		}
		else {
			if(num1 == num2) stack.push(-1);
			else stack.push(-2);
		}
    }

    public static void conditionalEvaluation(Stack<Integer> stack) {
		int num2 = stack.pop();
		int num1 = stack.pop();
		int val = stack.pop();
		if(val == -1) stack.push(num1);			// true -> num1
		else stack.push(num2);					// false -> num2
    }
}
