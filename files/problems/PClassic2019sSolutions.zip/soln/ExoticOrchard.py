from ast import literal_eval

def convex_hull(points):
    """Computes the convex hull of a set of 2D points.

    Input: a list of (x, y) pairs representing the points.
    Output: a list of vertices of the convex hull in counter-clockwise order,
      starting from the vertex with the lexicographically smallest coordinates.
    Implements Andrew's monotone chain algorithm. O(n log n) complexity.

    Taken from:
    https://en.wikibooks.org/wiki/Algorithm_Implementation/Geometry/Convex_hull/Monotone_chain#Python
    """

    points = sorted(set(points))

    if len(points) <= 1:
        return points

    def cross(o, a, b):
        return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

    lower = []
    for p in points:
        while len(lower) >= 2 and cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)
    upper = []
    for p in reversed(points):
        while len(upper) >= 2 and cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    return lower[:-1] + upper[:-1]

def in_perimeter(points, new_point):
    hull_0 = convex_hull(points)
    points.append(new_point)
    hull_1 = convex_hull(points)
    return hull_0 == hull_1
 
#Do not modify below this line
if __name__ == '__main__':
    with open('ExoticOrchardIN.txt', 'r') as f:
        T = int(f.readline().strip())
        for t in range(T):
            new_point = literal_eval(f.readline().strip())
            num_points = int(f.readline().strip())
            existing_points = []
            for i in range(num_points):
                existing_points.append(literal_eval(f.readline().strip()))
            print('1' if in_perimeter(existing_points, new_point) else '0')