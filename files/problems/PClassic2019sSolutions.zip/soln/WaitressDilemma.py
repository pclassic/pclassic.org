from collections import deque

def minBridges(n, xs, ys, xd, yd):
  queue = deque()
  queue.append((0, xs, ys))
  visited = set()

  while(not len(queue) == 0):
    top = queue.popleft()
    curX, curY = top[1], top[2]
    if (curX, curY) in visited:
      continue
    
    visited.add((curX, curY))
    if (curX == xd and curY == yd):
      return top[0]

    dx = [-1, -1, -2 ,-2 , 1, 1, 2, 2]
    dy = [-2, 2, -1, 1, -2, 2, -1, 1]

    for i in range(0, 8):
      newX, newY = curX + dx[i], curY + dy[i]
      if (newX > 0 and newX <= n and newY > 0 and newY <= n):
        queue.append((top[0] + 1, newX, newY))

if __name__ == '__main__':
  with open('WaitressDilemmaIN.txt', 'r') as f:
    num_test_cases = int(f.readline().strip())
    for i in range(num_test_cases):
      n = f.readline().strip()
      s = f.readline().strip().split()
      xs, ys = s[0], s[1]
      d = f.readline().strip().split()
      xd, yd = d[0], d[1]
      print(minBridges(int(n), int(xs), int(ys), int(xd), int(yd)))


    




    
    
    

