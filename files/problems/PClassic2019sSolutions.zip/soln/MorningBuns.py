def message_reveal(matrix):
    string = ""
    s = len(matrix)
    for d in range(s // 2):
        top, bottom, left, right = "", "", "", ""
        for i in range(d, s - 1 - d):
            top += matrix[d][i]
            right += matrix[i][s-1-d]
            bottom += matrix[s-1-d][s-1-i]
            left += matrix[s-1-i][d]
        string += top + right + bottom + left
    if s % 2 == 1:
        string += matrix[s//2][s//2]
    return string.strip().replace("*", ' ')

#Do not modify below this line
if __name__ == '__main__':
    with open('MorningBunsIN.txt', 'r') as f:
        num_test_cases = int(f.readline().strip())
        for i in range(num_test_cases):
            side_length = int(f.readline().strip())
            matrix = []
            for j in range(side_length):
                matrix.append(list(f.readline().strip()))
            print(message_reveal(matrix))
