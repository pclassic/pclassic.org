# adds the numbers at top of stack until no more '+' found
def eval_plus(stack):
    if len(stack) < 3 or type(stack[-1]) != int:
        return
    num2 = stack.pop()
    op = stack.pop()
    while op == '+':
        num1 = stack.pop()
        stack.append(num1 + num2)
        if len(stack) < 3:
            return
        num2 = stack.pop()
        op = stack.pop()
    stack.append(op)
    stack.append(num2)

# evaluates '<', '=', '>' if those operations are on top of stack
def eval_compare(stack):
    if len(stack) < 3 or stack[-1] == 'T' or stack[-1] == 'F':
        return
    num2 = stack.pop()
    op = stack.pop()
    num1 = stack.pop()
    if op == '<':
        stack.append('T' if num1 < num2 else 'F')
    elif op == '=':
        stack.append('T' if num1 == num2 else 'F')
    elif op == '>':
        stack.append('T' if num1 > num2 else 'F')
    else:
        print('hmm: ' + op)
        return -1

# evaluates conditional statement; assumes it's on top of stack
def eval_conditional(stack):
    num2 = stack.pop()
    num1 = stack.pop()
    cond = stack.pop()
    stack.pop()         # pop the '('
    if cond == 'T':
        stack.append(num1)
    else:
        stack.append(num2)

def solve(expr):
    curr = 0
    stack = []
    for c in expr:
        if c.isdigit():
            curr *= 10
            curr += int(c)
        else:
            if curr > 0:
                stack.append(curr)
            eval_plus(stack)
            curr = 0
            if c == '?':
                eval_compare(stack)
            elif c == ')':
                eval_conditional(stack)
            elif c != ':':
                stack.append(c)
    if curr != 0:
        stack.append(curr)
    eval_plus(stack)
    return stack.pop()
 
# Do not modify below this line
if __name__ == '__main__':
    with open('CookiesIN.txt', 'r') as f:
        T = int(f.readline().strip())
        for t in range(T):
            print(solve(f.readline().strip()))