def winner(scores):
    matt = sum(scores[::2])
    joey = sum(scores[1::2])
    if matt == joey:
        return "tie"
    elif matt > joey:
        return "matt"
    else:
        return "joey"

#Do not modify below this line
if __name__ == '__main__':
    with open('EatingContestIN.txt', 'r') as f:
        while True:
            input = f.readline().strip() # read input
            if input == '':
                break
            scores = [int(x) for x in input.split(' ')] # parse to int
            print(winner(scores))
