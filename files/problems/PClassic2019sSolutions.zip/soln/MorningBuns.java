import java.util.*;
import java.io.*;
import java.math.*;

public class MorningBuns {
	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("MorningBunsIN.txt"));
		int n = Integer.parseInt(br.readLine());
	    while (n-->0) {
	        int s = Integer.parseInt(br.readLine());
	        char[][] cm = new char[s][s];
		    for (int r = 0; r < s; r++) {
		        cm[r] = br.readLine().toCharArray();
		    }
		    System.out.println(message_reveal(cm));
	    }
	}
	
	public String message_reveal(char[][] cm) {
		String ans = "";
		int s = cm.length;
		for (int d = 0; d < s/2; d++) {
		    String top = "";
		    String right = "";
		    String bot = "";
		    String left = "";
		    for (int i = d; i < s-1-d; i++) {
		        top += cm[d][i];
		        right += cm[i][s-1-d];
		        bot += cm[s-1-d][s-1-i];
		        left += cm[s-1-i][d];
		    }
		    ans += top+right+bot+left;
		}
		if (s % 2 == 1) {
            ans+= cm[s/2][s/2];
        }
		ans = ans.trim();
		ans = ans.replace('*', ' ');
		return ans;
	}
	
	public static void main (String[] args) throws Exception {
		new MorningBuns().run();
	}
}
