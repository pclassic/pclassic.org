import java.util.*;
import java.io.*;

public class BalancedDiet {

	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("BalancedDietIN.txt"));
		int n = Integer.parseInt(br.readLine());

		for (int i = 0; i < n; i++) {
			System.out.println(isBalanced(br.readLine()) ? "True" : "False");
		}
	}

	public static boolean isBalanced(String input) {
		Stack s = new Stack();

		for (int i = 0; i < input.length(); i++) {
			char curr = input.charAt(i);

			switch (curr) {
				case '(':
					s.push(')');
					break;
				case '[':
					s.push(']');
					break;
				case '{':
					s.push('}');
					break;
				default:
					if (s.isEmpty() || (char) s.pop() != curr) return false;
			}
		}

		return s.isEmpty();
	}

	public static void main(String[] args) throws Exception {
		new BalancedDiet().run();
	}
}