def tripleBears(arr):
    ways = 0
    freq_map = dict()

    for i, food in enumerate(arr):
        if food in freq_map:
            freq_map[food] = freq_map[food] + 1
        else:
            freq_map[food] = 1

        baby_meal = food/9
        mama_meal = food/3
        if i >= 2 and (mama_meal in freq_map) and (baby_meal in freq_map):
            ways = ways + (freq_map[baby_meal]*freq_map[mama_meal])
    return ways

#Do not modify below this line
if __name__ == '__main__':
    with open('TripleBearsIN.txt', 'r') as f:
        cases = int(f.readline().strip())
        for case in range(cases):
            arr = [int(i) for i in f.readline().strip().split()]
            print(tripleBears(arr))
