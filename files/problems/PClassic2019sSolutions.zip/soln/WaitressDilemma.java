import java.util.*;
import java.io.*;
import java.math.*;

public class WaitressDilemma {
    public void run() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("WaitressDilemmaIN.txt"));
        int tc = Integer.parseInt(br.readLine());
        while (tc-->0) {
            int n = Integer.parseInt(br.readLine());
            String[] s1 = br.readLine().split(" ");
            String[] s2 = br.readLine().split(" ");
            System.out.println(solve(n,Integer.parseInt(s1[0]),Integer.parseInt(s1[1]),Integer.parseInt(s2[0]),Integer.parseInt(s2[1])));
        }
    }
    
    public int solve(int n, int xs, int ys, int xd, int yd) {
        Queue<Point> q = new LinkedList<Point>();
        q.add(new Point(xs,ys,0));
        boolean[][] sm = new boolean[n][n];
        
        while(!q.isEmpty()) {
            Point p = q.poll();
            int x = p.x;
            int y = p.y;
            int t = p.t;
            if (x == xd && y == yd) {
                return t;
            }
            int[] xinc = {-2, -2, -1, -1, 1, 1, 2, 2};
            int[] yinc = {-1, 1, -2, 2, -2, 2, -1, 1};
            for (int i = 0; i < xinc.length; i++) {
                int nx = x + xinc[i];
                int ny = y + yinc[i];
                if (nx >= 1 && nx <= n && ny >= 1 && ny <= n && sm[nx-1][ny-1] == false) {
                    q.add(new Point(nx,ny,t+1));
                    sm[nx-1][ny-1] = true;
                }
            }
        }
        return -1;
    }
    
    public static void main (String[] args) throws Exception {
        new WaitressDilemma().run();
    }
}
class Point {
    int x;
    int y;
    int t;
    public Point(int x, int y, int t) {
        this.x = x;
        this.y = y;
        this.t = t;
    }
    public String toString() {
        return "(" + x + " " + y + " " + t + ")";
    }
}