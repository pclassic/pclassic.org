import java.util.*;
import java.io.*;

public class TripleBears {

	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("TripleBearsIN.txt"));	
		int n = Integer.parseInt(br.readLine()); // number of test cases

		for (int i = 0 ; i < n; i++) {
			String[] input = br.readLine().split(" ");
			int[] arr = new int[input.length];

			for (int j = 0; j < input.length; j++) {
				arr[j] = Integer.parseInt(input[j]);
			}

			System.out.println(tripleBears(arr));
		}
	}

	public static int tripleBears(int[] arr) {
		Map<Double, Integer> freq = new HashMap<>();
		int tripleCount = 0;

		for (int i = 0; i < arr.length; i++) {
			double curr = arr[i];

			// add to frequency map
			if (freq.containsKey(curr)) {
				freq.put(curr, freq.get(curr) + 1);
			} else {
				freq.put(curr, 1);
			}

			// check if can make pairs
			if (i >= 2 && freq.containsKey(curr * 1.0 / 3) && freq.containsKey(curr * 1.0 / 9)) {
				int fst = freq.get(curr * 1.0 / 3);
				int snd = freq.get(curr * 1.0 / 9);

				tripleCount += fst * snd;
			}
		}

		return tripleCount;
	}

	public static void main(String[] args) throws Exception {
		new TripleBears().run();
	}
}