def solve(mesg1, mesg2):
    m = len(mesg1)
    n = len(mesg2)
    
    dp = [[0 for i in range(n + 1)]
          for i in range(m + 1)]

    for i in range(m + 1):
        for j in range(n + 1):
            if i == 0:
                dp[i][j] = j
            elif j == 0:
                dp[i][j] = i
            elif mesg1[i-1] == mesg2[j-1]:
                dp[i][j] = dp[i-1][j-1]
            else:
                a = dp[i-1][j-1]
                b = dp[i-1][j]
                c = dp[i][j-1]
                dp[i][j] = min(a, min(b, c)) + 1
    
    return dp[m][n]

#Do not modify below this line
if __name__ == '__main__':
    with open('CupcakeClubIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            for i in range(int(s)):
                sa = f.readline().strip().split(" ")
                print(solve(sa[0], sa[1]))
