import java.io.*;
import java.util.*;

// https://en.wikibooks.org/wiki/Algorithm_Implementation/Geometry/Convex_hull/Monotone_chain#Java

public class ExoticOrchard {
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("ExoticOrchardIN.txt"));
            int N = Integer.parseInt(br.readLine());

            for (int i = 0; i < N; i++) {
                String[] line = br.readLine().split(",");
                Point newPoint = new Point(Integer.parseInt(line[0].substring(1)),
                        Integer.parseInt(line[1].substring(1, line[1].length() - 1)));
                int K = Integer.parseInt(br.readLine());
                Point[] P = new Point[K];
                for (int j = 0; j < K; j++) {
                    line = br.readLine().split(",");
                    P[j] = new Point(Integer.parseInt(line[0].substring(1)),
                            Integer.parseInt(line[1].substring(1, line[1].length() - 1)));
                }
                System.out.println(exoticOrchard(newPoint, P) ? "1" : "0");
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static class Point implements Comparable<Point> {
        int x, y;

        public Point(int x, int y) {
            this.x = x;
            this.y = y;
        }

        public int compareTo(Point p) {
            if (this.x == p.x) {
                return this.y - p.y;
            } else {
                return this.x - p.x;
            }
        }

        public String toString() {
            return "(" + x + "," + y + ")";
        }
    }

    public static boolean exoticOrchard(Point newPoint, Point[] P) {
        Point[] p1 = Arrays.copyOf(P, P.length + 1);
        p1[p1.length - 1] = newPoint;
        if (Arrays.equals(convex_hull(P), convex_hull(p1)))
            return true;
        else
            return false;
    }

    public static long cross(Point O, Point A, Point B) {
        return (A.x - O.x) * (long) (B.y - O.y) - (A.y - O.y) * (long) (B.x - O.x);
    }

    public static Point[] convex_hull(Point[] P) {

        if (P.length > 1) {
            int n = P.length, k = 0;
            Point[] H = new Point[2 * n];

            Arrays.sort(P);

            // Build lower hull
            for (int i = 0; i < n; ++i) {
                while (k >= 2 && cross(H[k - 2], H[k - 1], P[i]) <= 0)
                    k--;
                H[k++] = P[i];
            }

            // Build upper hull
            for (int i = n - 2, t = k + 1; i >= 0; i--) {
                while (k >= t && cross(H[k - 2], H[k - 1], P[i]) <= 0)
                    k--;
                H[k++] = P[i];
            }
            if (k > 1) {
                H = Arrays.copyOfRange(H, 0, k - 1); // remove non-hull vertices after k; remove k - 1 which is a
                                                     // duplicate
            }
            return H;
        } else if (P.length <= 1) {
            return P;
        } else {
            return null;
        }
    }
}