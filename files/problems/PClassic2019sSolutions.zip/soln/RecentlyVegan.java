import java.util.*;
import java.io.*;

public class RecentlyVegan {
    //Do not modify below this line
     public void run() throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("RecentlyVeganIN.txt"));
        String line;
        while ((line = br.readLine()) != null) {
            int n = Integer.parseInt(line);
            String[] A = br.readLine().split(", ");
            System.out.println(solve(n, A));
        }
    }
    // Do not modify above this line
     
     public int solve(int n, String[] A) {
         int count = 0;
         for (int i = 1; i <= n; i++) {
             for (int j = 0; j < A.length; j++) {
                 if (i % Integer.parseInt(A[j]) == 0) {
                     count++;
                     break;
                 }
             }
         }
         return count;
     }
     
     public static void main(String[] args) throws Exception {
         new RecentlyVegan().run();
     }
}