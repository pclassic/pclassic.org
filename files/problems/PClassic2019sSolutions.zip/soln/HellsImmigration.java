import java.io.*;
import java.util.*;

public class HellsImmigration {
    // Do not change anything in main method
    public static void main(String[] args) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("HellsImmigrationIN.txt"));
			int testCases = Integer.parseInt(br.readLine());
			
			for (int i = 0; i < testCases; i++) {
                String[] line = br.readLine().split(" ");
                int N = Integer.parseInt(line[0]);
                int M = Integer.parseInt(line[1]);

                List<Shift> shift = new ArrayList<> ();
				for (int j = 0; j < N; j++) {
                    line = br.readLine().split(" ");
                    shift.add(new Shift(Integer.parseInt(line[0]), Integer.parseInt(line[1])));
                }
                List<Edge> edges = new ArrayList<> ();
                for (int j = 0; j < M; j++) {
                    line = br.readLine().split(" ");
                    edges.add(new Edge(Integer.parseInt(line[0]), Integer.parseInt(line[1]), Integer.parseInt(line[2])));
                }
                line = br.readLine().split(" ");
                int s = Integer.parseInt(line[0]);
                int d = Integer.parseInt(line[1]);
				System.out.println(helpRordon(N, M, shift, edges, s, d));
            }
            br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    // Start coding below this

    public static int helpRordon(int n, int m, List<Shift> shift, List<Edge> edges, int s, int d) {
        PriorityQueue<Node> pq = new PriorityQueue<>();
        int[] dist = new int[n + 1];
        Map<Integer, List<Node>> adj = new HashMap<>();
        for (Edge edge : edges) {
            if (!adj.containsKey(edge.u)) {
                List<Node> temp = new ArrayList<>();
                temp.add(new Node(edge.v, edge.weight));
                adj.put(edge.u, temp);
            } else {
                adj.get(edge.u).add(new Node(edge.v, edge.weight));
            }
            if (!adj.containsKey(edge.v)) {
                List<Node> temp = new ArrayList<>();
                temp.add(new Node(edge.u, edge.weight));
                adj.put(edge.v, temp);
            } else {
                adj.get(edge.v).add(new Node(edge.u, edge.weight));
            }
        }

        dist[0] = -1;
        for (int i = 1; i < n + 1; i++) {
            dist[i] = Integer.MAX_VALUE;
        }
        pq.add(new Node(s, 0));
        dist[s] = 0;

        while (!pq.isEmpty()) {
            Node node = pq.poll();
            int currDist = node.weight;
            int shift1 = shift.get(node.u - 1).first;
            int shift2 = shift.get(node.u - 1).second;
            int extra = 0;
            if (currDist % (shift1 + shift2) >= shift1) extra = shift1 + shift2 - (currDist % (shift1 + shift2));
            
            for (Node N : adj.get(node.u)) {
                int next = N.u;
                int weight = N.weight;
                int time = currDist + weight;
                if (dist[next] == -1 || dist[next] > time + extra) {
                    dist[next] = time + extra;
                    pq.add(new Node(next, dist[next]));
                }
            }
        }
        return dist[d];
    }

    static class Node implements Comparable<Node> {
        public int u;
        public int weight;

        public Node(int u, int weight) {
            this.u = u;
            this.weight = weight;
        }

        public int compareTo(Node n) { 
            if (this.weight < n.weight) return -1; 
            if (this.weight > n.weight) return 1;
            return 0; 
        } 
    }

    static class Shift {
        public int first;
        public int second;

        public Shift(int first, int second) {
            this.first = first;
            this.second = second;
        }
    }

    static class Edge {
        public int u;
        public int v;
        public int weight;

        public Edge(int u, int v, int weight) {
            this.u = u;
            this.v = v;
            this.weight = weight;
        }
    }
}