import queue

def helpRordan(n, m, shift, edges, s, d):
  graph = [[]]
  dist = [-1]
  pq = queue.PriorityQueue()

  for i in range(n):
    graph.append([])
    dist.append(-1)
  
  for (b, e, w) in edges:
    graph[b].append((e,w))
    graph[e].append((b,w))

  pq.put((s, 0))
  dist[s] = 0

  while (not pq.empty()):
    node, currDist = pq.get()
    shift1, shift2 = shift[node - 1]
    extra = 0
    if (currDist % (shift1 + shift2) >= shift1):
      extra = shift1 + shift2 - (currDist % (shift1 + shift2))
    
    for next, weight in graph[node]:
      time = currDist + weight
      if (dist[next] == -1):
        dist[next] = time + extra
        pq.put((next, dist[next]))
      elif (dist[next] > time + extra):
        dist[next] = time + extra
        pq.put((next, dist[next]))
  return dist[d]

if __name__ == '__main__':
  with open('HellsImmigrationIN.txt', 'r') as f:
    num_test_cases = int(f.readline().strip())
    for i in range(num_test_cases):
      n, m = f.readline().strip().split()
      n, m = int(n), int(m)
      shift = []
      edges = []
      for i in range(0, n):
        first, second = f.readline().strip().split()
        first, second = int(first), int(second)
        shift.append((first, second))
        
      
      for i in range(0, m):
        b, e, w = f.readline().strip().split()
        b, e, w = int(b), int(e), int(w)
        edges.append((b,e,w))
        
      
      s, d = f.readline().strip().split()
      s, d = int(s), int(d)
      print(helpRordan(n, m, shift, edges, s, d))
      