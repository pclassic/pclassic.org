def minDishes(num_islands, bridges):
    map = []
    max_bridges_to_island = 0
    for i in range(num_islands):
        map.append([])
    for bridge in bridges:
        map[bridge[0]].append(bridge[1])
        map[bridge[1]].append(bridge[0])
    for bridges_to_island in map:
        max_bridges_to_island = max(max_bridges_to_island, len(bridges_to_island))
    return max_bridges_to_island + 1

#Do not modify below this line
if __name__ == '__main__':
    with open('PicnicDayIN.txt', 'r') as f:
        cases = int(f.readline().strip())
        for case in range(cases):
            num_islands = int(f.readline().strip())
            bridges = []
            for i in range(num_islands - 1):
                bridges.append(f.readline().strip().split())
            bridges = [[int(a), int(b)] for [a,b] in bridges]
            print(minDishes(num_islands, bridges))
