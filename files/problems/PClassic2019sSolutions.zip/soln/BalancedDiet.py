def is_balanced(str):
    if str == '': # edge case
        return True
    stack = []
    mapping = {
        '(': ')',
        '{': '}',
        '[': ']'
    }
    for c in str:
        if c in mapping.keys():
            stack.append(c)
        else:
            if not stack or mapping[stack.pop()] != c:
                return False
    return not stack # want empty list at the end

#Do not modify below this line
if __name__ == '__main__':
    with open('BalancedDietIN.txt', 'r') as f:
        n = int(f.readline().strip())
        while True:
            str = f.readline().strip() # read input
            if str == '':
                break
            print(is_balanced(str))
