import java.util.*;
import java.io.*;
import java.math.*;

public class CupcakeClub {
	public void run() throws Exception {
		BufferedReader br = new BufferedReader(new FileReader("CupcakeClubIN.txt"));
		int n = Integer.parseInt(br.readLine());
	    while (n-->0) {
	        String[] sa = br.readLine().split(" ");
	        System.out.println(solve(sa[0],sa[1]));
	    }
	}
	
	public int solve(String message1, String message2) {
		int m = message1.length();
		int n = message2.length();
		int[][] dp = new int[m+1][n+1];
		for (int i = 0; i < m+1; i++) {
		    for (int j = 0; j < n+1; j++) {
		        if (i == 0) {
		            dp[i][j] = j;
		        }
		        else if (j == 0) {
		            dp[i][j] = i;
		        }
		        else if (message1.charAt(i-1) == message2.charAt(j-1)) {
		            dp[i][j] = dp[i-1][j-1];
		        }
		        else {
		            int a = dp[i-1][j-1];
		            int b = dp[i-1][j];
		            int c = dp[i][j-1];
		            dp[i][j] = Math.min(a, Math.min(b, c)) + 1;
		        }
		    }
		}
		return dp[m][n];
	}
	
	public static void main (String[] args) throws Exception {
		new CupcakeClub().run();
	}
}
