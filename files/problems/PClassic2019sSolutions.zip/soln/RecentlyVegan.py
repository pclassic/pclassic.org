def solve(n, A):
    c = 0
    for i in range(1, n + 1):
        for j in range(len(A)):
            if i % int(A[j]) == 0:
                c += 1
                break
    return c

#Do not modify below this line
if __name__ == '__main__':
    with open('RecentlyVeganIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            t = f.readline().strip().split(", ")
            print(solve(int(s), t))
