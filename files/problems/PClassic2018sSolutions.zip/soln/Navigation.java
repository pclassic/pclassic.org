import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.ArrayDeque;

class Obstacle {
  long xPosition;
  long yPosition;
  long detectionRange;
  Obstacle(){}
}

class Vertex {
  HashMap<Integer, Integer> edges;
  Vertex() { edges = new HashMap<Integer,Integer>(); }
}

public class Navigation {
  // Before submitting, make sure the main method hasn't been changed!
  public static void main(String[] args) throws IOException {
    BufferedReader br = new BufferedReader(new FileReader("NavigationIN.txt"));

    while (br.ready()) {
      String[] data = br.readLine().split(" ");
      long width = Long.parseLong(data[0]);
      long height = Long.parseLong(data[1]);
      int n = Integer.parseInt(br.readLine()); 
      Obstacle[] obs = new Obstacle[n];
      for (int i = 0; i < n; i++) {
        obs[i] = new Obstacle();
        data = br.readLine().split(" ");
        obs[i].xPosition = Long.parseLong(data[0]);
        obs[i].yPosition = Long.parseLong(data[1]);
        obs[i].detectionRange = Long.parseLong(data[2]);
      }

      System.out.println(minObstacles(width, height, obs));
    }
    br.close();
  }

  private static long dist_sq(long x1, long y1, long x2, long y2) {
    return (x2 - x1)*(x2 - x1) + (y2 - y1)*(y2 - y1);
  }

  // Fill out the body of this method
  public static long minObstacles(long width, long height, Obstacle[] obstacles) {
    Vertex[] vertices = new Vertex[2 + obstacles.length * 2];
    int source = 2 * obstacles.length;
    int sink = 2 * obstacles.length + 1;
    for (int i = 0; i < vertices.length; i++) vertices[i] = new Vertex();
    int INF = obstacles.length + 1; // "effectively infinite"
    for (int i = 0; i < obstacles.length; i++) {
      vertices[2 * i].edges.put(2 * i + 1, 1);
      vertices[2 * i + 1].edges.put(2 * i, 0);
      if (obstacles[i].yPosition >= height - obstacles[i].detectionRange) {
        vertices[source].edges.put(2 * i, INF);
        vertices[2 * i].edges.put(source, 0);
      }
      if (obstacles[i].yPosition <= obstacles[i].detectionRange) {
        vertices[2 * i + 1].edges.put(sink, INF);
        vertices[sink].edges.put(2 * i + 1, 0);
      }
      for (int j = 0; j < obstacles.length; j++) {
        if (i == j) continue;
        if (dist_sq(obstacles[i].xPosition, obstacles[i].yPosition, obstacles[j].xPosition, obstacles[j].yPosition) <= 
            (obstacles[i].detectionRange + obstacles[j].detectionRange)*(obstacles[i].detectionRange + obstacles[j].detectionRange)) {
          vertices[2 * i + 1].edges.put(2 * j, INF);
          vertices[2 * j].edges.put(2 * i + 1, 0);
        }
      }
    }
    // Now, use the Ford-Fulkerson algorithm to find max-flow
    boolean hasFlow = false;
    long ret = 0;
    ArrayDeque<Integer> q = new ArrayDeque<Integer>(vertices.length + 1);
    int[] prev = new int[vertices.length];
    do {
      q.clear();
      hasFlow = false;
      for (int i = 0; i < prev.length; i++) prev[i] = -1;
      q.addLast(source);
      while (!q.isEmpty()) {
        int cur = q.removeFirst();
        if (cur == sink) {
          hasFlow = true;
          break;
        }
        for (HashMap.Entry<Integer, Integer> entry : vertices[cur].edges.entrySet()) {
          int nxt = entry.getKey();
          int cap = entry.getValue();
          if (prev[nxt] != -1 || cap <= 0) continue;
          prev[nxt] = cur;
          q.addLast(nxt);
        }
      }
      if (hasFlow) {
        ret++;
        int cur = sink;
        while (cur != source) {
          vertices[prev[cur]].edges.put(cur, vertices[prev[cur]].edges.get(cur) - 1);
          vertices[cur].edges.put(prev[cur], vertices[cur].edges.get(prev[cur]) + 1);
          cur = prev[cur];
        }
      }
    } while (hasFlow);
    return ret;
  }
}
