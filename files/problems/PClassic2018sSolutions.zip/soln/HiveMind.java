import java.io.*;
import java.util.*;

public class HiveMind {

    static class Event {
        int type;
        int robot1;
        int robot2;
    
        public Event(int type, int robot1, int robot2) {
            this.type = type;
            this.robot1 = robot1;
            this.robot2 = robot2;
        }
        
        int getType() {
            return type;
        }
        
        int getRobot1() {
            return robot1;
        }
        
        int getRobot2() {
            return robot2;
        }
    
    }

    static Map<Integer,Integer> robotToNode;
    static List<Integer> parent;
    static Random rand;
    
    public static void main(String[] args) throws FileNotFoundException {

        Scanner fileInput = new Scanner(new FileReader("HiveMindIN.txt"));

        while(fileInput.hasNext()) {
            List<Event> events = new ArrayList<Event>();
            int N = Integer.parseInt(fileInput.nextLine());
            for(int i = 0; i < N; i++) {
                String[] nextRow = fileInput.nextLine().split(" ");
                int type = Integer.parseInt(nextRow[0]);
                int robot1 = Integer.parseInt(nextRow[1]);
                int robot2 = Integer.parseInt(nextRow[2]);
                events.add( new Event(type, robot1, robot2));
            }
            List<Boolean> answer = solver(events);
            for(Boolean b : answer) {
                System.out.println(b ? "True" : "False");
            }
            System.out.println();
        }
        fileInput.close();
    }
    
    private static void addRobot(int robot) {
        int n = parent.size();
        parent.add(n);
        robotToNode.put(robot, n);
    }
    
    private static int getNode(int robot) {
        if(!robotToNode.containsKey(robot)) {
            addRobot( robot );
        }
        return robotToNode.get(robot);
    }
    
    private static int getRep(int a) {
        if( parent.get(a) == a ) {
            return a;
        }
        parent.set(a, getRep(parent.get(a)));
        return parent.get(a);
    }
    
    private static void unite(int a, int b) {
        a = getRep(a);
        b = getRep(b);
        if( a != b ) {
            parent.set(a, b);
        }
    }
    
    private static List<Boolean> solver(List<Event> events){
        robotToNode = new HashMap<Integer, Integer>();
        parent = new ArrayList<Integer>();
        rand = new Random();
        List<Boolean> answer = new ArrayList<Boolean>();
        for( Event e : events ) {
            int robot1 = e.getRobot1();
            int robot2 = e.getRobot2();
            int node1 = getNode(robot1);
            int node2 = getNode(robot2);
            
            
            int type = e.getType();
            if(type == 0) {
                unite(node1, node2);
            }
            else if(type == 1) {
                addRobot(robot1);
                node1 = getNode(robot1);
                node2 = getNode(robot2);
                unite(node1, node2);
                
                // tricky case when robot1 == robot2
            }
            else if(type == 2) {
                answer.add(getRep(node1) == getRep(node2));
            }
            else {
                throw new IllegalArgumentException();
            }
        }
        return answer;
    }
}