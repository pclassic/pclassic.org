def sum(arr):
    if arr is None:
        return 0
    elif len(arr) == 1:
        return max(0, arr[0])

    excl = 0
    incl = arr[0]

    for i in range(1, len(arr)):
        exclTemp = max(incl, excl)
        incl = excl + arr[i]
        excl = exclTemp

    return max(incl, excl)


# DO NOT MODIFY BELOW THIS LINE
if __name__ == '__main__':
    with open('SumIN.txt', 'r') as f:
        while True:
            line = f.readline()
            if line == '': # EOF
                break
            arr = [int(x) for x in line.split()]
            print(sum(arr))
