import java.util.*;
import java.io.*;

class QuickMaths {
	
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		while (sc.hasNextLine()) {
			String expr = sc.nextLine();
			System.out.println(quickMaths(expr));
		}

	}

	private static boolean isDigit(String s) {
		for (int i = 0; i < s.length(); i++) {
			if (!Character.isDigit(s.charAt(i))) {
				return false;
			}
		}
		return true;
	}

	public static int quickMaths(String s) {
	
		Queue<String> tokens = new LinkedList<String>();
		Stack<Integer> values = new Stack<Integer>();
	    Stack<Character> operators = new Stack<Character>();


	    for (String token : s.split(" ")) {
	    	tokens.add(token);
	    }

	    while (!tokens.isEmpty()) {
	    	String currToken = tokens.poll();
	    	if (isDigit(currToken)) {
	    		values.push(Integer.parseInt(currToken));
	    	} else if (currToken.equals("(")) {
	    		operators.push('(');
	    	} else if (currToken.equals(")")) {
	    		while (operators.peek() != '(') {
	    			Character op = operators.pop();
	    			int secondVal = values.pop();
	    			int firstVal = values.pop();

	    			if (op == '+') {
	    				values.push(firstVal + secondVal);
	    			} else if (op == '-') {
	    				values.push(firstVal - secondVal);
	    			} else if (op == '*') {
	    				values.push(firstVal * secondVal);
	    			} else {
	    				values.push(firstVal / secondVal);
	    			}
	    		}
	    		operators.pop();
	    	} else {
	    		while (!operators.isEmpty() && operators.peek() != '(' && 
	    			((!currToken.equals("+") && !currToken.equals("/")) ||
	    				(operators.peek() != '+' && operators.peek() != '-'))) {
	    				while (operators.peek() != '(') {
	    			Character op = operators.pop();
	    			int secondVal = values.pop();
	    			int firstVal = values.pop();

	    			if (op == '+') {
	    				values.push(firstVal + secondVal);
	    			} else if (op == '-') {
	    				values.push(firstVal - secondVal);
	    			} else if (op == '*') {
	    				values.push(firstVal * secondVal);
	    			} else {
	    				values.push(firstVal / secondVal);
	    			}
	    		}
	    		operators.pop();
	    			}
	    		operators.push(currToken.charAt(0));
	    	}
	    }

	    while (!operators.isEmpty()) {
	    	while (operators.peek() != '(') {
	    			Character op = operators.pop();
	    			int secondVal = values.pop();
	    			int firstVal = values.pop();

	    			if (op == '+') {
	    				values.push(firstVal + secondVal);
	    			} else if (op == '-') {
	    				values.push(firstVal - secondVal);
	    			} else if (op == '*') {
	    				values.push(firstVal * secondVal);
	    			} else {
	    				values.push(firstVal / secondVal);
	    			}
	    		}
	    }
	    
	    return values.peek();

	}

}