import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Reverse {
	
	public static void main(String[] args) throws IOException{
		Scanner sc = new Scanner(new FileReader("ReverseIN.txt"));
		while(sc.hasNext()) {
			String str = sc.nextLine();
			System.out.println(ReverseWords(str));
		}
	}
	public static String ReverseWords(String input) {
		StringBuilder result = new StringBuilder();
		StringBuilder word = new StringBuilder();
			for(int i = 0; i < input.length(); i++){
			if(input.charAt(i) != ' ') {
				word.append(input.charAt(i));
			}
			else {
				result.append(word.reverse());
				result.append(" ");
				word.setLength(0);
			}
		}
		result.append(word.reverse());
		return result.toString();
	}
	
}