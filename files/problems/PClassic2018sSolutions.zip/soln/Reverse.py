def reverse(line):
    words = line.split(" ")
    revarr = []
    for i in words:
        revarr.append(i[::-1])
    revstring = ""
    for i in revarr:
        revstring += i
        revstring += " "
    return revstring
        


# DO NOT MODIFY BELOW THIS LINE
if __name__ == '__main__':
    with open('ReverseIN.txt', 'r') as f:
        while True:
            line = f.readline()
            if line == '': # EOF
                break
            print(reverse(line))
