def gold_rush(l):
    A = l
    last_index = {x: i for i, x in enumerate(A)}
    for i, x in enumerate(A):
        for d in range(9, x, -1):
            if last_index.get(d, None) is not None:
                if last_index[d] > i:
                    A[i], A[last_index[d]] = A[last_index[d]], A[i]
                    return ''.join(map(str, A))
    return ''.join(map(str, l))

if __name__ == '__main__':
    with open('GoldRushIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            print(str(gold_rush(list(map(int, s.split())))))