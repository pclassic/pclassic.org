def distance(a, b):
    return bin(a ^ b).count('1')

if __name__ == '__main__':
    with open('GoingTheDistanceIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            t = f.readline().strip()
            if s == '':
                break
            print(distance(int(s), int(t)))