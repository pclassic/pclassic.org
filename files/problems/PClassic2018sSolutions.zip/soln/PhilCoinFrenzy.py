def can_exchange(n):
    n2 = str(n**2)
    for i in range(len(n2)):
        a, b = int(n2[:i] or 0), int(n2[i:])
        if b and a + b == n:
            return True
    return False

if __name__ == '__main__':
    with open('PhilCoinFrenzyIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            print(can_exchange(int(s)))