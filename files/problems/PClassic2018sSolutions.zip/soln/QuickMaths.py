def quick_maths(l):
    tokens = l.strip().split()
    values = []
    operators = []

    def evaluation():
        n = operators.pop()
        second_value = values.pop()
        first_value = values.pop()
        if n == '+':
            values.append(first_value + second_value)
        elif n == '-':
            values.append(first_value - second_value)
        elif n == '*':
            values.append(first_value * second_value)
        else:
            values.append(int(first_value / second_value))

    while len(tokens) != 0:
        curr_token = tokens.pop(0)
        if curr_token.isdigit():
            values.append(int(curr_token))
        elif curr_token == '(':
            operators.append(curr_token)
        elif curr_token == ')':
            while operators[-1] != '(':
                evaluation()
            operators.pop()
        else:
            while len(operators) != 0 and operators[-1] != '(' and (curr_token not in ['*', '/'] or
                                                                    operators[-1] not in ['+', '-']):
                evaluation()
            operators.append(curr_token)
    while len(operators) != 0:
        evaluation()
    return int(values[0])

if __name__ == '__main__':
    with open('QuickMathsIN.txt', 'r') as f:
        while True:
            s = f.readline().strip()
            if s == '':
                break
            print(str(int(quick_maths(s))))