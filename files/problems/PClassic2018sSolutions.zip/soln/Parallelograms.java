import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Parallelograms {

    static class MyPoint implements Comparable<MyPoint>{

	    public int x;
	    public int y;
	    
	    public MyPoint(int x, int y) {
	        this.x = x;
	        this.y = y;
	    }
	
	    @Override
	    public int compareTo(MyPoint v) {
	        if( this.x != v.x ) {
	            return this.x - v.x;
	        }
	        return this.y - v.y;
	    }
    }

    public static void main(String[] args) throws FileNotFoundException {

        Scanner fileInput = new Scanner(new File("ParallelogramsIN.txt"));

        List<MyPoint> points = null;
        while(fileInput.hasNext()) {
            points = new ArrayList<MyPoint>();
            int N = Integer.parseInt(fileInput.nextLine());
            
            for(int i = 0; i < N; i++) {
                String[] nextRow = fileInput.nextLine().trim().split(" ");
                int x = Integer.parseInt(nextRow[0]);
                int y = Integer.parseInt(nextRow[1]);
                points.add( new MyPoint(x, y) );
            }
            System.out.println( solver( points ) );
        }
        fileInput.close();
    }
    
    public static int solver( List<MyPoint> points ) {
        List<MyPoint> sumOfPoints = new ArrayList<MyPoint>();
        

        
        
        for(int i = 0; i < points.size(); i++) {
            for(int j = i+1; j < points.size(); j++) {
                MyPoint sum = new MyPoint(points.get(i).x + points.get(j).x, points.get(i).y + points.get(j).y);
                sumOfPoints.add( sum );
            }
        }
        Collections.sort(sumOfPoints);
        
        
        
        int answer = 0;
        for(int i = 0; i < sumOfPoints.size()-1; ) {
            int len = 1;
            while( (i + len < sumOfPoints.size()) && (sumOfPoints.get(i+len).x == sumOfPoints.get(i).x) && (sumOfPoints.get(i+len).y == sumOfPoints.get(i).y) ) {
                len++;
            }
            answer += ((len - 1) * len) / 2;
            i+=len;
        }
        return answer;
    }
}