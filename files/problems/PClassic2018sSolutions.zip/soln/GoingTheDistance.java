import java.util.*;
import java.io.*;

class GoingTheDistance {
	
	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(new FileReader("GoingTheDistanceIN.txt"));
		while (sc.hasNext()) {
			long s = sc.nextLong();
			long t = sc.nextLong();
			System.out.println(distance(s, t));
		}

	}

	public static int distance(long a, long b) {
		int count = 0;
		long xor = a ^ b;
		String bin = Long.toBinaryString(xor);
		for (int i = 0; i < bin.length(); i++) {
			if (bin.charAt(i) == '1') {
				count++;
			}
		}
		return count;
	}

}