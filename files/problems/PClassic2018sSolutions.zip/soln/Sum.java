import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Sum {
  public static void main(String[] args) {
    try {
      BufferedReader br = new BufferedReader(new FileReader("SumIN.txt"));
      while (br.ready()) {
        String[] splitted = br.readLine().split("\\s+");
        int[] arr = new int[splitted.length];
        for (int i = 0; i < splitted.length; i++) {
          arr[i] = Integer.parseInt(splitted[i]);
        }
        System.out.println(maxSum(arr));
      }
      br.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public static int maxSum(int[] arr) {
     if (arr == null) {
       return 0;
     } else if (arr.length == 1) {
       return Math.max(0, arr[0]);
     }

     int excl = 0; // maximum sum not including the current element
     int incl = arr[0]; // maximum sum including the current element

     for (int i = 1; i < arr.length; i++) {
       // current max excluding current element
       int exclTemp = Math.max(incl, excl);
       // current max including current element
       incl = excl + arr[i];
       excl = exclTemp;  // update current max excluding current element
     }

     return Math.max(excl, incl);
   }
 }
