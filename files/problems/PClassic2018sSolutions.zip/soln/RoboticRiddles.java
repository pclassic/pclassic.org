import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class RoboticRiddles {

    /* DO NOT MODIFY BELOW THIS LINE */
    public static void main(String[] args) {
        try {
            BufferedReader br = new BufferedReader(new FileReader("RoboticRiddlesIN.txt"));
            while (br.ready()) {
                String[] splitted = br.readLine().split("\\s+");
                List<int[]> split = new LinkedList<int[]>();
                for (int i = 0; i < splitted.length; i++) {
                    int[] addthis = new int[2];
                    addthis[0] = Integer.parseInt(splitted[i].split(",")[0]);
                    addthis[1] = Integer.parseInt(splitted[i].split(",")[1]);
                    split.add(addthis);
                }
                System.out.println(TestRobots(split) ? "True" : "False");
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /* DO NOT MODIFY ABOVE THIS LINE */

    public static boolean TestRobots(List<int[]> robots) {
        HashMap<Integer, List<Integer>> graph = new HashMap<Integer, List<Integer>>();
        Set<Integer> answers = new TreeSet<Integer>();
        //Build graph and answer set
        for (int[] x : robots) {
            answers.add(x[0]);
            answers.add(x[1]);
            if (!(graph.containsKey((-1) * x[0]))) {
                List<Integer> l = new LinkedList<Integer>();
                l.add(x[1]);
                graph.put((-1) * x[0], l);
            } else {
                List<Integer> l = graph.get((-1) * x[0]);
                l.add(x[1]);
                graph.put((-1) * x[0], l);
            }
            if (!(graph.containsKey((-1) * x[1]))) {
                List<Integer> l = new LinkedList<Integer>();
                l.add(x[0]);
                graph.put((-1) * x[1], l);
            } else {
                List<Integer> l = graph.get((-1) * x[1]);
                l.add(x[0]);
                graph.put((-1) * x[1], l);
            }
        }
        //Run BFS from every possible start point,
        // make sure at least one leads to no contradiction
        for (Integer x : answers) {
            boolean first = false;
            boolean second = false;
            List<Integer> found = new LinkedList<>();
            found.add(x);
            List<Integer> marked = new LinkedList<>();
            while (found.size() > 0) {
                int item = found.remove(0);
                if (!(marked.contains(item))) {
                    List<Integer> next = graph.get(item);
                    if (next != null) {
                        for (Integer y : next) {
                            if (y == (-1) * x) {
                                first = true;
                            } else {
                                found.add(y);
                            }
                        }
                    }
                }
                marked.add(item);
            }
            found = new LinkedList<>();
            found.add(-1*x);
            marked = new LinkedList<>();
            while (found.size() > 0) {
                int item = found.remove(0);
                if (!(marked.contains(item))) {
                    if (graph.containsKey(item)) {
                        List<Integer> next = graph.get(item);
                        if (next != null) {
                            for (Integer y : next) {
                                if (y == x) {
                                    second = true;
                                } else {
                                    found.add(y);
                                }
                            }
                        }
                    }
                }
                marked.add(item);
            }
            if (first && second) {
                return false;
            }
        }
        return true;
    }

}