def testrobots(robotlist):
    # YOUR CODE HERE
    graph = {}
    vertexlist = []
    for i in  robotlist:
        if (-1*i[0] in graph):
            graph[-1*i[0]].append(i[1])
        else:
            graph[-1*i[0]] = [i[1]]
        if (-1*i[1] in graph):
            graph[-1*i[1]].append(i[0])
        else:
            graph[-1*i[1]] = [i[0]]
        vertexlist.append(i[0])
        vertexlist.append(i[1])

    for i in vertexlist:
        seen = []
        seen.append(i)
        check = []
        check.append(i)
        first = False
        while len(check) > 0:
            item = check[0]
            del check[0]
            if item in graph:
                for j in graph[item]:
                    if j not in seen:
                        seen.append(j)
                        check.append(j)
                        if (j == -1*i):
                            first = True
        
        seen = []
        seen.append(-1*i)
        check = []
        check.append(-1*i)
        second = False
        while len(check) > 0:
            item = check[0]
            del check[0]
            if item in graph:
                for j in graph[item]:
                    if j not in seen:
                        seen.append(j)
                        check.append(j)
                        if (j == i):
                            second = True
        if (first and second):
            return False
        
    return True
 
 
# DO NOT MODIFY BELOW THIS LINE
if __name__ == '__main__':
    with open('RoboticRiddlesIN.txt', 'r') as f:
        while True:
            line = f.readline()
            if line == '': # EOF
                break
            mylist = line.split()
            myfixedlist = [[int(y.split(',')[0]), int(y.split(',')[1])] for y in mylist]
            print(testrobots(myfixedlist))
