import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class EvilMerger {
	
	public static void main(String[] args) throws IOException{
		Scanner sc = new Scanner(new FileReader("EvilMergerIN.txt"));
		while(sc.hasNextLine()) {
			ArrayList<Integer> arr1 = new ArrayList<Integer>();
			ArrayList<Integer> arr2 = new ArrayList<Integer>();
			String str = sc.nextLine();
			String[] temp1 = str.split(",");
			for(int i = 0; i < temp1.length; i++) {
				arr1.add(Integer.parseInt(temp1[i].trim()));
			}
			String s = sc.nextLine();
			String[] temp2 = s.split(",");
			for(int i = 0; i < temp2.length; i++) {
				arr2.add(Integer.parseInt(temp2[i].trim()));
			}
			int[] arrX = new int[arr1.size()];
			int[] arrY = new int[arr2.size()];
			for(int i = 0; i < arr1.size(); i++) {
				arrX[i] = arr1.get(i).intValue();
				arrY[i] = arr2.get(i).intValue();
			}
			System.out.printf("%.2f\n", findCorrelation(arrX, arrY));
		}
	}
	
	public static double findCorrelation(int[] xArray, int[] yArray) {
		double avgX = 0.0;
		double avgY = 0.0;
		double stdX = 0.0;
		double stdY = 0.0;
		double corr = 0.0;
		int n = xArray.length;
		for(int i = 0; i < n; i++) {
		    avgX = avgX + xArray[i];
		    avgY = avgY + yArray[i];
		}
		avgX = avgX/(n * 1.0);		
		avgY = avgY/(n * 1.0);
		for(int i = 0; i < n; i++) {
			stdX = stdX + Math.pow(xArray[i] - avgX, 2);
			stdY = stdY + Math.pow(yArray[i] - avgY, 2);
		}
		stdX = stdX/((n - 1) * 1.0);
		stdY = stdY/((n - 1) * 1.0);
        stdX = Math.sqrt(stdX);
        stdY = Math.sqrt(stdY);
		for(int i = 0; i < xArray.length; i++) {
			corr = corr + ((xArray[i] - avgX)/stdX * 1.0) * ((yArray[i] - avgY)/stdY * 1.0);
		}
		corr = corr/((n - 1) * 1.0);
		return corr;
	}
}