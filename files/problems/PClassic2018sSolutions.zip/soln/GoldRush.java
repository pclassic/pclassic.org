import java.io.*;
import java.util.*;
 
class GoldRush {
     
    public static void main(String[] args) throws FileNotFoundException {
 
        Scanner sc = new Scanner(new FileReader("GoldRushIN.txt"));
        while (sc.hasNext()) {
            String s = sc.nextLine();
            String[] t = s.split(" ");
            int[] arr = new int[t.length];
            for (int i = 0; i < t.length; i++) {
                arr[i] = Integer.parseInt(t[i]);
            }
            System.out.println(goldRush(arr));
        }
 
    }

    public static String joinArr(int[] arr) {
        if (null == arr || 0 == arr.length) return "";

        StringBuilder sb = new StringBuilder(1000);
        sb.append(Integer.toString(arr[0]));

        for (int i = 1; i < arr.length; i++) {
            sb.append(Integer.toString(arr[i]));
        }

        return sb.toString();
    }
 
    public static String goldRush(int[] L) {
        int[] A = Arrays.copyOf(L, L.length);
        int[] lastIndex = new int[10];
        Arrays.fill(lastIndex, -1);
        for (int i = 0; i < A.length; i++) {
            lastIndex[A[i]] = i;
        }
        for (int i = 0; i < A.length; i++) {
            for (int d = 9; d > A[i]; d--) {
                if (lastIndex[d] > i) {
                    int temp = A[lastIndex[d]];
                    A[lastIndex[d]] = A[i];
                    A[i] = temp;
                    return joinArr(A);
                }
            }
        }
        return joinArr(L);
    }
 
}