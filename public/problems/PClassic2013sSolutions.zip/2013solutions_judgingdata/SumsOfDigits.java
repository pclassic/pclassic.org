import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SumsOfDigits {

	public static int PQOverlaps(int n){
		int max1 = 0;
		int max2 = 0;
		int maxVal = -1;
		for(int i = 2; i <= 15; i++){
			for(int j = i+1; j <= 16; j++){
				int count = 0;
				for(int k = 1; k <= n; k++){
					if(sumOfDigitsInBase(k, i) == sumOfDigitsInBase(k, j)){
						count++;
					}
				}
				if(count >= maxVal){
					maxVal = count;
					max1 = i;
					max2 = j;
				}
//				System.out.println(i+", "+j+", "+count);
			}
		}
		
		return 100 * max2 + max1;
		
	}
	
	public static int sumOfDigitsInBase(int num, int base){
		int total = 0;
		while (num > 0){
			total += num % base;
			num /= base;
		}
		return total;
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("sumsofdigits.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(PQOverlaps(val));
		}
	}
	
}
