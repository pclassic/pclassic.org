import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TreeSet;


public class Anagrams {
	static HashMap<Integer, TreeSet<String>> wordlists = null;
	static HashMap<String, TreeSet<String>> generations = new HashMap<String, TreeSet<String>>();
	static HashMap<String, HashMap<Character, Integer>> letterCounts = new HashMap<String, HashMap<Character, Integer>>();
	
	public static int solve(int n, String k, List<String> dictionary){
		if (k.length() == n){
//			System.out.println(k);
			return 1;
		}
		
		if(wordlists == null){
			wordlists = new HashMap<Integer, TreeSet<String>>();
			for(int i = 3; i <= 10; i++){
				wordlists.put(i, new TreeSet<String>());
			}
			//sort out the words into the accurate word list.
			for(String word:dictionary){
				wordlists.get(word.length()).add(word);
				letterCounts.put(word, getCounts(word));
			}
		}
		int total = 0;
		if(!generations.containsKey(k)){
			generations.put(k, generated(k));
		} 
		
		TreeSet<String> words = generations.get(k);
		for(String generated:words){
			total += solve(n, generated, dictionary);
		}
		
//		System.out.println(k +": "+generations.get(k));
		
		return total;
	}

	public static HashMap<Character, Integer> getCounts(String word){
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		for (char c : word.toCharArray()){
			if(map.containsKey(c)){
				map.put(c, map.get(c)+1);
			} else{
				map.put(c, 1);
			}
		}
		return map;
	}
	
	public static TreeSet<String> generated(String source){
		HashMap<Character, Integer> myCounts = letterCounts.get(source);
		TreeSet<String> words = new TreeSet<String>();
		for (String word:wordlists.get(source.length() + 1)){
			if(contains(letterCounts.get(word), myCounts)){
				words.add(word);
			}
		}
		return words;
	}
	
	public static boolean contains(HashMap<Character, Integer> set2, HashMap<Character, Integer> set1){
		for(char c : set1.keySet()){
			if(!set2.containsKey(c))
				return false;
			if(set2.get(c) < set1.get(c))
				return false;
		}
		
		return true;
	}
	
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("anagrams.txt"));
		boolean readingDictionary = true;
		ArrayList<String> dictionary = new ArrayList<String>();
		while(br.ready()){
			String line = br.readLine();
			if(readingDictionary){
				if(line.equals("***END***")){
					readingDictionary = false;
					continue;
				}
				if(line.length() < 9 && line.length() > 2){
					dictionary.add(line.toUpperCase());
				}
			} else{
				String[] split	= line.split(" ");
				int n = Integer.parseInt(split[0]);
				String k = split[1];
				System.out.println(solve(n, k, dictionary));
			}
		}
	}
	
}
