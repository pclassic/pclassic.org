import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class CircularPrimes {

	public static boolean isCircular(long number){
		if(number < 2) return false;
		if (number == 2) return true;
		
		long f;
		long l;
		long length = (long) (Math.log10(number) + 1);
		long ten = (long) Math.pow(10, length - 1);
		
		for(long i = 0; i <= length - 1; i++){
			if(!isPrime(number)) return false;

			l = number % ten;
			f = (number - l) / ten;
			
			number = 10 * l + f;
			
		}
		return true;
	}
	
	private static boolean isPrime(long n){
		for(int i = 2; i <= (int) Math.ceil(Math.sqrt(n)); i++)
			if(n % i == 0) return false;
		return true;
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("circularprimes.txt"));
		while(br.ready()){
			String line = br.readLine();
			long val = Integer.parseInt(line);
			System.out.println(line);
			System.out.println(isCircular(val));
		}
	}
}
