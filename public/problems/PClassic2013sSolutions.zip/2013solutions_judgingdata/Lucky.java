import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;


public class Lucky {
	
	public static boolean isLucky(int number){
		if(number % 2 == 0){
			return false;
		}
		boolean[] nums = new boolean[number + 10];
		
		for(int i = 1;i < nums.length;  i+=2){
			nums[i] = true;
		}
		int counter = 3;
		int temp = 0;
		while(counter < number){
			temp = 0;
			for(int i = 1; i < nums.length; i++){
				if (nums[i]){
					temp++;
					if(temp == counter){
						if(number == i){
							return false;
						}
						nums[i] = false;
						temp = 0;
					}
				}
			}
			for(int i = counter+1; i < nums.length; i++){
				if(nums[i]){
					counter = i;
					break;
				}
			}
		}
		return nums[number];
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("lucky.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(isLucky(val));
		}
	}
}
