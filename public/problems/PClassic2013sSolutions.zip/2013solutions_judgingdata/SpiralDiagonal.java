import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class SpiralDiagonal {
	  /* We recognize that the top-right hand corner of the spiral is n^2, so the
	   * top-left hand corner of the spiral is n^2 - (n - 1).
	   *
	   * We also recognize that the bottom-left hand corner is (n^2 - (n - 1) - 
	   * (n - 2)) = n^2 - 2n + 2, so the bottom-right hand corner is n^2 - 2n + 2 -
	   * (n - 1) = n^2 - 3n + 3.
	   */
		public static int sum (int N){
		    int total = 1;
				for (int i = 3; i <= N; i += 2) {
		      total += i*i - (i - 1);
		      total += i*i - 3*i + 3;
		    }
		    return total;
		}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("spiral.txt"));
		while(br.ready()){
			String line = br.readLine();
			int val = Integer.parseInt(line);
			System.out.println(sum(val));
		}
	}
}
