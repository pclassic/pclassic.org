import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class EquationSolver {

	public static int solve(String equation){
	    int a = 0, b = 0, c = 0; // quadratic coefficients
	    int e = 1, m = 1; // pos/neg multipliers for side of equal sign and +/-
	
	    String[] tokens = equation.split(" ");
	
	    for (String t : tokens) {
	      if (t.equals("=")) {
	        e = -e;
	        m = 1;
	      } else if (t.equals("+")) {
	        m = 1;
	      } else if (t.equals("-")) {
	        m = -1;
	      } else {
	        //account for negative coefficients
	        if (t.startsWith("-")) {
	          m = -m;
	          t = t.substring(1);
	        }
	        
	        //default coefficient to 1, else parse everything before the x
	        int coeff = e*m*((t.startsWith("x")) ? 1 : Integer.parseInt(t.split("x")[0]));
	
	        //figure out power of token
	        if (t.contains("^")) {
	          a += coeff;
	        } else if (t.contains("x")) {
	          b += coeff;
	        } else {
	          c += coeff;
	        }
	      }
	    }
	
	    if(a != 0){
		    //calculate two roots, return max
		    double x1 = (-b + Math.sqrt(b*b-4*a*c))/(2*a);
		    double x2 = (-b - Math.sqrt(b*b-4*a*c))/(2*a);
		    return (int)Math.round(Math.max(x1,x2));
	    }
    	return (int)Math.round((double)-1.0 * c / b);
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("equation.txt"));
		while(br.ready()){
			String line = br.readLine();
			System.out.println(solve(line));
		}
	}
	
	
}
