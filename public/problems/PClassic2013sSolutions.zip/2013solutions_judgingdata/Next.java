import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class Next {

	public static String getNext(String str){
		char last = str.charAt(str.length()-1);
		for(int i = str.length() - 2; i >= 0; i--){
			char current = str.charAt(i);
			if(current < last){
				char min = 'Z'; //looking for smallest character bigger than current
				for(int j = i + 1; j < str.length(); j++){
					char thisOne = str.charAt(j);
					if(thisOne < min && thisOne > current){
						min = thisOne;
					}
				}
				ArrayList<Character> chars = new ArrayList<Character>();
				chars.add(current);
				for(int j = i+1; j < str.length(); j++){
					if (str.charAt(j) != min){
						chars.add(str.charAt(j));
					}
				}
				Collections.sort(chars);
				StringBuilder st = new StringBuilder();
				for(int j = 0; j < chars.size(); j++){
					st.append(chars.get(j));
				}
//				System.out.println(str.substring(0,i)+", "+min+", "+st.toString());
				return str.substring(0,i) + min + st.toString(); 
			}
			
			
			last = current;
		}
		
		return null;
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("next.txt"));
		while(br.ready()){
			String line = br.readLine();
			System.out.println(getNext(line));
		}
	}
}
