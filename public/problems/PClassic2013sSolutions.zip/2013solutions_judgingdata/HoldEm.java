import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.TreeSet;


public class HoldEm {
	
	public static boolean p1wins(String player1, String player2, String community){
		
		HashSet<Card> p1 = processCards(player1);
		HashSet<Card> p2 = processCards(player2);
		HashSet<Card> comm = processCards(community);
		
		Hand h1 = new Hand(p1, comm);
		Hand h2 = new Hand(p2, comm);
//		System.out.println(h1.category+" "+h1.highRank+" "+h1.secondRank+" "+h1.kickers);
//		System.out.println(h2.category+" "+h2.highRank+" "+h2.secondRank+" "+h2.kickers);
		return h1.compareTo(h2) > 0;
	}
	
	public static HashSet<Card> processCards(String st){
		HashSet<Card> cards = new HashSet<Card>();
		String[] s = st.split(" ");
		for(String str : s){
			Card c = new Card(str);
			cards.add(c);
		}
		return cards;
	}
	
	public static void main(String [] args) throws IOException{
		BufferedReader br = new BufferedReader(new FileReader("holdem.txt"));
		while(br.ready()){
			String p1 = br.readLine();
			String p2 = br.readLine();
			String community = br.readLine();
			System.out.println(p1wins(p1, p2, community));
		}
	}
}

class Hand implements Comparable<Hand>{
	ArrayList<Card> cards = new ArrayList<Card>();
	int category; //straight flush = 9, 4 of a kind = 8, full house = 7, flush = 6,
				  //straight = 5, 3 of a kind = 4, 2 pair = 3, one pair = 2, high card = 1
	boolean hasStraight;
	int topStraightCard = -1;
	boolean hasFlush;
	int flushSuit = -1;
	boolean hasStraightFlush;
	boolean hasFullHouse;
	int _4ofa = -1;
	int _3ofa = -1;
	int pairA = -1;
	int pairB = -1; //pairA is the higher of the pairs if there are 2, pairA is the pair if only 1
	
	int highRank = 0;
	int secondRank = 0;
	int kickers = 0; //10000 * highest_kicker + 100 * middle_kicker + lowest_kicker
	
	int[] cardsArr = new int[15];
	int[] suits = new int[4];
	
	public Hand(HashSet<Card> pocket, HashSet<Card> community){
		for(Card c : pocket){
			cards.add(c);
			cardsArr[c.val] = cardsArr[c.val] + 1;
			suits[c.suit.ordinal()] = suits[c.suit.ordinal()] + 1;
		}
		for(Card c : community){
			cards.add(c);
			cardsArr[c.val] = cardsArr[c.val] + 1;
			suits[c.suit.ordinal()] = suits[c.suit.ordinal()] + 1;
		}
		HashSet<Card> uniqueCheck = new HashSet<Card>();
		for (Card c : cards){
			uniqueCheck.add(c);
		}
		if(uniqueCheck.size() != 7){
			System.out.println("Not a 7 card total");
		}
		Collections.sort(cards);
		computeRank();
	}
	public void computeRank(){
		checkStraight();
		checkFlush();
		checkMatches();
		if(hasStraightFlush){
			category = 9;
			highRank = topStraightCard;
		} else if (_4ofa > 0){
			category = 8;
			highRank = _4ofa;
			for(int i = 14; i >= 2; i--){
				if(i != _4ofa && cardsArr[i] > 0){
					secondRank = i;
					break;
				}
			}
		} else if (hasFullHouse){
			category = 7; 
			highRank = _3ofa;
			secondRank = pairA;
		} else if(hasFlush){
			category = 6;
			int suitCount = 0;
			for(int i = 6; i >= 0; i--){
				if(cards.get(i).suit.ordinal() == flushSuit){
					suitCount++;
					switch(suitCount){
					case 1: highRank = cards.get(i).val; break;
					case 2: secondRank = cards.get(i).val; break;
					case 3:
					case 4:
					case 5: kickers = kickers * 100 + cards.get(i).val; break;
					}
				}
			}
		} else if (hasStraight){
			category = 5;
			highRank = topStraightCard;
		} else if (_3ofa > 0){
			category = 4;
			highRank = _3ofa;
			for(int i = 6; i >= 0; i--){
				if(cards.get(i).val != _3ofa){
					if(secondRank ==0){
						secondRank = cards.get(i).val;
					} else if (kickers == 0){
						kickers = cards.get(i).val;
					}
				}
			}
		} else if(pairB > 0 && pairA > 0){
			category = 3;
			highRank = pairA;
			secondRank = pairB;
			for(int i = 6; i >= 0; i--){
				int val = cards.get(i).val; 
				if(val != pairA && val != pairB){
					kickers = val;
					break;
				}
			}
		} else if(pairA > 0){
			category = 2; 
			highRank = pairA;
			int count = 0;
			for(int i = 6; i >= 0; i--){
				if(cards.get(i).val != pairA){
					count++;
					switch(count){
					case 1: secondRank = cards.get(i).val; break;
					case 2:
					case 3: kickers = kickers * 100 + cards.get(i).val; break;
					}
				}
			}
		} else{
			category = 1;
			int count = 0;
			for(int i = 6; i >= 0; i--){
				if(cards.get(i).val != pairA){
					count++;
					switch(count){
					case 1: highRank = cards.get(i).val; break;
					case 2: secondRank = cards.get(i).val; break;
					case 3: 
					case 4:
					case 5: kickers = kickers * 100 + cards.get(i).val; break;
					}
				}
			}	
		}
	}
	
	private void checkMatches(){
		for(int i = 14; i >= 2; i--){
			switch(cardsArr[i]){
			case 4: _4ofa = i; break;
			case 3: if(_3ofa > 0){pairA = i;} else{_3ofa = i;} 
			break;
			case 2: if(pairA > -1 && pairB == -1){ pairB = i;} else {pairA = i;} break;
			}
		}
		if (_3ofa > -1 && pairA > -1){
			hasFullHouse = true; 
		}
	}
	
	private void checkFlush(){
		for(int i = 0; i < 4; i++){
			if(suits[i] >= 5){
				hasFlush = true;
				flushSuit = i;
				checkStraightFlush();
			}
		}
	}

	private void checkStraight(){
		int run = 0;
		for(int i = 2; i <= 14; i++){
			if(cardsArr[i] > 0){
				run++;
				if(run >= 5 || run == 4 && i == 5 && cardsArr[14] > 0){ //low straight
					hasStraight = true;
					topStraightCard = i;
				}
			} else{
				run = 0;
			}
		}
	}
	
	private void checkStraightFlush(){
		HashSet<Card> suitCards = new HashSet<Card>();
		int[] suitCardsArr = new int[15];
		for(Card c : cards){
			if(c.suit.ordinal() == flushSuit){
				suitCards.add(c);
				suitCardsArr[c.val] = suitCardsArr[c.val]+1;
			}
		}
		int run = 0;
		for(int i = 2; i <= 14; i++){
			if(suitCardsArr[i] > 0){
				run++;
				if(run >= 5 || run == 4 && i == 5 && suitCardsArr[14] > 0){ //low straight
					hasStraightFlush = true;
					topStraightCard = i;
//					System.out.println(i);
				}
			} else{
				run = 0;
			}
		}
		
	}
	
	@Override
	public int compareTo(Hand other) {
		if(category != other.category){
			return category - other.category;
		}
		if (highRank != other.highRank){
			return highRank - other.highRank;
		}
		if (secondRank != other.secondRank){
			return secondRank - other.secondRank;
		}
		return kickers - other.kickers;
	}
}

class Card implements Comparable<Card>{
	@Override
	public String toString() {
		return val+" "+suit.name();
	}
	@Override
	public boolean equals(Object obj) {
		Card other = (Card) obj;
		
		return val == other.val && suit == other.suit;
	}
	@Override
	public int hashCode() {
		int v = 0;
		switch(suit){
		case C: v = 1; break;
		case D: v = 2; break;
		case S: v = 3; break;
		case H: v = 4; 
		}
		return val * 100 + val;
	}
	Suit suit;
	int val;
	enum Suit{
		H, D, S, C;
	}
	public Card(String str){
		char v = str.charAt(0);
		char s = str.charAt(1);
		if(Character.isDigit(s)){
			s = str.charAt(2);
			v = 10;
		}
		else if(Character.isDigit(v)){
			val = Integer.parseInt(""+v);
		} else{
			switch(v){
			case 'J': val = 11; break;
			case 'Q': val = 12; break;
			case 'K': val = 13; break;
			case 'A': val = 14; 
			}
		}
		
		switch(s){
		case 'H': suit = Suit.H; break;
		case 'D': suit = Suit.D; break;
		case 'S': suit = Suit.S; break;
		case 'C': suit = Suit.C; break;
		}
		
	}
	public Card(int v, int s){
		switch(s){
		case 1: suit = Suit.H;
		case 2: suit = Suit.D;
		case 3: suit = Suit.S;
		case 4: suit = Suit.C;
		}
		val  = v;
	}
	@Override
	public int compareTo(Card o) {
		return val - o.val;
	}
}